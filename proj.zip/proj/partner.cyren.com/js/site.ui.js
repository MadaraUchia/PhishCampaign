if (!('prmux' in window)) {
	window.prmux = {};
}

(function (exports) {
	var matchHeight = function (selector, rowSelector) {
		if (!rowSelector) {
			rowSelector = '.row';
		}
		// Select and loop the container element of the elements you want to equalise
		$(rowSelector).each(function () {
			// Cache the highest
			var highestBox = 0;
			// Select and loop the elements you want to equalise
			$(selector, this).each(function () {
				// If this box is higher than the cached highest then store it
				if ($(this).height() > highestBox) {
					highestBox = $(this).height();
				}
			});
			// Set the height of all those children to whichever was highest 
			$(selector, this).height(highestBox);
		});
	};

	exports.matchHeight = matchHeight;

	//$(function () {
	//	// Add scrollspy to <body>
	//	$('body').scrollspy();
	//	// Add smooth scrolling on all links inside the .navbar classes anchors
	//	$("body").on('click', '.navbar a', function (event) {
	//		// Make sure this.hash has a value before overriding default behavior
	//		if (this.hash !== "") {
	//			// Prevent default anchor click behavior
	//			event.preventDefault();
	//			$('#navbarCollapse').removeClass('in');
	//			$('.navbar-toggle').addClass('collapsed');
	//			// Store hash
	//			var hash = this.hash;
	//			// Using jQuery's animate() method to add smooth page scroll
	//			// The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
	//			$('html, body').animate({
	//				scrollTop: $(hash).offset().top
	//			}, 800, function () {

	//				// Add hash (#) to URL when done scrolling (default click behavior)
	//				window.location.hash = hash;
	//			});
	//		} // End if
	//	});
	//});
})(window.prmux);
