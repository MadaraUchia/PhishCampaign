// STANDARD HELPER SCRIPTS
function isCheckBoxListItemChecked(checkboxListId, checkboxValue) {
	var checked = false;
	jQuery("#" + checkboxListId + " input:checkbox").each(function () {
	//jQuery("input[name*='" + checkboxListId + "']").each(function () {
		switch (this.value) {
			case checkboxValue:
				checked = this.checked;
				break;
		}
	});
	return checked;
}
function isDropDownListItemSelected(dropdownListId, selectedValue) {
	return jQuery("#" + dropdownListId).val().toLowerCase() == selectedValue.toLowerCase();
}
function isListBoxOrDropDownListItemSelected(dropdownListId, selectedValue) {
	values = jQuery("#" + dropdownListId).val();
	var lowerCaseValues = [];

	if (Array.isArray(values)) {
		$.each(values, function (index, value) {
			lowerCaseValues.push(value.toLowerCase());
		});
		values = lowerCaseValues;
	} else {
		if (values) {
			values = values.toLowerCase();
		}
	}

	if (values) {
		return values.includes(selectedValue.toLowerCase());
	} else {
		return false;
	}
}
function updateCheckboxGroup(question, checked) {
	var rows = jQuery('table[id$=' + question + '] tr');
	var rowCount = rows.length;
	rows.each(function (rowIx, tr) {
		jQuery(tr).find('input[type=checkbox]').each(function (idx, input) {
			jQuery(input).attr("checked", checked);
		});
	});
}
function showError(title, body) {
	var message = "<div class='modal-header'>" +
	"<button class='close' data-dismiss='modal'>&times;</button>" +
	"<h4 id='Title' class='modal-title'><span class='glyphicon glyphicon-alert'></span>&nbsp; " + title + "</h4>" +
	"</div>" +
	"<div class='modal-body'>" + body + "</div>" +
	"<div class='modal-footer'>" +
	"<button class='btn btn-default' data-dismiss='modal' type='button'>Close</button>" +
	"</div>";
	PrmApp.prototype.showModal(message, false);
}

var queryStringUtil = {
	update: function (replacements, includeOnly) {
		var params = {},
			names = {},
			includeLower = includeOnly && includeOnly.map(function (val, i, arr) {
				return val.toLowerCase();
			});

		if (window.location.search) {
			var query = window.location.search.substring(1);
			$.each(query.split('&'), function (i, val) {
				var parm = val.split('='),
					name = decodeURIComponent(parm[0]),
					nameLower = name.toLowerCase(),
					value = decodeURIComponent(parm[1]);

				if (!includeLower || includeLower.indexOf(nameLower) != -1) {
					if (!params[nameLower]) {
						params[nameLower] = [];
						names[nameLower] = name;
					}
					params[nameLower].push(value);
				}
			});
		}
		if (replacements) {
			$.each(replacements, function (prop, valOrFn) {
				var propLower = prop.toLowerCase(),
					newVal = (typeof (valOrFn) === 'function') ? valOrFn(params[propLower] || []) : valOrFn;

				if (!names[propLower]) {
					names[propLower] = prop;
				}
				if (newVal == null) {
					params[propLower] = [];
				}
				else if (newVal.constructor !== Array) {
					params[propLower] = [(newVal + '')];
				}
				// it's an array
				else {
					params[propLower] = $.map(newVal, function (val, i) {
						return val + '';
					});
				}
			});
		}
		var newQuery = $.map(params, function (arr, propLower) {
			var name = names[propLower];
			if (!arr.length) {
				return null;
			}
			return $.map(arr, function (val, i) {
				if (!val) {
					return null;
				}
				return [encodeURIComponent(name), encodeURIComponent(val)].join('=');
			});
		}).join('&');

		if (newQuery) {
			newQuery = '?' + newQuery;
		}
		else {
			newQuery = '?'; // empty string doesnt update
		}
		return newQuery;
	}
};

var historyUtil = {
	updateQueryString: function (replacements, includeOnly) {
		if (!replacements) {
			return;
		}
		window.history.replaceState([], window.title, queryStringUtil.update(replacements, includeOnly));
	}
};



// CUSTOM SCRIPTS
var portal = {};
portal.webRoot = null;
portal.homeDirectory = null;

// search
portal.search = (function($) {
	var search = function(textBoxId, buttonId) {
		this.textBoxId = textBoxId;
		this.buttonId = buttonId;
	};
	// instance members
	search.prototype.get_textBoxId = function () {
		return this.textBoxId;
	};
	search.prototype.get_buttonId = function () {
		return this.buttonId;
	};
	search.prototype.results = function() {
		var value = $("#" + this.get_textBoxId()).val();
		portal.search.results(value);
	}
	search.prototype.domReady = function () {
		var that = this;
        require(['pjs!typeahead.bundle'], function () {
		// bind to the textbox enter pressed event
            $("#" + that.get_textBoxId()).keypress(function (event) {
			if ((event.keyCode == 10) || (event.keyCode == 13)) {
				event.preventDefault();
				that.results();
			}
		});
		
		var engine = new Bloodhound({
			datumTokenizer: Bloodhound.tokenizers.obj.whitespace("name"),
			queryTokenizer: Bloodhound.tokenizers.whitespace,
			remote: {
				url: portal.homeDirectory + "search/proxy.ashx/suggest?q=%QUERY",
				filter: function (parsedResponse) {
					return parsedResponse.results;
				}
			}
		});
		engine.initialize();

            $("#" + that.get_textBoxId()).typeahead(null, {
			displayKey: "name",
			source: engine.ttAdapter()
		})
		.on("typeahead:selected", function (event, data, dataset) {
			portal.search.results(data.name);
		});	
		
		// attach to the click even of button
            if ((typeof that.get_buttonId() !== undefined) && (that.get_buttonId() != null)) {
                $("#" + that.get_buttonId()).click(function (event) {
				event.preventDefault();
				that.results();
			});
		}
        });
	};

	// static methods
	search.results = function(value) {
		if ((typeof value === undefined) || (value == null)) {
			value = "";
		}
		value = encodeURIComponent(value.toString()).replace(/%20/g, "+")
		window.location.href = portal.homeDirectory + "search/results.aspx?q=" + value;
	}
	search.click = function(q, r, s, url) {
		$.ajax({
			type: "GET",
			async: false,
			url: portal.homeDirectory + "search/proxy.ashx/click",
			data: { q: q, r: r, s: s, url: url },
			contentType: "x-www-form-urlencoded"
		});
		return true;
	};
	search.instances = [];
	search.createRegisteredInstance = function (textBoxId, buttonId) {
		// first instance attach ready handler
		if (search.instances.length == 0) {
			$(function () {
				$.each(search.instances, function (ix, instance) {
					instance.domReady();
				});
			});
		}

		var instance = new search(textBoxId, buttonId);
		search.instances.push(instance);
		return instance;
	};
	return search;
})(jQuery);

// state province toggler
portal.stateProvinceToggler = (function($) {
	var stateProvinceToggler = function(countryListId, stateListId, provinceTextBoxId) {
		this.countryListId = countryListId;
		this.stateListId = stateListId;
		this.provinceTextBoxId = provinceTextBoxId;
	};

	// instance members
	stateProvinceToggler.prototype.get_countryListId = function () {
		return this.countryListId;
	};
	stateProvinceToggler.prototype.get_stateListId = function () {
		return this.stateListId;
	};
	stateProvinceToggler.prototype.get_provinceTextBoxId = function () {
		return this.provinceTextBoxId;
	};
	stateProvinceToggler.prototype.updateDisplay = function () {
		var country = $("#" + this.get_countryListId()).val();
		this.updateDisplayInternal(country);
	};
	stateProvinceToggler.prototype.updateDisplayInternal = function (country) {
		if (stateProvinceToggler.isUsOrCanada(country)) {
			$("#" + this.get_stateListId()).show();
			$("#" + this.get_provinceTextBoxId()).hide();
			$("#stateProvinceRequired").show();
		} else {
			$("#" + this.get_stateListId()).hide();
			$("#" + this.get_provinceTextBoxId()).show();
			$("#stateProvinceRequired").hide();
		}
	};
	stateProvinceToggler.prototype.get_selectedStateProvince = function () {
		return this.get_isUnitedStatesOrCanadaSelected() ?
			$("#" + this.get_stateListId()).val() :
			$("#" + this.get_provinceTextBoxId()).val();
	};
	stateProvinceToggler.prototype.get_isUnitedStatesOrCanadaSelected = function () {
		return stateProvinceToggler.isUsOrCanada($("#" + this.get_countryListId()).valueOf());
	};

	// the server code has overloaded method
	//stateProvinceToggler.prototype.setSelectedStateProvince = function (country, stateProvince) {
	//stateProvinceToggler.prototype.setSelectedStateProvince = function (country, state, province) {

	stateProvinceToggler.prototype.setSelectedStateProvince = function () {
		var country = arguments[0];
		var state = null;
		var province = null;

		if (arguments.length == 2) {
			if (stateProvinceToggler.isUsOrCanada(country)) {
				state = arguments[1];
			} else {
				province = arguments[1];
			}
		} else if (arguments.length == 3) {
			state = arguments[1];
			province = arguments[2];
		} else {
			throw "Invalid argument count: " + arguments.length;
		}

		$("#" + this.get_countryListId()).val(country);
		$("#" + this.get_stateListId()).val(state);
		$("#" + this.get_provinceTextBoxId()).val(province);
		this.updateDisplay();
	};
	stateProvinceToggler.prototype.domReady = function () {
		// attach to change handler
		$("#" + this.get_countryListId()).change({ toggler: this }, function (e) {
			var country = $(this).val();
			e.data.toggler.updateDisplayInternal(country);
		});
		// update current page
		this.updateDisplay();
	};

	// static methods
	stateProvinceToggler.isUsOrCanada = function (country) {
		return (country == null) ||
			((country = $.trim(country)) == "") ||
			(country == "United States") ||
			(country == "Canada");
	};
	stateProvinceToggler.instances = [];
	stateProvinceToggler.createRegisteredInstance = function (countryListId, stateListId, provinceTextBoxId) {
		// first instance attach ready handler
		if (stateProvinceToggler.instances.length == 0) {
			$(function () {
				$.each(stateProvinceToggler.instances, function (ix, instance) {
					instance.domReady();
				});
			});
		}

		var instance = new stateProvinceToggler(countryListId, stateListId, provinceTextBoxId);
		stateProvinceToggler.instances.push(instance);
		return instance;
	};
	return stateProvinceToggler;
})(jQuery);

// syndication feed widget
portal.syndicationFeedWidget = (function ($) {
	var syndicationFeedWidget = function (clientId, widgetType, feedUrl, fadeDuration, displayDuration, titleLength, maxItems) {
		this.clientId = clientId;
		this.widgetType = widgetType;
		this.feedUrl = feedUrl;
		this.fadeDuration = fadeDuration;
		this.displayDuration = displayDuration;
		this.titleLength = titleLength;
		this.maxItems = maxItems;
		this.feed = null;
	};

	// instance members
	syndicationFeedWidget.prototype.get_clientId = function () {
		return this.clientId;
	};
	syndicationFeedWidget.prototype.get_widgetType = function () {
		return this.widgetType;
	};
	syndicationFeedWidget.prototype.get_feedUrl = function () {
		return this.feedUrl;
	};
	syndicationFeedWidget.prototype.get_fadeDuration = function () {
		return this.fadeDuration;
	};
	syndicationFeedWidget.prototype.get_displayDuration = function () {
		return this.displayDuration;
	};
	syndicationFeedWidget.prototype.get_titleLength = function () {
		return this.titleLength;
	};
	syndicationFeedWidget.prototype.get_maxItems = function () {
		return this.maxItems;
	};
	syndicationFeedWidget.prototype.get_feed = function () {
		return this.feed;
	};
	syndicationFeedWidget.prototype.initTicker = function (immediate) {
		var $ticker = $("#" + this.get_clientId()).find(".feed-ticker");
		var $entry = $("#" + this.get_clientId()).find(".feed-ticker-entry");

		var entryIndex = -1;
		var that = this;
		var cycle = function (immediate) {
			entryIndex = (entryIndex + 1) % that.get_feed().entries.length;
			that.displayEntry($entry, entryIndex);
			$entry.fadeIn(immediate ? 0 : that.get_fadeDuration(), function () {
				setTimeout(function () {
					$entry.fadeOut(that.get_fadeDuration(), function () {
						if ($entry.is(":focus")) {
							$entry.blur();
						}
						cycle(false);
					});
				}, that.get_displayDuration());
			});
		};

		$ticker.fadeIn(0, function () {
			cycle(immediate);
		});
	};
	syndicationFeedWidget.prototype.initList = function (immediate) {
		var $list = $("#" + this.get_clientId()).find(".feed-list");
		var $first_item = $("#" + this.get_clientId()).find(".feed-list-item:first-child");

		for (var entryIndex = 0; entryIndex < this.get_feed().entries.length; entryIndex++) {
			var $item = $first_item.clone();
			var $entry = $item.find(".feed-list-entry");
			this.displayEntry($entry, entryIndex);
			$list.append($item);
		}

		$first_item.remove();
		$list.fadeIn(immediate ? 0 : this.get_fadeDuration());
	};
	syndicationFeedWidget.prototype.displayEntry = function ($entry, entryIndex) {
		var entry = this.get_feed().entries[entryIndex];
		var href = entry.link
		var title = entry.title;

		if (title && title.length > this.get_titleLength()) {
			title = title.substr(0, this.get_titleLength());
			var lastSpace = title.lastIndexOf(" ");
			if (lastSpace > 0) {
				title = title.substr(0, lastSpace);
			}
			title = title.trim() + "...";
		}
		$entry.attr("href", href).text(title);
	};
	syndicationFeedWidget.prototype.domReady = function () {
		var $loading = $("#" + this.get_clientId()).find(".feed-loading");
		var that = this;

		var displayFeed = function (d, immediate) {
			if (d.feed && d.feed.entries && d.feed.entries.length) {
				that.feed = d.feed;
				$loading.fadeOut(immediate ? 0 : that.get_fadeDuration(), function () {
					switch (that.get_widgetType()) {
						case "Ticker":
							that.initTicker(immediate);
							break;
						case "List":
							that.initList(immediate);
							break;
					}
				});
				return true;
			} else {
				return false;
			}
		};

		// load the feed from session storage
		var cacheKey = "FeedWidget";
		try {
			if (sessionStorage.getItem(cacheKey)) {
				var index = JSON.parse(sessionStorage.getItem(cacheKey));
				for (var i = 0; i < index.feeds.length; i++) {
					if (index.feeds[i] == this.get_feedUrl()) {
						var d = JSON.parse(sessionStorage.getItem(cacheKey + i));
						if (displayFeed(d, true)) {
							return;
						}
						break;
					}
				}
			}
		} catch (e) {
			// load failed
		}

		$.ajax({
			method: "GET",
			url: this.get_feedUrl(),
			cache: true,
			success: function(d) {
				if (displayFeed(d, false)) {
					// save the feed to session storage
					try {
						var index;
						if (sessionStorage.getItem(cacheKey)) {
							index = JSON.parse(sessionStorage.getItem(cacheKey));
						} else {
							index = {feeds: []};
						}
						var feedIndex = -1
						for (var i = 0; i < index.feeds.length; i++) {
							if (index.feeds[i] == that.get_feedUrl()) {
								feedIndex = i;
								break;
							}
						}
						if (feedIndex == -1) {
							feedIndex = index.feeds.length;
							index.feeds.push(that.get_feedUrl());
							sessionStorage.setItem(cacheKey, JSON.stringify(index));
						}
						sessionStorage.setItem(cacheKey + feedIndex, JSON.stringify(d));
					} catch (e) {
						// save failed
					}
				} else {
					$loading.text("No entries found.");
				}
			},
			error: function() {
				$loading.text("Error loading feed.");
			}
		});
	};
	syndicationFeedWidget.instances = [];
	syndicationFeedWidget.createRegisteredInstance = function (clientId, widgetType, feedUrl, fadeDuration, displayDuration, titleLength, maxItems) {
		// first instance attach ready handler
		if (syndicationFeedWidget.instances.length == 0) {
			$(function () {
				$.each(syndicationFeedWidget.instances, function (ix, instance) {
					instance.domReady();
				});
			});
		}

		var instance = new syndicationFeedWidget(clientId, widgetType, feedUrl, fadeDuration, displayDuration, titleLength, maxItems);
		syndicationFeedWidget.instances.push(instance);
		return instance;
	};
	return syndicationFeedWidget;
})(jQuery);

//// BEGIN YOU TUBE SEARCH ////

var youTubeSearch = {};
youTubeSearch.MAX_RESULTS = 5;
youTubeSearch.apiKey = "AIzaSyCyHcJcxsPDirfDBBZ-6tmuJW28d8RQXE8"; // Default key
youTubeSearch.currentSearch = null;
youTubeSearch.searchTextId = null;
youTubeSearch.searchButtonId = null;
youTubeSearch.resultsId = null;
youTubeSearch.dialogId = null;
youTubeSearch.onVideoSelected = null;
youTubeSearch.onClose = null;
youTubeSearch.initialize = function (searchTextId, searchButtonId, resultsId, dialogId) {
	youTubeSearch.searchTextId = searchTextId;
	youTubeSearch.searchButtonId = youTubeSearch.searchButtonId;
	youTubeSearch.resultsId = resultsId;
	youTubeSearch.dialogId = dialogId;
	youTubeSearch.apiKey = (typeof (apiKey) !== "undefined" && apiKey !== "") ? apiKey : youTubeSearch.apiKey;

	jQuery("#" + searchTextId).keypress(function (event) {
		if (event.which != 13) {
			return;
		}
		event.preventDefault();
		youTubeSearch.doSearch();
	});
	jQuery("#" + searchButtonId).click(function (event) {
		youTubeSearch.doSearch();
	});
	//jQuery("#" + dialogId).dialog({
	//	modal: true,
	//	width: 735,
	//	height: 615,
	//	autoOpen: false,
	//	open: function (event, ui) {
	//		jQuery("#" + youTubeSearch.searchTextId).val("");
	//		jQuery("#" + youTubeSearch.searchTextId).focus();
	//	},
	//	close: function (event, ui) {
	//		jQuery("html,body").removeClass("youTubeProfileNoScroll");
	//		jQuery("#" + youTubeSearch.resultsId + " iframe").attr("src", "about:blank"); // needed to prevent nasty flash w/ IE9
	//		jQuery("#" + youTubeSearch.resultsId).empty();
	//		if (youTubeSearch.onClose) {
	//			youTubeSearch.onClose();
	//		}
	//	}
	//});
	jQuery("#youTubeProfileSearchResults").scroll(function (e) {
		var elem = jQuery(e.currentTarget);
		if ((elem[0].scrollHeight - elem.scrollTop()) == elem.outerHeight()) {
			youTubeSearch.loadMore();
		}
	});
};
youTubeSearch.doSearch = function () {
	jQuery("#" + youTubeSearch.resultsId + " iframe").attr("src", "about:blank"); // needed to prevent nasty flash w/ IE9
	jQuery("#" + youTubeSearch.resultsId).empty();

	var searchText = jQuery.trim(jQuery("#" + youTubeSearch.searchTextId).val());
	if (!searchText || (searchText.length < 2)) {
		jQuery("#" + youTubeSearch.resultsId).html("<div id=\"youTubeProfileSearchError\">Search phrase must be at least 2 characters in length.</div>");
		return;
	}

	youTubeSearch.currentSearch = {
		SearchText: searchText,
		StartIndex: 1,
		Results: [],
		PrevPageToken: null,
		NextPageToken: null,
		HasMore: false
	};

	youTubeSearch.queryService(false);
};
youTubeSearch.loadMore = function () {
	jQuery("tr.youTubeSearchResultsLoadMore > td").html("Loading...");
	youTubeSearch.currentSearch.StartIndex += youTubeSearch.MAX_RESULTS;
	youTubeSearch.queryService(true);
};
youTubeSearch.queryService = function (queryMore) {
	// Youtube API
	var youTubeUrl = "https://www.googleapis.com/youtube/v3/search?type=video&key=" +
			youTubeSearch.apiKey +
			"&maxResults=" +
			youTubeSearch.MAX_RESULTS +
			"&part=snippet&fields=items(id,snippet),nextPageToken,prevPageToken";
	if (queryMore) {
		if (youTubeSearch.currentSearch.NextPageToken) {
			youTubeUrl += "&pageToken=" + youTubeSearch.currentSearch.NextPageToken;
		} else {
			jQuery("#" + youTubeSearch.resultsId + " tr.load_more").val("No more results");
			return;
		}
	}
	if (youTubeSearch.currentSearch.SearchText && (youTubeSearch.currentSearch.SearchText != "")) {

		// check if the user has pasted in an URL from YouTube... If so, we should extract VideoId and query for that
		// http://stackoverflow.com/questions/3452546/javascript-regex-how-to-get-youtube-video-id-from-url
		//
		var regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
		var match = youTubeSearch.currentSearch.SearchText.match(regExp);
		if (match && (match[2].length == 11)) {
			youTubeUrl += "&q=" + encodeURIComponent(match[2]);
		} else {
			youTubeUrl += "&q=" + encodeURIComponent(youTubeSearch.currentSearch.SearchText);
		}
	}

	jQuery.ajax({
		type: "GET",
		url: youTubeUrl,
		dataType: "jsonp",
		success: function (response) {
			if (queryMore) {
				jQuery("#" + youTubeSearch.resultsId + " tr.youTubeSearchResultsLoadMore").remove();
			} else {
				if (response.items && response.items.length > 0) {
					jQuery("#" + youTubeSearch.resultsId).html("<table id=\"youTubeProfileSearchResultsTable\"></table>");
				} else {
					jQuery("#" + youTubeSearch.resultsId).html("<div id=\"youTubeProfileSearchError\">No Videos Found</div>");
					return;
				}
			}
			if (response.items) {
				jQuery.each(response.items, function (ix, data) {
					var video_id = data.id.videoId;
					var video_title = data.snippet.title;
					var video_description = data.snippet.description;
					var video = jQuery("<tr><td>" +
						"<div class=\"videoDescriptionScroll\">" +
							"<div class=\"videoDescriptionContainer\">" +
								"<div class=\"videoTitle\"><a href=\"#\" onclick=\"youTubeSearch.selectVideo('" + video_id + "');return false;\"></a></div>" +
								"<div class=\"videoDescription\"></div>" +
							"</div>" +
						"</div>" +
						"</td><td>" +
							"<iframe src=\"//www.youtube.com/embed/" + video_id + "\" width=\"320\" height=\"240\" frameborder=\"0\" type=\"text/html\"></iframe>" +
						"</td></tr>");

					video.find("div.videoTitle a").text(video_title);
					video.find("div.videoDescription").text(video_description);

					//alert(video.html());

					jQuery("#youTubeProfileSearchResultsTable").append(video);

					youTubeSearch.currentSearch.Results.push(data);
					youTubeSearch.currentSearch.PrevPageToken = response.prevPageToken;
					youTubeSearch.currentSearch.NextPageToken = response.nextPageToken;

				});
				if (typeof (response.nextPageToken) !== "undefined" && response.nextPageToken !== "") {
					jQuery("#youTubeProfileSearchResultsTable").append("<tr class=\"youTubeSearchResultsLoadMore\"><td colspan=\"2\"><a href=\"#\" onclick=\"youTubeSearch.loadMore();return false;\">Load More...</a></td></tr>")
				}
			}
		}
	});
};
youTubeSearch.show = function () {
	jQuery("html,body").addClass("youTubeProfileNoScroll");
	//jQuery("#" + youTubeSearch.dialogId).dialog("open");
};
youTubeSearch.selectVideo = function (videoId) {
	var selectedVideo = null;
	jQuery.each(youTubeSearch.currentSearch.Results, function (ix, data) {
		if (data.id.videoId == videoId) {
			selectedVideo = data;
			return false;
		}
	});

	if (youTubeSearch.onVideoSelected) {
		youTubeSearch.onVideoSelected(selectedVideo);
	}
	youTubeSearch.close();
};
youTubeSearch.close = function () {
	//jQuery("#" + youTubeSearch.dialogId).dialog("close");
	jQuery("#youTubeProfileSearchDialog").modal('hide');
};
//// END YOU TUBE SEARCH ////
jQuery(document).ready(function ($) {
	$("#YouTubeVideo").on('show.bs.modal', function (event) {
		var button = $(event.relatedTarget);
		var titleData = button.data('title');
		$(this).find('.modal-title').text(titleData);
		var src = button.data('src');
		$("#YouTubeVideo iframe").attr({
			'src': src,
		});
	});
	$("#YouTubeVideo").on('hidden.bs.modal', function () {
		$("#YouTubeVideo iframe").attr({
			'src': "",
		});
	});

});

jQuery(document).ready(function ($) {
	$("#ImageModal").on('show.bs.modal', function (event) {
		var button = $(event.relatedTarget);
		var titleData = button.data('title');
		$(this).find('.modal-title').text(titleData);
		var src = button.data('src');
		$("#ImageModal img").attr({
			'src': src,
		});
	});
	$("#ImageModal").on('hidden.bs.modal', function () {
		$("#ImageModal img").attr({
			'src': "",
		});
	});

});